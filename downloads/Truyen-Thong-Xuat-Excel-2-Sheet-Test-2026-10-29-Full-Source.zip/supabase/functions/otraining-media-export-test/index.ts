import {authenticate,AccessError,readDashboardValues} from './access.ts';
import {MediaExportModel as M} from './model.js';
const ORIGIN='https://centraltraining.github.io',CORS={'Access-Control-Allow-Origin':ORIGIN,'Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'POST,OPTIONS','Cache-Control':'no-store','Vary':'Origin'};
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{...CORS,'Content-Type':'application/json'}});
const fail=(message,status=400)=>{throw new AccessError(message,status);};
const validId=v=>/^[1-9]\d{0,8}$/.test(M.clean(v));
async function selection(body){
 const principal=await authenticate(body.dashboardToken);
 if(typeof body.campaignKey!=='string'||!/^[-A-Za-z0-9_]{1,120}$/.test(body.campaignKey)||!/^\d{4}-(0[1-9]|1[0-2])$/.test(body.month||'')||!M.record(body.filters))fail('Chiến dịch, tháng hoặc bộ lọc chưa hợp lệ.');
 const fields=['scopeRegion','scopeTrainer','scopeSale','region','trainer','search'];
 if(fields.some(k=>typeof body.filters[k]!=='string'||body.filters[k].length>250)||Object.keys(body.filters).some(k=>!fields.includes(k)))fail('Bộ lọc xuất chưa hợp lệ.');
 const data=await readDashboardValues(['campaigns','pgs:'+body.month]);
 const camp=(data.campaigns||[]).find(c=>String(c.id)===body.campaignKey&&c.month===body.month&&c.group==='truyenthong'&&(c.subtype||'noibo')==='noibo');
 if(!camp||!validId(camp.otrId)||!['noibo','fm'].includes(camp.mediaCampaignType||'noibo')||(M.clean(camp.programId)&&!validId(camp.programId))||((camp.mediaCampaignType||'noibo')==='fm'&&!validId(camp.programId)))fail('Admin chưa lưu đủ nguồn, ID chiến dịch hoặc Program ID truyền thông nội bộ.',409);
 const source=data['pgs:'+body.month];if(!Array.isArray(source))fail('Chưa có danh sách PG của tháng đang xem.',409);
 const f=body.filters,trainers=new Map(principal.trainers.map(t=>[String(t.id),t])),byCode=new Map();
 for(const pg of source){
  if(pg.brand!=='OPPO'||pg.status!=='Đang làm')continue;
  const t=trainers.get(String(pg.trainerId)),region=t?.region||pg.area||'';
  if(principal.role!=='admin'&&(!t||M.norm(t.region)!==M.norm(principal.region)))continue;
  if(f.scopeSale&&M.clean(pg.sale)!==f.scopeSale)continue;
  if(f.scopeTrainer){if(String(pg.trainerId)!==f.scopeTrainer)continue;}else if(f.scopeRegion&&(!t||M.norm(t.region)!==M.norm(f.scopeRegion)))continue;
  if(f.region&&(!t||M.norm(t.region)!==M.norm(f.region)))continue;
  if(f.trainer&&String(pg.trainerId)!==f.trainer)continue;
  const term=f.search.toLowerCase();if(term&&!M.clean(pg.code).toLowerCase().includes(term)&&!M.clean(pg.name).toLowerCase().includes(term))continue;
  const key=M.code(pg.code);if(!key)fail('Có PG chưa có mã nhân viên. Hãy cập nhật DATA trước khi xuất.',409);
  const row={code:M.clean(pg.code),name:M.clean(pg.name),trainerId:String(pg.trainerId||''),region:M.clean(region)};
  if(byCode.has(key)&&JSON.stringify(byCode.get(key))!==JSON.stringify(row))fail('Mã PG đang trùng thông tin phân công. Hãy kiểm tra DATA trước khi xuất.',409);
  byCode.set(key,row);
 }
 const roster=[...byCode.values()];if(!roster.length)fail('Không có PG Đang làm khớp bộ lọc trong phạm vi được phép xuất.',409);
 return {principal,camp,roster,signature:JSON.stringify([camp.id,camp.month,camp.name,camp.otrId,camp.programId,camp.mediaCampaignType,roster])};
}
Deno.serve(async req=>{
 const origin=req.headers.get('origin');if(origin&&origin!==ORIGIN)return json({error:'Nguồn truy cập không hợp lệ.'},403);if(req.method==='OPTIONS')return new Response(null,{status:204,headers:CORS});if(req.method!=='POST')return json({error:'Chỉ hỗ trợ POST.'},405);
 try{
  const raw=await req.text();if(raw.length>12000)fail('Yêu cầu quá dài.',413);let body;try{body=JSON.parse(raw);}catch{fail('Yêu cầu xuất Excel không hợp lệ.');}
  if(!M.record(body)||body.type!=='mediaexport')fail('Yêu cầu xuất Excel không hợp lệ.');
  const ctx=await selection(body),userInfo=Deno.env.get('OTRAINING_USER_INFO');if(!userInfo)fail('Chưa sẵn sàng kết nối nguồn truyền thông.',503);
  const url=new URL('https://otraining.io.vn/api/media-dashboard/employees');url.search=new URLSearchParams({campaignType:ctx.camp.mediaCampaignType||'noibo',campaignId:M.clean(ctx.camp.otrId),programId:M.clean(ctx.camp.programId)||'1',vung:'Mien Trung',area:'all',search:'',page:'1',limit:'999999'}).toString();
  let source;try{const r=await fetch(url,{method:'GET',redirect:'error',headers:{'x-user-info':userInfo,'Accept':'application/json','Referer':'https://otraining.io.vn/quanly_kqtt.html'},signal:AbortSignal.timeout(40000)});if(!r.ok)fail('Nguồn truyền thông chưa trả dữ liệu xuất (HTTP '+r.status+'). Chưa tạo file.',502);source=await r.json();}catch(error){if(error instanceof AccessError)throw error;fail('Chưa đọc được nguồn truyền thông. Chưa tạo file, hãy thử lại.',502);}
  let workbook;try{workbook=M.normalize(source,ctx.camp,ctx.roster);}catch{fail('Nguồn truyền thông thiếu dữ liệu chi tiết hoặc chưa khớp chương trình. Chưa tạo file thiếu số liệu.',502);}
  const latest=await selection(body);if(latest.principal.userId!==ctx.principal.userId||latest.principal.role!==ctx.principal.role||latest.signature!==ctx.signature)fail('Quyền, phân công PG hoặc nguồn chiến dịch vừa thay đổi. Hãy tải lại trước khi xuất.',409);
  return json({ok:true,source:'otraining-media-employees',campaignKey:body.campaignKey,month:body.month,campaignId:M.clean(ctx.camp.otrId),programId:M.clean(ctx.camp.programId),campaignType:ctx.camp.mediaCampaignType||'noibo',readAt:new Date().toISOString(),...workbook});
 }catch(error){return json({error:error instanceof AccessError?error.message:'Chưa xuất được Excel truyền thông. Dữ liệu đã lưu được giữ nguyên.'},error instanceof AccessError?error.status:503);}
});
