let mediaReportExportBusy_=false;
function mediaReportExportFilters_(){return {scopeRegion:document.getElementById('ovFilterRegion')?.value||'',scopeTrainer:document.getElementById('ovFilterTrainer')?.value||'',scopeSale:document.getElementById('ovFilterSale')?.value||'',region:document.getElementById('mediaNotDoneFilterRegion')?.value||'',trainer:document.getElementById('mediaNotDoneFilterTrainer')?.value||'',search:(document.getElementById('mediaNotDoneSearchInput')?.value||'').trim()};}
function mediaReportExportPgs_(){
 const f=mediaReportExportFilters_(),seen=new Map();
 scopedActivePgs('OPPO').filter(p=>canExportMediaTrainerRecord_(p.trainerId,trainerOf(p.trainerId)?.region||p.area)).filter(p=>(!f.region||trainerOf(p.trainerId)?.region===f.region)&&(!f.trainer||p.trainerId===f.trainer)&&(!f.search||String(p.code||'').toLowerCase().includes(f.search.toLowerCase())||String(p.name||'').toLowerCase().includes(f.search.toLowerCase()))).forEach(p=>seen.set(normalizeCode_(p.code),p));
 return [...seen.values()];
}
function mediaReportExportMessage_(message,error=false){const el=document.getElementById('mediaReportExportMsg');if(el){el.textContent=message;el.style.color=error?'var(--red)':'var(--muted)';}}
async function exportMediaReportExcel_(){
 if(mediaReportExportBusy_)return;
 if(!isAdmin()&&!isTrainer())return mediaReportExportMessage_('Tài khoản không có quyền xuất báo cáo.',true);
 const month=currentMonth,camp=campaigns.find(c=>String(c.id)===String(mediaScopeKey)&&c.month===month&&c.group==='truyenthong'&&campaignSubtype(c)==='noibo');
 if(!camp?.otrId)return mediaReportExportMessage_('Admin cần lưu nguồn và ID chiến dịch nội bộ trước khi xuất.',true);
 const list=mediaReportExportPgs_();if(!list.length)return mediaReportExportMessage_('Không có PG Đang làm khớp bộ lọc trong phạm vi được phép xuất.',true);
 const owner=()=>JSON.stringify([session?.userId,session?.role,session?.region,session?.trainerId]),initialOwner=owner(),filters=mediaReportExportFilters_(),codes=list.map(p=>normalizeCode_(p.code)).sort(),campaignSignature=c=>JSON.stringify(c&&[c.id,c.month,c.name,c.otrId,c.programId,c.mediaCampaignType]);
 const initialCampaign=campaignSignature(camp),initialRoster=JSON.stringify(list.map(p=>[p.code,p.name,p.trainerId,trainerOf(p.trainerId)?.region||p.area]));
 const same=()=>month===currentMonth&&initialOwner===owner()&&String(mediaScopeKey)===String(camp.id)&&mediaActiveSubtype==='noibo'&&initialCampaign===campaignSignature(campaigns.find(c=>String(c.id)===String(camp.id)));
 const current=()=>same()&&JSON.stringify(filters)===JSON.stringify(mediaReportExportFilters_())&&initialRoster===JSON.stringify(mediaReportExportPgs_().map(p=>[p.code,p.name,p.trainerId,trainerOf(p.trainerId)?.region||p.area]));
 mediaReportExportBusy_=true;const button=document.getElementById('mediaReportExportBtn');if(button){button.disabled=true;button.textContent='Đang xuất…';}mediaReportExportMessage_('Đang lấy tiến độ PG và chi tiết bài đăng…');
 try{
  const pending=workshopNoiboToken_(),title=document.querySelector('#wsnbAuthOverlay h3');if(title)title.textContent='Xác thực xuất Excel truyền thông';const token=await pending;if(!current())return;
  const fn=location.pathname.startsWith('/Test/')?'otraining-media-export-test':'otraining-media-export';
  const response=await fetch(SUPABASE_URL+'/functions/v1/'+fn,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+OTRAINING_ANON_KEY_},body:JSON.stringify({type:'mediaexport',dashboardToken:token,campaignKey:String(camp.id),month,filters}),signal:AbortSignal.timeout(65000)});
  let out;try{out=await response.json();}catch{throw Error('Chưa nhận được dữ liệu Excel hợp lệ. Chưa tạo file.');}if(response.status===401)sessionStorage.removeItem('workshop_private_session');if(!response.ok||!out.ok)throw Error(out.error||'Chưa lấy được báo cáo truyền thông.');if(!current())return;
  if(out.source!=='otraining-media-employees'||out.month!==month||out.campaignKey!==String(camp.id)||out.campaignId!==String(camp.otrId)||out.programId!==String(camp.programId||'')||out.campaignType!==(camp.mediaCampaignType||'noibo')||!Array.isArray(out.sheets)||out.sheets.length!==2||out.pgCount!==codes.length)throw Error('Báo cáo chưa khớp chiến dịch hoặc danh sách PG đang chọn. Hãy tải lại rồi xuất.');
  if(typeof XLSX==='undefined')throw Error('Thư viện Excel chưa sẵn sàng. Hãy tải lại trang.');
  const wb=XLSX.utils.book_new(),headers=[['Mã NV','Tên nhân viên','Vùng','Khu vực','Đã duyệt FB','Bị loại FB','Đã duyệt TT','Bị loại TT'],['Mã NV','Tên nhân viên','Vùng','Khu vực','Tên chương trình','Platform','Link','Trạng thái','View','Tim/Like','Comment','Share','Favorite']];
  out.sheets.forEach((sheet,i)=>{
   const len=i?13:12;if(sheet.name!==(i?'ChiTietLink':'TienDoTruyenThong')||!Array.isArray(sheet.columns)||sheet.columns.length!==len||!headers[i].every((h,k)=>sheet.columns[k]===h)||!Array.isArray(sheet.rows)||sheet.rows.some(r=>!Array.isArray(r)||r.length!==len||r.some(v=>v!==null&&!['number','string'].includes(typeof v))))throw Error('Cấu trúc hai sheet Excel chưa hợp lệ.');
   if(!i&&JSON.stringify(sheet.rows.map(r=>normalizeCode_(r[0])).sort())!==JSON.stringify(codes))throw Error('Danh sách PG vừa thay đổi. Hãy tải lại trước khi xuất.');
   if(i&&sheet.rows.some(r=>!codes.includes(normalizeCode_(r[0]))))throw Error('Chi tiết bài đăng chưa khớp danh sách PG.');
   const ws=XLSX.utils.aoa_to_sheet([sheet.columns,...sheet.rows]);ws['!cols']=(i?[16,30,18,22,42,14,65,18,15,15,15,15,15]:[16,30,18,22,16,16,16,16,30,30,30,30]).map(wch=>({wch}));ws['!rows']=[{hpt:55}];ws['!autofilter']={ref:XLSX.utils.encode_range({r:0,c:0},{r:sheet.rows.length,c:len-1})};XLSX.utils.book_append_sheet(wb,ws,sheet.name);
  });
  if(out.sheets[1].rows.length!==out.linkCount)throw Error('Số link báo cáo chưa hợp lệ.');
  wb.Props={Title:'Báo cáo Truyền thông Nội bộ',Subject:camp.name+' · '+month,Author:'Training Central'};if(!current())return;XLSX.writeFile(wb,'TienDoTruyenThong_'+month+'_'+String(camp.id).replace(/[^A-Za-z0-9_-]/g,'')+'.xlsx');
  const missing=(out.warnings?.missingEmployees||0)+(out.warnings?.missingPrograms||0);mediaReportExportMessage_('Đã xuất '+out.pgCount+' PG và '+out.linkCount+' bài đăng · 2 sheet.'+(missing?' '+missing+' PG chưa có dữ liệu chương trình từ nguồn; các ô số liệu để trống.':''));
 }catch(error){if(same())mediaReportExportMessage_(error.message||'Chưa xuất được Excel truyền thông.',true);}
 finally{mediaReportExportBusy_=false;const b=document.getElementById('mediaReportExportBtn');if(b){b.disabled=!isAdmin()&&!isTrainer();b.textContent='⇩ Xuất Excel truyền thông (2 sheet)';}if(same()&&!current())mediaReportExportMessage_('Bộ lọc hoặc danh sách PG vừa thay đổi. Hãy bấm xuất lại theo bảng hiện tại.',true);}
}
