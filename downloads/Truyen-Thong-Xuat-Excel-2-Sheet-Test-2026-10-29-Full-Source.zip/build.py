from pathlib import Path
import hashlib,json
r=Path(__file__).parent;s=(r/'before.html').read_text();assert hashlib.sha256(s.encode()).hexdigest()=='6e05e58cb432d6b69942e7bd338b767622aa889de03cbc86bf40d9b61f6e7462'
old='''  box.innerHTML = `
    <div class="scope-filters" style="flex-wrap:wrap;gap:10px;margin-bottom:6px;justify-content:space-between;">'''
new='''  box.innerHTML = `
    <div class="media-report-export-toolbar"><button type="button" class="secondary" id="mediaReportExportBtn" ${mediaReportExportBusy_||(!isAdmin()&&!isTrainer())?'disabled':''}>${mediaReportExportBusy_?'Đang xuất…':'⇩ Xuất Excel truyền thông (2 sheet)'}</button><span id="mediaReportExportMsg" role="status">Xuất toàn bộ PG Đang làm khớp bộ lọc, gồm đã và chưa hoàn thành; không giới hạn trang đang xem.</span></div>
    <div class="scope-filters" style="flex-wrap:wrap;gap:10px;margin-bottom:6px;justify-content:space-between;">'''
assert s.count(old)==1;s=s.replace(old,new)
old="  document.getElementById('mediaNotDoneSearchInput').addEventListener('input', ()=>{ mediaNotDonePage=1; renderMediaNotDoneRows_(); });"
assert s.count(old)==1;s=s.replace(old,"  document.getElementById('mediaReportExportBtn')?.addEventListener('click',exportMediaReportExcel_);\n"+old)
css='.media-report-export-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px;}.media-report-export-toolbar button{max-width:100%;}.media-report-export-toolbar span{font-size:11px;color:var(--muted);line-height:1.6;min-width:0;overflow-wrap:anywhere;}@media(max-width:700px){.media-report-export-toolbar{gap:6px;}.media-report-export-toolbar button{font-size:11px!important;}.media-report-export-toolbar span{font-size:10px;width:100%;}}'
marker='\n</body>\n</html>';assert s.count(marker)==1;s=s.replace(marker,'<style id="media-report-export-style-20261029">'+css+'</style><script id="media-report-export-script-20261029">\n'+(r/'media-export.js').read_text()+'\n</script>'+marker)
name='Dashboard-Test-2026-10-29-Truyen-Thong-Xuat-Excel-2-Sheet.html';b=s.encode()
for n in ['index.html',name]:(r/n).write_bytes(b)
m={'scope':'Test','date':'2026-10-29','filename':name,'bytes':len(b),'characters':len(s),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+bytes([0])+b).hexdigest(),'base_commit':'27b761af239877862283d8bc3f96ce491a8a0718','function':'otraining-media-export-test','main_changed':False,'existing_functions_changed':False,'schema_changed':False,'secrets_changed':False,'business_data_changed':False}
(r/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));print(json.dumps(m,ensure_ascii=False))
