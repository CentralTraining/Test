const CHANNEL_HASHTAG_KEY_='channelHashtagWatchlist:v1';
let channelHashtags_={owner:'',tags:[],active:'',loaded:false,loading:false,saving:false,busy:false,
 cache:new Map(),errors:new Map(),error:'',progress:'',run:0,requestContext:'',page:1};
function channelHashtagReset_(){
 const run=channelHashtags_.run+1;
 channelHashtags_={owner:channelOwner_(),tags:[],active:'',loaded:false,loading:false,saving:false,busy:false,
  cache:new Map(),errors:new Map(),error:'',progress:'',run,requestContext:'',page:1};
}
function channelHashtagCurrent_(){
 const period=ChannelModel.period(channelView_.filters),f=channelView_.filters;
 const list=(channelView_.data?.trainers||channelInitial_()).filter(t=>(!f.region||t.region===f.region)&&(!f.trainer||String(t.id)===f.trainer));
 return {period,report:ChannelModel.report(list,period)};
}
function channelHashtagCacheKey_(t,period){return JSON.stringify([String(t.id),period.from,period.to,t.syncedAt||'']);}
function channelHashtagContextKey_(report,period){return JSON.stringify([period.from,period.to,report.rows.map(t=>[String(t.id),t.syncedAt||'',t.known,t.connected])]);}
function channelHashtagRedraw_(){
 const root=document.getElementById('channelTool');
 if(!root?.querySelector('#channelHashtagPanel')||!['admin','trainer'].includes(session?.role))return;
 const current=channelHashtagCurrent_();channelDrawHashtags_(root,current.report,current.period);
}
async function channelHashtagLoad_(){
 if(channelHashtags_.loading||channelHashtags_.loaded)return;
 const state=channelHashtags_,owner=channelOwner_();state.loading=true;
 try{
  const saved=await dbGetMulti([CHANNEL_HASHTAG_KEY_]);
  if(state!==channelHashtags_||owner!==channelOwner_())return;
  if(!Object.prototype.hasOwnProperty.call(saved,CHANNEL_HASHTAG_KEY_))throw Error('Chưa đọc được danh sách hashtag. Hãy thử tải lại.');
  const value=saved[CHANNEL_HASHTAG_KEY_];
  if(value!==null&&!Array.isArray(value))throw Error('Danh sách hashtag đã lưu không đúng định dạng.');
  state.tags=ChannelHashtagModel.parse(value||[]);state.loaded=true;state.error='';
 }catch(error){if(state===channelHashtags_&&owner===channelOwner_())state.error=error.message;}
 finally{if(state===channelHashtags_&&owner===channelOwner_()){state.loading=false;channelHashtagRedraw_();}}
}
async function channelHashtagSave_(add=[],remove=''){
 if(!isAdmin()||channelHashtags_.saving||!channelHashtags_.loaded)return;
 const state=channelHashtags_,owner=channelOwner_();state.saving=true;state.error='';channelHashtagRedraw_();
 try{
  const saved=await dbGetMulti([CHANNEL_HASHTAG_KEY_]);
  if(state!==channelHashtags_||owner!==channelOwner_()||!isAdmin())return;
  if(!Object.prototype.hasOwnProperty.call(saved,CHANNEL_HASHTAG_KEY_))throw Error('Chưa đọc được danh sách đã lưu; chưa thay đổi hashtag.');
  const old=saved[CHANNEL_HASHTAG_KEY_];if(old!==null&&!Array.isArray(old))throw Error('Danh sách hashtag đã lưu không đúng định dạng.');
  const next=ChannelHashtagModel.parse([...ChannelHashtagModel.parse(old||[]).filter(tag=>tag!==remove),...add]);
  if(!await dbSet(CHANNEL_HASHTAG_KEY_,next))throw Error('Chưa lưu được hashtag. Hãy thử lại.');
  if(state!==channelHashtags_||owner!==channelOwner_())return;
  state.tags=next;state.active=add[0]|| (next.includes(state.active)?state.active:'');state.page=1;
 }catch(error){if(state===channelHashtags_&&owner===channelOwner_())state.error=error.message;}
 finally{if(state===channelHashtags_&&owner===channelOwner_()){state.saving=false;channelHashtagRedraw_();}}
}
async function channelHashtagRefresh_(){
 if(channelHashtags_.busy||channelView_.busy||!channelHashtags_.tags.length)return;
 const state=channelHashtags_,owner=channelOwner_(),{report,period}=channelHashtagCurrent_();
 const context=channelHashtagContextKey_(report,period),run=++state.run;
 const allowed=()=>state===channelHashtags_&&owner===channelOwner_()&&run===state.run&&currentTabId_()==='extensions'&&channelHashtagContextKey_(channelHashtagCurrent_().report,channelHashtagCurrent_().period)===context;
 state.busy=true;state.requestContext=context;state.errors.clear();state.error='';state.page=1;
 const list=report.rows.filter(t=>t.known&&t.connected&&t.sandboxReady!==false&&!t.needsSandboxReconnect);
 let cursor=0,done=0;
 state.progress=list.length?'Đang đọc nội dung video từ TikTok…':'Chưa có kênh đã đồng bộ trong phạm vi. Hãy Đồng bộ TikTok trước.';
 channelHashtagRedraw_();
 async function worker(){
  while(cursor<list.length&&allowed()){
   const t=list[cursor++],items=[];let offset=0,complete=false,readAt=null;
   try{
    for(let page=0;page<=1000&&allowed();page++){
     const out=await channelApi_('hashtag_videos',{trainerId:String(t.id),from:period.from,to:period.to,offset,snapshotAt:t.syncedAt||undefined});
     if(!allowed())return;
     if(out.trainerId!==String(t.id)||out.from!==period.from||out.to!==period.to||!Array.isArray(out.videos))throw Error('Dữ liệu hashtag chưa đúng phạm vi đang xem.');
     const seen=new Set(items.map(v=>String(v.id)));
     for(const video of out.videos)if(!seen.has(String(video.id))){items.push({...video,trainerId:String(t.id),trainerName:t.name,region:t.region,handle:out.handle||t.handle});seen.add(String(video.id));}
     readAt=out.readAt||readAt;
     if(out.complete){complete=true;break;}
     if(!Number.isSafeInteger(out.nextOffset)||out.nextOffset<=offset)throw Error('TikTok chưa đọc xong trang video. Hãy thử lại.');
     offset=out.nextOffset;
    }
    if(!allowed())return;
    if(!complete)throw Error('Kênh còn video chưa đọc xong. Hãy chọn khoảng ngày nhỏ hơn rồi thử lại.');
    state.cache.set(channelHashtagCacheKey_(t,period),{items,complete:true,readAt:readAt||new Date().toISOString()});
    while(state.cache.size>52)state.cache.delete(state.cache.keys().next().value);
   }catch(error){if(allowed())state.errors.set(String(t.id),error.message||'Chưa đọc được nội dung video.');}
   if(allowed()){done++;state.progress='Đã kiểm tra '+done+'/'+list.length+' kênh trong phạm vi.';channelHashtagRedraw_();}
  }
 }
 try{await Promise.all([worker(),worker()]);}
 finally{if(state===channelHashtags_&&owner===channelOwner_()&&run===state.run){state.busy=false;channelHashtagRedraw_();}}
}
function channelDrawHashtags_(root,report,period){
 const panel=root.querySelector('#channelHashtagPanel');if(!panel)return;
 if(channelHashtags_.owner!==channelOwner_())channelHashtagReset_();
 const state=channelHashtags_,e=channelEscape_,num=channelNumber_,compact=channelMetricCompact_;
 const context=channelHashtagContextKey_(report,period);
 if(state.requestContext&&state.requestContext!==context){state.run++;state.busy=false;state.errors.clear();state.progress='Bộ lọc đã thay đổi. Bấm Cập nhật hashtag để đọc kỳ mới.';}
 state.requestContext=context;
 const entries=report.rows.map(t=>({t,cache:state.cache.get(channelHashtagCacheKey_(t,period))}));
 const items=entries.flatMap(({cache})=>cache?.items||[]),known=items.filter(v=>v.captionKnown).length;
 const expected=report.rows.filter(t=>t.known).reduce((n,t)=>n+t.videos.length,0);
 const checked=entries.filter(({cache})=>cache?.complete).length;
 const ready=known>0||(checked>0&&expected===0&&report.rows.every(t=>t.known));
 const stats=ChannelHashtagModel.report(items,state.tags,state.active,period),v=stats.totals;
 const metrics=[['Video khớp',v.videos],['Trainer tham gia',v.trainers],['Lượt xem',v.views],['Lượt thích',v.likes],['Bình luận',v.comments],['Chia sẻ',v.shares]];
 const readTimes=entries.map(({cache})=>cache?.readAt).filter(Boolean).sort();
 const coverage='Đã đọc nội dung '+known+'/'+expected+' video đã đồng bộ · đã kiểm tra '+checked+'/'+report.rows.length+' kênh';
 const totalPages=Math.max(1,Math.ceil(stats.videos.length/10));state.page=Math.max(1,Math.min(state.page,totalPages));
 const videos=stats.videos.slice((state.page-1)*10,state.page*10);
 panel.innerHTML=`<div class="channel-hashtag-heading"><div><h3><span aria-hidden="true">#</span> Tracking hashtag</h3><p>Trong các kênh Trainer đã kết nối · Dùng cùng bộ lọc thời gian, khu vực và Trainer phía trên</p></div><button type="button" class="secondary" id="channelHashtagRefresh" ${state.busy||channelView_.busy||!state.tags.length?'disabled':''}>${state.busy?'Đang cập nhật…':'↻ Cập nhật hashtag'}</button></div>
  ${isAdmin()?`<form id="channelHashtagForm" class="channel-hashtag-form"><label for="channelHashtagInput">Hashtag theo dõi</label><div><input id="channelHashtagInput" type="text" maxlength="2200" placeholder="Nhập #hashtag, cách nhau bằng dấu phẩy" autocomplete="off" ${!state.loaded||state.saving?'disabled':''}><button type="submit" class="secondary" ${!state.loaded||state.saving?'disabled':''}>${state.saving?'Đang lưu…':'＋ Thêm hashtag'}</button></div></form>`:''}
  ${state.loading?'<p class="channel-note">Đang tải danh sách hashtag…</p>':''}
  ${state.error?`<div class="channel-hashtag-error" role="alert">${e(state.error)}${!state.loaded?'<button type="button" class="secondary" id="channelHashtagRetry">Tải lại</button>':''}</div>`:''}
  <div class="channel-hashtag-tags" aria-label="Chọn hashtag">${state.tags.length?`<button type="button" data-channel-hashtag="" aria-pressed="${!state.active}">Tất cả hashtag</button>`:''}${stats.tags.map(tag=>`<span><button type="button" data-channel-hashtag="${e(tag.tag)}" aria-pressed="${state.active===tag.tag}">#${e(tag.tag)} <small>${ready?num(tag.videos):'—'}</small></button>${isAdmin()?`<button type="button" class="channel-hashtag-remove" data-channel-hashtag-remove="${e(tag.tag)}" aria-label="Bỏ theo dõi hashtag ${e(tag.tag)}" ${state.saving?'disabled':''}>×</button>`:''}</span>`).join('')}</div>
  ${!state.tags.length?`<div class="channel-empty">${state.loaded?(isAdmin()?'Thêm hashtag để theo dõi video và tương tác của đội ngũ.':'Admin chưa thêm hashtag để theo dõi.'):'Chưa tải được danh sách hashtag.'}</div>`:`
  <div class="channel-hashtag-status" role="status" aria-live="polite"><span>${e(state.progress|| (ready?coverage:'Bấm Cập nhật hashtag để đọc nội dung video trong kỳ.'))}</span>${state.progress&&ready?`<small>${e(coverage)}</small>`:''}${readTimes.length?`<small>Lần đọc gần nhất: ${e(channelFollowerDate_(readTimes.at(-1)))}</small>`:''}</div>
  ${state.errors.size?`<details class="channel-hashtag-errors"><summary>${state.errors.size} kênh chưa đọc được trong lượt này</summary><ul>${[...state.errors].map(([id,message])=>`<li>${e(report.rows.find(t=>String(t.id)===id)?.name||'Kênh')}: ${e(message)}</li>`).join('')}</ul></details>`:''}
  <div class="channel-hashtag-stats">${metrics.map(([label,value])=>`<div><span>${label}</span><strong title="${ready?num(value):'Chưa đọc dữ liệu'}">${ready?compact(value):'—'}</strong></div>`).join('')}</div>
  <p class="channel-hashtag-note">Tổng chỉ tính video đã đọc được và khớp hashtag. Một video mang nhiều hashtag chỉ tính một lần trong tổng. View/like/bình luận/share là tổng hiện tại của video đăng trong kỳ, không phải số tăng riêng trong kỳ.</p>
  <h4>Theo Trainer</h4><div class="channel-hashtag-trainers" role="table" aria-label="Chỉ số hashtag theo Trainer"><div class="channel-hashtag-row channel-hashtag-head" role="row"><span>Trainer</span><span>Video</span><span>View</span><span>Like</span><span>Bình luận</span><span>Share</span></div>${entries.map(({t,cache})=>{
   const own=stats.videos.filter(video=>video.trainerId===String(t.id)),total=ChannelHashtagModel.totals(own),read=cache?.items.filter(video=>video.captionKnown).length||0;
   const usable=cache&&(read>0||cache.items.length===0);
   return `<div class="channel-hashtag-row" role="row"><div><strong>${e(channelShort_(t.name))}</strong><small>${e(t.region)} · ${cache?read+'/'+cache.items.length+' video đã đọc':'Chưa cập nhật hashtag'}</small></div>${[['Video',total.videos],['View',total.views],['Like',total.likes],['Bình luận',total.comments],['Share',total.shares]].map(([label,value])=>`<div role="cell" title="${usable?num(value):'Chưa đọc dữ liệu'}"><small>${label}</small><b>${usable?compact(value):'—'}</b></div>`).join('')}</div>`;
  }).join('')||'<div class="channel-empty">Chưa có Trainer trong phạm vi đang xem.</div>'}</div>
  <div class="channel-hashtag-video-heading"><h4>Video khớp hashtag <span>${ready?num(stats.videos.length):'—'}</span></h4><span>${e(state.active?'#'+state.active:'Tất cả hashtag đang theo dõi')}</span></div>
  <div class="channel-hashtag-videos">${videos.map(video=>`<article><a href="https://www.tiktok.com/@${encodeURIComponent(video.handle||'')}/video/${encodeURIComponent(video.id)}" target="_blank" rel="noopener noreferrer">${e(video.title||video.caption||'Video TikTok')}</a><small>${e(video.trainerName)} · ${e(new Date(video.createdAt).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'}))}</small><div class="channel-hashtag-video-tags">${video.matched.map(tag=>`<span>#${e(tag)}</span>`).join('')}</div><div class="channel-hashtag-video-metrics">${[['View',video.views],['Like',video.likes],['Bình luận',video.comments],['Share',video.shares]].map(([label,value])=>`<span>${label} <b title="${num(value)}">${compact(value)}</b></span>`).join('')}</div></article>`).join('')||`<div class="channel-empty">${ready?'Chưa tìm thấy video khớp hashtag trong phần nội dung đã đọc.':'Chưa cập nhật dữ liệu hashtag trong kỳ này.'}</div>`}</div>
  ${stats.videos.length>10?`<div class="channel-hashtag-pagination"><span>${(state.page-1)*10+1}–${Math.min(state.page*10,stats.videos.length)} / ${stats.videos.length} video</span><button type="button" class="secondary" data-channel-hashtag-page="${state.page-1}" ${state.page===1?'disabled':''}>‹</button><span>${state.page}/${totalPages}</span><button type="button" class="secondary" data-channel-hashtag-page="${state.page+1}" ${state.page===totalPages?'disabled':''}>›</button></div>`:''}
  <p class="channel-hashtag-note">Phạm vi: video công khai đã đồng bộ của các kênh đang chọn và nội dung TikTok API trả về; không tìm kiếm toàn TikTok. Các kênh chưa đọc được không bị coi là đã hoàn tất.</p>`}`;
 panel.querySelector('#channelHashtagRefresh')?.addEventListener('click',channelHashtagRefresh_);
 panel.querySelector('#channelHashtagRetry')?.addEventListener('click',()=>{state.error='';channelHashtagLoad_();});
 panel.querySelector('#channelHashtagForm')?.addEventListener('submit',async event=>{
  event.preventDefault();if(!isAdmin())return;
  try{const tags=ChannelHashtagModel.parse(panel.querySelector('#channelHashtagInput').value);if(!tags.length)throw Error('Nhập ít nhất một hashtag.');await channelHashtagSave_(tags);}
  catch(error){state.error=error.message;channelHashtagRedraw_();}
 });
 panel.querySelectorAll('[data-channel-hashtag]').forEach(button=>button.onclick=()=>{state.active=button.dataset.channelHashtag;state.page=1;channelHashtagRedraw_();});
 panel.querySelectorAll('[data-channel-hashtag-remove]').forEach(button=>button.onclick=()=>channelHashtagSave_([],button.dataset.channelHashtagRemove));
 panel.querySelectorAll('[data-channel-hashtag-page]').forEach(button=>button.onclick=()=>{state.page=Number(button.dataset.channelHashtagPage);channelHashtagRedraw_();});
 if(!state.loaded&&!state.loading&&!state.error)channelHashtagLoad_();
}
document.getElementById('logoutBtn').addEventListener('click',channelHashtagReset_);
