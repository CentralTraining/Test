// Hashtags remain accent-sensitive; case and full-width forms are normalized.
const ChannelHashtagModel=(()=>{
 const normalize=value=>String(value??'').normalize('NFKC').trim().replace(/^#+/u,'').toLocaleLowerCase('vi');
 function parse(value){
  const tokens=Array.isArray(value)?value:String(value||'').split(/[\s,;]+/u);
  const result=[];
  for(const token of tokens){
   if(!String(token).trim())continue;
   const tag=normalize(token);
   if(!tag||Array.from(tag).length>100||!/^[\p{L}\p{M}\p{N}_]+$/u.test(tag))throw Error('Hashtag chỉ gồm chữ, số và dấu gạch dưới; cách nhau bằng dấu phẩy hoặc khoảng trắng.');
   if(!result.includes(tag))result.push(tag);
  }
  if(result.length>20)throw Error('Theo dõi tối đa 20 hashtag cùng lúc.');
  return result;
 }
 function extract(caption){
  const text=String(caption||'').normalize('NFKC').replace(/https?:\/\/\S+/giu,'');
  return [...new Set([...text.matchAll(/#([\p{L}\p{M}\p{N}_]+)/gu)].map(m=>normalize(m[1])))];
 }
 function totals(videos){
  const sum=field=>videos.some(v=>!Number.isFinite(v[field]))?null:videos.reduce((n,v)=>n+v[field],0);
  return {videos:videos.length,trainers:new Set(videos.map(v=>String(v.trainerId))).size,
    views:sum('views'),likes:sum('likes'),comments:sum('comments'),shares:sum('shares')};
 }
 function report(items,tags,active,period){
  const watch=parse(tags),unique=new Map();
  for(const item of items){
   if(!item.captionKnown||!item.id||!Number.isFinite(Date.parse(item.createdAt)))continue;
   const day=new Date(Date.parse(item.createdAt)+7*3600000).toISOString().slice(0,10);
   if(day<period.from||day>period.to)continue;
   const found=extract(item.caption),matched=watch.filter(tag=>found.includes(tag));
   if(matched.length&&!unique.has(String(item.id)))unique.set(String(item.id),{...item,matched,day});
  }
  const all=[...unique.values()].sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt)||String(a.id).localeCompare(String(b.id)));
  const videos=active?all.filter(v=>v.matched.includes(normalize(active))):all;
  return {videos,totals:totals(videos),tags:watch.map(tag=>({tag,...totals(all.filter(v=>v.matched.includes(tag)))}))};
 }
 return {normalize,parse,extract,totals,report};
})();
