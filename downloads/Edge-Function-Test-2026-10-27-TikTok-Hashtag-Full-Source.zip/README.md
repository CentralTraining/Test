# Tracking hashtag TikTok — bản Test, 27/10/2026

Giao diện: Mở rộng → Xây kênh TikTok → Tracking hashtag, bên dưới biểu đồ nhịp đăng video.

1. Admin nhập hashtag cần theo dõi, có thể nhập nhiều hashtag cách nhau bằng dấu phẩy.
2. Bấm **Thêm hashtag** để lưu danh sách dùng chung cho đội ngũ.
3. Chọn tuần/tháng/khoảng ngày, khu vực và Trainer ở bộ lọc phía trên.
4. Bấm **Cập nhật hashtag**. Chọn một hashtag hoặc Tất cả hashtag để xem thống kê và video.

Trainer được đọc kết quả toàn đội trong phạm vi TikTok đã cho phép; chỉ Admin thêm hoặc bỏ hashtag khỏi danh sách chung.

Mỗi video khớp được tính một lần trong tổng, kể cả khi mang nhiều hashtag. Hashtag được khớp đầy đủ theo token, không phân biệt hoa/thường; dấu tiếng Việt được giữ nguyên. Thời gian lọc là ngày đăng video theo giờ Việt Nam. View/like/bình luận/share là tổng hiện tại do TikTok trả về của những video đăng trong kỳ.

Phạm vi là các video công khai đã đồng bộ từ những kênh được kết nối và nội dung TikTok API trả về. Đây không phải công cụ tìm kiếm toàn TikTok. Kênh chưa đọc được, video không còn được TikTok trả về hoặc chỉ số bị thiếu được ghi rõ; không tự coi dữ liệu thiếu là 0.

## Mã nguồn máy chủ

ZIP chứa đầy đủ `supabase/functions/trainer-channel-test/` và mọi file phụ thuộc, cùng cấu hình tên function. Giao diện HTML đầy đủ được cung cấp thành tệp tải riêng.

Function Test giữ `verify_jwt=false` như bản trước và tự xác thực tài khoản Dashboard bằng `access.ts`. Action mới `hashtag_videos` dùng quyền `video.list` đã có để đọc caption và chỉ số của tối đa 20 video trong một yêu cầu. Máy chủ chỉ đọc những video đã có trong snapshot của Trainer hợp lệ, có kiểm tra kỳ và mốc snapshot. Action này không ghi grant, không refresh token, không thay mốc follower và không thay callback.

Danh sách hashtag dùng key mới `channelHashtagWatchlist:v1` trong `kv_store`. Key được tạo khi Admin chủ động lưu hashtag; không yêu cầu đổi schema. Không cần thêm Secrets hoặc sửa ứng dụng TikTok.

`trainer-channel-api` dùng chung và `trainer-channel` Main không thay đổi trong bản Test này. Khi được yêu cầu chuyển lên Main, cần đưa nhánh đọc hashtag vào function Main cùng các helper tương ứng, giữ nguyên native owner routes và callback Main; không chép facade Test đè lên Main.

Không có Secrets, token, dữ liệu tài khoản hoặc dữ liệu Trainer thật trong gói mã nguồn này. Các kiểm thử sử dụng dữ liệu giả lập và không ghi lên hệ thống thật.
