# Xây kênh TikTok — giao diện gọn — Test 25/10/2026

- Chỉ thay giao diện trong `CentralTraining/Test/index.html`.
- Bỏ thẻ follower lớn phía trên. Bốn số tổng quan gồm Bài đăng, Tăng follow, Like, Share.
- Trên máy tính, giữ tỷ lệ hai khung 1,45 : 1: tiến độ bài đăng bên trái; Follow/Like/Share hiển thị đồng thời trong khung tương tác bên phải.
- Trên điện thoại, dùng một danh sách chung gồm Trainer và bốn chỉ số, tránh lặp hai danh sách Trainer và không cuộn ngang.
- Giữ biểu đồ nhịp đăng bên dưới. Logic chia ngày/nhóm 7 ngày và cách tính số bài không thay đổi; chiều cao trình bày được thu gọn.
- Quản lý kênh, cấp thêm quyền follower, mốc đầu kỳ và bảng chi tiết được đặt trong mục Quản lý kênh có thể mở ra. Lịch sử follower vẫn xem được khi bấm giá trị Follow.
- Thanh chốt tháng KPI chỉ ẩn khi xem Mở rộng, vẫn giữ trên các trang KPI. Tab con Xây kênh duy nhất được ẩn trên điện thoại để giảm phần trùng lặp.
- Không thay backend, Secrets, dữ liệu, cách tính follower/like/share, bộ nhắc KPI hoặc dashboard chính.

## Kiểm tra

Kiểm thử giao diện bằng dữ liệu giả ở 320×844, 390×844, 1440×900 và 1920×1080. Hai khung giữ tỷ lệ cũ trên desktop; desktop hiển thị phần tổng quan, hai bảng chỉ số và nhịp đăng trong chiều cao thử nghiệm. Mobile hiển thị cả bốn chỉ số cho 13 Trainer trong phần tổng quan của màn hình thử nghiệm. Không tràn ngang. Các thao tác lọc, quản lý, lịch sử, trợ giúp và phân quyền khu vực vẫn hoạt động.

## File lưu

`index.html` là toàn bộ HTML có thể lưu để dự phòng. `source/` chứa các module giao diện và mô hình tính toán được ghép vào HTML. `verification/` lưu kết quả kiểm thử; dữ liệu thử không phải số liệu của Trainer thực tế.

Mốc follower vẫn là 01/10/2026 theo chức năng đã triển khai trước đó. Bản giao diện này không tạo hoặc suy đoán số đầu kỳ còn thiếu.
