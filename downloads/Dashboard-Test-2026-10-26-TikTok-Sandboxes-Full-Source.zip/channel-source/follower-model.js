// Follower growth is measured between recorded observations, not reconstructed history.
const FollowerModel=(()=>{
 const baselineDate='2026-10-01';
 const day=at=>new Date(Date.parse(at)+7*3600000).toISOString().slice(0,10);
 const valid=p=>typeof p?.at==='string'&&Number.isFinite(Date.parse(p.at))&&Number.isSafeInteger(p.count)&&p.count>=0;
 function row(trainer,period){
  const raw=trainer.followers||{},map=new Map();
  for(const p of Array.isArray(raw.history)?raw.history:[]){if(valid(p)&&day(p.at)>=baselineDate&&day(p.at)<=period.to)map.set(p.at,{at:p.at,count:p.count,source:p.source||'tiktok_api'});}
  const observed=[...map.values()].sort((a,b)=>Date.parse(a.at)-Date.parse(b.at)),saved=raw.baseline;
  const baseline=saved?.date===baselineDate&&Number.isSafeInteger(saved.count)&&saved.count>=0?{date:baselineDate,dateOnly:true,count:saved.count,source:'admin_record'}:observed.find(p=>day(p.at)===baselineDate)||null;
  const points=baseline?.dateOnly&&period.to>=baselineDate?[baseline,...observed]:observed,first=baseline,last=observed[observed.length-1]||null;
  const current=Number.isSafeInteger(raw.current)&&raw.current>=0&&Number.isFinite(Date.parse(raw.asOf))?raw.current:null;
  const today=day(new Date().toISOString()),effectiveEnd=period.to<today?period.to:today;
  const comparable=!!baseline&&!!last&&period.to>=baselineDate&&period.from<=today&&(baseline.dateOnly||Date.parse(last.at)>Date.parse(baseline.at)),delta=comparable?last.count-baseline.count:null;
  return {...trainer,points,observed,first,last,baseline,comparable,delta,current,asOf:current===null?null:raw.asOf,
   growthPct:comparable&&first.count>0?Math.round(delta/first.count*1000)/10:null,
   partial:comparable&&day(last.at)<effectiveEnd,
   authorized:raw.authorized===true,status:raw.status||(!trainer.connected?'not_connected':'needs_authorization')};
 }
 function report(trainers,period){
  const rows=trainers.map(t=>row(t,period)),currentKnown=rows.filter(t=>t.current!==null),comparable=rows.filter(t=>t.comparable),complete=rows.length>0&&comparable.length===rows.length;
  const start=comparable.reduce((n,t)=>n+t.first.count,0),end=comparable.reduce((n,t)=>n+t.last.count,0);
  return {rows,currentKnown:currentKnown.length,comparable:comparable.length,complete,
   current:currentKnown.length?currentKnown.reduce((n,t)=>n+t.current,0):null,
   delta:complete?end-start:null,growthPct:complete&&start>0?Math.round((end-start)/start*1000)/10:null};
 }
 return {row,report,day,baselineDate};
})();
