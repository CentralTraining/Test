function channelReport_(trainers,period){
 const source=WebTrackingModel.source(trainers,channelView_.filters.source);
 const result=source==='web_tracking'?WebTrackingModel.report(trainers,period,ChannelModel.goal,ChannelModel.add):ChannelModel.report(trainers,period);
 result.source=source;return result;
}
function channelSourceControl_(source){const selected=channelView_.filters.source;return `<label class="channel-source-control">Nguồn <select id="channelSource" aria-label="Nguồn số liệu Xây kênh"><option value="auto" ${selected==='auto'?'selected':''}>Tự động · ${source==='web_tracking'?'Web tracking':'TikTok API'}</option><option value="tiktok_api" ${selected==='tiktok_api'?'selected':''}>TikTok API</option><option value="web_tracking" ${selected==='web_tracking'?'selected':''}>Web tracking</option></select></label>`;}
function channelApplyScan_(trainer,out){
 if(!channelView_.data)return;
 channelView_.scanResults.set(String(trainer.id),{handle:trainer.handle,result:out});
 channelView_.request++;channelView_.filters.source='auto';
 const period=ChannelModel.period(channelView_.filters);
 channelView_.data={...channelView_.data,trainers:channelView_.data.trainers.map(t=>String(t.id)===String(trainer.id)&&t.handle===trainer.handle?WebTrackingModel.applyScan(t,out,period):t)};
 channelDraw_();
}
function channelBindManual_(root){
 root.querySelector('#channelManualUpdate')?.addEventListener('click',channelManualDialog_);
 root.querySelector('#channelSource')?.addEventListener('change',event=>{channelView_.filters.source=event.target.value;channelDraw_();});
}
function channelManualHistory_(trainer){
 const e=channelEscape_,n=channelNumber_,t=trainer.webTracking||{},signed=value=>value===null||value===undefined?'—':(value>0?'+':'')+n(value),base=trainer.followers?.baseline;
 const ov=channelDialog_(trainer.name+' · Lịch sử quét web',`<p class="channel-note">Tổng kênh tại lần quét gần nhất: ${e(channelFollowerDate_(t.asOf))}. Mốc Admin 01/10/2026: ${base?n(base.count)+' follower':'chưa có'}.</p><div class="channel-manual-values"><span><small>Follower hiện tại</small><b>${n(t.current?.followers)}</b></span><span><small>Tổng video kênh</small><b>${n(t.current?.videos)}</b></span><span><small>Tổng like kênh</small><b>${n(t.current?.likes)}</b></span></div><p class="channel-note">Bảng dưới là phần tăng/giảm ghi nhận trong kỳ đang chọn. Quét lại cùng ngày cập nhật mốc cuối, không cộng trùng; ngày không quét không được tự dựng số liệu.</p><div class="channel-manual-history">${(t.days||[]).map(d=>`<div class="channel-manual-history-row"><strong>${e(d.day.split('-').reverse().join('/'))}</strong><span>Follower ${signed(d.growth.followers)}</span><span>Video ${signed(d.growth.videos)}</span><span>Like ${signed(d.growth.likes)}</span><small>${d.scans} lượt quét · ${e(channelFollowerDate_(d.lastAt))}</small></div>`).join('')||'<p>Chưa có lượt quét trong kỳ này.</p>'}</div>`);
 ov.querySelector('.channel-dialog').classList.add('channel-manual-dialog');
}
async function channelManualDialog_(){
 if(channelView_.busy)return;
 const owner=channelOwner_(),f=channelView_.filters,e=channelEscape_,n=channelNumber_;
 const list=(channelView_.data?.trainers||[]).filter(t=>(!f.region||t.region===f.region)&&(!f.trainer||String(t.id)===f.trainer)&&t.handle);
 if(!list.length){channelMessage_('Chưa có kênh được gán trong bộ lọc hiện tại. Nhờ Admin gán đúng kênh trước.',true);return;}
 const selected=new Set(list.map(t=>String(t.id))),results=new Map();let running=false,cancelled=false;
 const ov=channelDialog_('Cập nhật tiến độ thủ công',`<div class="channel-manual-intro">Quét số liệu từ web tracking cho kênh đã gán. Mốc Admin giữ nguyên; các lần quét ghi nhận tăng trưởng theo ngày Việt Nam.</div><div class="channel-manual-upload"><label>File mẫu có cột Url<input type="file" id="channelManualFile" accept=".xlsx,.xls,.csv"></label><button type="button" class="secondary" id="channelManualTemplate">Tải mẫu</button></div><p class="channel-note">Không bắt buộc chọn file nếu danh sách dưới đây đã đúng. File chỉ dùng để chọn kênh đã gán, không thay mốc hoặc ghép Trainer theo thứ tự dòng.</p><div class="channel-manual-tools"><button type="button" class="secondary" id="channelManualAll">Chọn tất cả</button><button type="button" class="secondary" id="channelManualNone">Bỏ chọn</button><span id="channelManualSelection"></span></div><div id="channelManualProgress" class="channel-manual-progress" role="status" aria-live="polite">Sẵn sàng quét. Lần đầu làm mốc cho chỉ số chưa có mốc cũ; không cộng tổng video đã có thành bài đăng hôm nay.</div><div class="channel-manual-results" id="channelManualResults"></div><div class="channel-manual-actions"><button type="button" class="primary" id="channelManualRun">Quét và cập nhật</button><button type="button" class="secondary" id="channelManualStop" disabled>Dừng lượt còn lại</button><button type="button" class="secondary" id="channelManualView">Xem tiến độ</button></div><p class="channel-note">API hiện có Follower, Like và số Video toàn kênh. View/Share chưa có dữ liệu. Phần tăng được ghi vào ngày quét; không suy ra ngày đăng thực tế.</p>`);
 ov.querySelector('.channel-dialog').classList.add('channel-manual-dialog');
 const box=ov.querySelector('#channelManualResults'),progress=ov.querySelector('#channelManualProgress');
 const signed=value=>value===null||value===undefined?'—':(value>0?'+':'')+n(value);
 function draw(){
  ov.querySelector('#channelManualSelection').textContent='Đã chọn '+selected.size+'/'+list.length+' kênh';
  box.innerHTML=list.map(t=>{
   const r=results.get(String(t.id)),current=r?.current||t.webTracking?.current,delta=r?.growth;
   return `<div class="channel-manual-row"><label class="channel-manual-name"><input type="checkbox" data-manual-trainer="${e(t.id)}" ${selected.has(String(t.id))?'checked':''} ${running?'disabled':''}><span><strong>${e(t.name)}</strong><small>@${e(t.handle)}</small></span></label><div class="channel-manual-values"><span><small>Follower</small><b>${n(current?.followers)}</b></span><span><small>Video kênh</small><b>${n(current?.videos)}</b></span><span><small>Like kênh</small><b>${n(current?.likes)}</b></span></div><div class="channel-manual-outcome ${r?.error?'error':''}">${r?.error?e(r.error):r?`Đã lưu · Tăng hôm nay: F ${signed(delta?.followers)} · V ${signed(delta?.videos)} · L ${signed(delta?.likes)}`:t.webTracking?.asOf?'Quét gần nhất: '+e(channelFollowerDate_(t.webTracking.asOf)):'Chưa quét web'}</div></div>`;
  }).join('');
  box.querySelectorAll('[data-manual-trainer]').forEach(input=>input.onchange=()=>{if(input.checked)selected.add(input.dataset.manualTrainer);else selected.delete(input.dataset.manualTrainer);ov.querySelector('#channelManualSelection').textContent='Đã chọn '+selected.size+'/'+list.length+' kênh';});
 }
 ov.querySelector('#channelManualAll').onclick=()=>{if(running)return;list.forEach(t=>selected.add(String(t.id)));draw();};
 ov.querySelector('#channelManualNone').onclick=()=>{if(running)return;selected.clear();draw();};
 ov.querySelector('#channelManualTemplate').onclick=()=>{const book=XLSX.utils.book_new();XLSX.utils.book_append_sheet(book,XLSX.utils.aoa_to_sheet([['Url'],['https://www.tiktok.com/@ten_kenh']]),'Template');XLSX.writeFile(book,'MediaTracker_Kenh_Template.xlsx');};
 ov.querySelector('#channelManualFile').onchange=async event=>{
  if(running)return;
  try{
   const file=event.target.files[0];if(!file)return;if(file.size>5*1024*1024)throw Error('File tối đa 5 MB.');
   const book=XLSX.read(await file.arrayBuffer(),{type:'array'}),rows=XLSX.utils.sheet_to_json(book.Sheets[book.SheetNames[0]],{header:1,defval:'',raw:true});
   const parsed=WebTrackingModel.parseRows(rows,list);selected.clear();parsed.ids.forEach(id=>selected.add(id));draw();
   progress.textContent=`Đã đọc ${parsed.unique} URL; khớp ${parsed.ids.length} kênh trong phạm vi.${parsed.issues.length?' '+parsed.issues.length+' dòng trùng, không hợp lệ hoặc chưa khớp bị bỏ qua.':''} Chưa quét và chưa thay đổi dữ liệu.`;
  }catch(error){progress.textContent=error.message;}
 };
 ov.querySelector('#channelManualStop').onclick=()=>{cancelled=true;progress.textContent='Sẽ dừng sau kênh đang quét; các kênh đã lưu được giữ nguyên.';};
 ov.querySelector('#channelManualView').onclick=()=>{if(!running)ov.remove();};
 ov.querySelector('#channelManualRun').onclick=async()=>{
  if(running||!selected.size)return;
  const targets=list.filter(t=>selected.has(String(t.id)));running=true;cancelled=false;channelView_.busy=true;let done=0,failed=0;
  ov.querySelectorAll('button:not(.channel-close),input').forEach(el=>el.disabled=true);ov.querySelector('#channelManualStop').disabled=false;draw();
  try{
   for(const t of targets){
    if(cancelled||!ov.isConnected||owner!==channelOwner_())break;
    progress.textContent='Đang quét '+t.name+' · '+(done+failed+1)+'/'+targets.length+'…';
    try{const out=await channelApi_('manual_scan',{trainerId:t.id});results.set(String(t.id),out);channelApplyScan_(t,out);done++;}
    catch(error){results.set(String(t.id),{error:error.message});failed++;}
    if(ov.isConnected&&owner===channelOwner_())draw();
   }
   if(owner===channelOwner_()){
    if(done)channelView_.filters.source='auto';
    let reloadError=false;try{await channelLoad_(false);}catch{reloadError=true;}
    channelView_.busy=false;channelDraw_();
    const message=`Đã lưu ${done}/${targets.length} kênh${done?' và cập nhật bảng tiến độ':''}.${failed?' '+failed+' kênh chưa lấy được; giữ dữ liệu cũ.':''}${cancelled?' Đã dừng các lượt còn lại.':''}${reloadError?' Chưa tải lại được toàn bộ danh sách; bảng đang giữ các kết quả quét vừa lưu.':''}`;
    if(ov.isConnected)progress.textContent=message;
    channelMessage_(message,failed>0);
   }
  }catch(error){if(ov.isConnected)progress.textContent=error.message;}
  finally{
   running=false;if(owner===channelOwner_())channelView_.busy=false;
   if(ov.isConnected){ov.querySelectorAll('button:not(.channel-close),input').forEach(el=>el.disabled=false);ov.querySelector('#channelManualStop').disabled=true;draw();}
  }
 };
 draw();
}
