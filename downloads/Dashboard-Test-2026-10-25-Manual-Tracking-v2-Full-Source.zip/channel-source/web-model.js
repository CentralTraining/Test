// Pure client calculations. A scan date is an observation date, never a post date.
const WebTrackingModel=(()=>{
 function profile(value){
  const url=new URL(String(value||'').trim());
  if(url.protocol!=='https:'||!['www.tiktok.com','tiktok.com','m.tiktok.com'].includes(url.hostname)||url.port||url.username||url.password)throw Error('Dùng link kênh TikTok dạng https://www.tiktok.com/@tenkenh.');
  const match=url.pathname.match(/^\/@([a-zA-Z0-9._]{2,40})\/?$/);
  if(!match)throw Error('File cần link kênh TikTok, không dùng link từng video.');
  return match[1].toLowerCase();
 }
 function parseRows(rows,trainers){
  if(!Array.isArray(rows)||!rows.length)throw Error('File chưa có dữ liệu.');
  const headers=rows[0].map(v=>String(v??'').trim().toLowerCase()),column=headers.indexOf('url');
  if(column<0)throw Error('Không tìm thấy cột Url theo file mẫu.');
  if(rows.length>201)throw Error('Mỗi file tối đa 200 dòng kênh.');
  const byHandle=new Map(trainers.filter(t=>t.handle).map(t=>[t.handle.toLowerCase(),String(t.id)])),seen=new Set(),ids=[],issues=[];
  for(let i=1;i<rows.length;i++){
   const value=rows[i]?.[column];if(value===null||value===undefined||String(value).trim()==='')continue;
   let handle;try{handle=profile(value);}catch{issues.push({row:i+1,kind:'invalid_url'});continue;}
   if(seen.has(handle)){issues.push({row:i+1,kind:'duplicate'});continue;}seen.add(handle);
   const id=byHandle.get(handle);if(id)ids.push(id);else issues.push({row:i+1,kind:'not_in_scope'});
  }
  if(!ids.length)throw Error('Chưa có URL nào khớp kênh đã gán trong phạm vi. Nhờ Admin kiểm tra tên kênh; không ghép theo thứ tự dòng.');
  return {ids,issues,unique:seen.size};
 }
 function source(trainers,selected){return selected==='web_tracking'||selected==='tiktok_api'?selected:trainers.some(t=>t.webTracking?.ready)?'web_tracking':'tiktok_api';}
 function applyScan(trainer,scan,period){
  if(String(scan?.trainerId)!==String(trainer.id)||!scan.ready||!scan.current||!Number.isFinite(Date.parse(scan.asOf)))return trainer;
  const old=trainer.webTracking||{};
  if(Date.parse(old.asOf)>Date.parse(scan.asOf))return trainer;
  const map=new Map((old.days||[]).map(d=>[d.day,d]));
  for(const d of scan.days||[]){const before=map.get(d.day);if(!before||Date.parse(d.lastAt)>=Date.parse(before.lastAt))map.set(d.day,d);}
  const days=[...map.values()].filter(d=>d.day>=period.from&&d.day<=period.to).sort((a,b)=>a.day.localeCompare(b.day));
  const growth=days.length?days.reduce((sum,d)=>{for(const k of ['followers','videos','likes'])sum[k]+=d.growth[k];return sum;},{followers:0,videos:0,likes:0}):null;
  const history=new Map((trainer.webFollowers?.history||[]).map(p=>[p.at,p]));
  for(const d of scan.days||[])history.set(d.lastAt,{at:d.lastAt,count:d.current.followers,source:'web_tracking'});
  return {...trainer,webTracking:{...old,...scan,startedAt:old.startedAt||scan.startedAt,days,growth},webFollowers:{...(trainer.webFollowers||trainer.followers),baseline:trainer.followers?.baseline,history:[...history.values()].sort((a,b)=>Date.parse(a.at)-Date.parse(b.at)),current:scan.current.followers,asOf:scan.asOf,status:'web_tracking'}};
 }
 function report(trainers,period,goal,add){
  const rows=trainers.map(t=>{
   const tracking=t.webTracking||{},known=!!tracking.growth,actual=known?tracking.growth.videos:null,target=goal(t,period);
   return {...t,known,target,actual,likes:tracking.ready?tracking.current?.likes??null:null,likeGrowth:known?tracking.growth.likes:null,channelVideos:tracking.ready?tracking.current?.videos??null:null,views:null,shares:null,pct:known&&target?Math.round(actual/target*1000)/10:null,videos:[],followers:t.webFollowers||{baseline:t.followers?.baseline,status:'awaiting_web_scan',history:[],current:null},dataSource:'web_tracking',partial:!!tracking.startedAt&&new Date(Date.parse(tracking.startedAt)+7*3600000).toISOString().slice(0,10)>period.from,syncedAt:tracking.asOf||null};
  });
  const totals=rows.reduce((a,t)=>({target:a.target+t.target,actual:a.actual+(t.actual||0),likes:a.likes+(t.likes||0),likeGrowth:a.likeGrowth+(t.likeGrowth||0),currentKnown:a.currentKnown+Number(t.webTracking?.ready),shares:0,known:a.known+Number(t.known)}),{target:0,actual:0,likes:0,likeGrowth:0,currentKnown:0,shares:0,known:0});
  const size=period.days>35?7:1,bins=[];
  for(let from=period.from;from<=period.to;from=add(from,size))bins.push({from,to:add(from,size-1)>period.to?period.to:add(from,size-1),count:0});
  for(const row of rows)for(const d of row.webTracking?.days||[]){const bin=bins.find(b=>d.day>=b.from&&d.day<=b.to);if(bin)bin.count+=d.growth.videos;}
  return {rows,totals,bins,source:'web_tracking',complete:rows.length>0&&totals.known===rows.length&&!rows.some(t=>t.partial)};
 }
 return {profile,parseRows,source,report,applyScan};
})();
