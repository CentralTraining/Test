// Trainer Hub standalone — deploy this complete file as trainer-hub. No imports required.
const HubAccess=(()=>{
// Account/config module. Private tables are read only by the server's service role.
const enc=new TextEncoder(),dec=new TextDecoder();
const clean=v=>String(v??'').trim();
const loginName=v=>clean(v).normalize('NFKC').toLowerCase();
const b64=v=>btoa(String.fromCharCode(...new Uint8Array(v))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const unb64=v=>Uint8Array.from(atob(v.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
class AccessError extends Error{constructor(message,status=401){super(message);this.status=status;}}
const fail=(message,status=400)=>{throw new AccessError(message,status);};
function appUrl(){
 const value=clean(Deno.env.get('APP_URL'));let u;try{u=new URL(value);}catch{fail('Chưa đặt APP_URL hợp lệ trên máy chủ.',503);}
 if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash)fail('APP_URL phải là URL HTTPS đầy đủ, không có query/hash.',503);
 return u.href;
}
async function database(path,options={}){
 const base=Deno.env.get('SUPABASE_URL'),secret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');if(!base||!secret)fail('Máy chủ chưa sẵn sàng.',503);
 const response=await fetch(base+'/rest/v1/trainer_hub_settings'+path,{...options,headers:{apikey:secret,Authorization:'Bearer '+secret,'Content-Type':'application/json',Prefer:'return=representation',...options.headers},signal:AbortSignal.timeout(12000)});
 if(!response.ok)fail('Không truy cập được bảng cấu hình. Kiểm tra đã chạy setup.sql.',503);
 return response.status===204?[]:await response.json();
}
async function readSetting(key){const rows=await database('?key=eq.'+encodeURIComponent(key)+'&select=key,value,version');return rows[0]||{key,value:key==='auth_users'?[]:{regions:[],trainers:[]},version:null};}
async function putSetting(record,value){
 const version=record.version===null?1:record.version+1;
 const body={key:record.key,value,version,updated_at:new Date().toISOString()};
 const rows=record.version===null?await database('',{method:'POST',headers:{Prefer:'resolution=ignore-duplicates,return=representation'},body:JSON.stringify(body)}):await database('?key=eq.'+encodeURIComponent(record.key)+'&version=eq.'+record.version,{method:'PATCH',body:JSON.stringify(body)});
 if(rows.length!==1)fail('Dữ liệu vừa được cập nhật ở phiên khác. Tải lại và thử lại.',409);return rows[0];
}
const digest=async value=>new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(value)));
async function passwordHash(password,saved=null){
 if(typeof password!=='string'||password.length<10||password.length>256)fail('Mật khẩu cần từ 10 đến 256 ký tự.');
 const parts=saved?.split('$'),salt=saved?unb64(parts[2]):crypto.getRandomValues(new Uint8Array(16)),iterations=120000;
 if(saved&&(parts.length!==4||parts[0]!=='pbkdf2_sha256'||parts[1]!==String(iterations)))return '';
 const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);
 const result=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations,hash:'SHA-256'},key,256);
 return 'pbkdf2_sha256$'+iterations+'$'+b64(salt)+'$'+b64(result);
}
async function equal(a,b){const x=await digest(String(a)),y=await digest(String(b));return x.every((v,i)=>v===y[i]);}
async function context(){const [users,config]=await Promise.all([readSetting('auth_users'),readSetting('config')]);if(!Array.isArray(users.value))fail('Dữ liệu tài khoản chưa hợp lệ.',503);return {users,config};}
function principal(user,config){
 if(!user||user.locked||!['admin','trainer'].includes(user.role)||!user.passHash)fail('Tài khoản không có quyền truy cập.',403);
 const trainer=(config.trainers||[]).find(t=>String(t.id)===String(user.trainerId));
 if(user.role==='trainer'&&!trainer?.region)fail('Tài khoản chưa được gán Trainer và khu vực.',403);
 return {userId:String(user.id),username:user.username,displayName:user.displayName,role:user.role,trainerId:user.role==='trainer'?String(trainer.id):'',region:user.role==='trainer'?trainer.region:''};
}
const binding=(p,user)=>JSON.stringify([p.role,p.region,p.trainerId,user.passHash]);
async function signingKey(){return crypto.subtle.importKey('raw',await digest('trainer-hub-session-v1:'+Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);}
async function issue(user,config){const p=principal(user,config),expires=Date.now()+8*3600000,payload=b64(enc.encode(JSON.stringify({sub:p.userId,exp:expires,nonce:crypto.randomUUID()}))),signature=b64(await crypto.subtle.sign('HMAC',await signingKey(),enc.encode(payload+':'+binding(p,user))));return {token:payload+'.'+signature,expires,viewer:p};}
async function authenticate(token){
 let payload,signature,claims;try{if(typeof token!=='string'||token.length>1500||token.split('.').length!==2)throw Error();[payload,signature]=token.split('.');claims=JSON.parse(dec.decode(unb64(payload)));if(!claims.sub||!Number.isFinite(claims.exp)||claims.exp<Date.now()||claims.exp>Date.now()+8*3600000)throw Error();}catch{fail('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.',401);}
 const c=await context(),users=c.users.value,matches=users.filter(u=>String(u.id)===claims.sub),user=matches.length===1?matches[0]:null,p=principal(user,c.config.value);let valid=false;
 try{valid=await crypto.subtle.verify('HMAC',await signingKey(),unb64(signature),enc.encode(payload+':'+binding(p,user)));}catch{}
 if(!valid)fail('Phiên đăng nhập không còn hợp lệ. Đăng nhập lại.',401);
 return {...p,trainers:c.config.value.trainers||[],config:c.config.value,configVersion:c.config.version};
}
async function initialized(){return (await readSetting('auth_users')).value.length>0;}
async function authorize(username,password){
 if(typeof password!=='string'||password.length>256||!clean(username)||clean(username).length>80)fail('Tên đăng nhập hoặc mật khẩu không đúng.',401);
 const c=await context(),list=c.users.value,matches=list.filter(u=>loginName(u.username)===loginName(username)),user=matches.length===1?matches[0]:null;
 if(!user||user.locked)fail('Tên đăng nhập hoặc mật khẩu không đúng, hoặc tài khoản bị khóa.',401);
 if((user.blockedUntil||0)>Date.now())fail('Tạm khóa đăng nhập do nhập sai nhiều lần. Thử lại sau 15 phút hoặc nhờ Admin mở khóa.',429);
 let match=false;try{match=await equal(await passwordHash(password,user.passHash),user.passHash);}catch{}
 if(!match){user.failedLoginAttempts=(user.failedLoginAttempts||0)+1;if(user.failedLoginAttempts>=5)user.blockedUntil=Date.now()+15*60000;await putSetting(c.users,list);fail('Tên đăng nhập hoặc mật khẩu không đúng.',401);}
 if(user.failedLoginAttempts||user.blockedUntil){user.failedLoginAttempts=0;user.blockedUntil=0;await putSetting(c.users,list);}
 return issue(user,c.config.value);
}
function fields(body,config){
 const username=loginName(body.username),displayName=clean(body.displayName),role=body.role;
 if(!/^[a-z0-9_.@-]{3,80}$/.test(username)||!displayName||displayName.length>160||!['admin','trainer'].includes(role))fail('Nhập tên hiển thị, username hợp lệ (3–80 ký tự) và vai trò.');
 const trainer=role==='trainer'?(config.trainers||[]).find(t=>String(t.id)===String(body.trainerId)):null;
 if(role==='trainer'&&!trainer)fail('Chọn Trainer đã được gán khu vực.');
 return {username,displayName,role,trainerId:trainer?String(trainer.id):'',region:trainer?.region||''};
}
async function bootstrap(body){
 const secret=Deno.env.get('BOOTSTRAP_TOKEN');if(!secret||secret.length<24)fail('Admin cần đặt BOOTSTRAP_TOKEN từ 24 ký tự trong Secrets.',503);
 if(typeof body.bootstrapToken!=='string'||!await equal(secret,body.bootstrapToken))fail('Mã khởi tạo không đúng.',403);
 const c=await context();if(c.users.value.length)fail('Admin đầu tiên đã được tạo. Hãy đăng nhập.',409);
 const user={id:crypto.randomUUID(),...fields({...body,role:'admin'},c.config.value),passHash:await passwordHash(body.password),locked:false,createdAt:new Date().toISOString()};
 await putSetting(c.users,[user]);return issue(user,c.config.value);
}
const safeUser=u=>({id:u.id,username:u.username,displayName:u.displayName,role:u.role,trainerId:u.trainerId||'',region:u.region||'',locked:!!u.locked,blockedUntil:u.blockedUntil||0});
async function manage(action,body,p){
 if(action==='me')return {viewer:{userId:p.userId,username:p.username,displayName:p.displayName,role:p.role,trainerId:p.trainerId,region:p.region},config:p.config,configVersion:p.configVersion};
 if(action==='change_password'){
  const record=await readSetting('auth_users'),user=record.value.find(u=>String(u.id)===p.userId);let correct=false;
  try{correct=await equal(await passwordHash(body.currentPassword,user.passHash),user.passHash);}catch{}
  if(!correct)fail('Mật khẩu hiện tại không đúng.',403);user.passHash=await passwordHash(body.password);user.failedLoginAttempts=0;user.blockedUntil=0;await putSetting(record,record.value);return {saved:true,relogin:true};
 }
 if(p.role!=='admin')fail('Chỉ Admin được quản lý khu vực, Trainer và tài khoản.',403);
 const c=await context();
 if(action==='admin_users')return {users:c.users.value.map(safeUser)};
 if(action==='admin_save_config'){
  if(body.version!==c.config.version)fail('Cấu hình đã thay đổi. Tải lại để xem bản mới.',409);
  const input=body.config;if(!input||!Array.isArray(input.regions)||!Array.isArray(input.trainers)||input.regions.length>200||input.trainers.length>500)fail('Cấu hình khu vực/Trainer không hợp lệ.');
  const regions=input.regions.map(clean);if(regions.some(x=>!x||x.length>120)||new Set(regions.map(x=>x.toLocaleLowerCase())).size!==regions.length)fail('Tên khu vực trống hoặc trùng nhau.');
  const trainers=input.trainers.map(t=>({id:clean(t.id),name:clean(t.name),region:clean(t.region)}));
  if(trainers.some(t=>!t.id||t.id.length>80||!t.name||t.name.length>160||!regions.includes(t.region))||new Set(trainers.map(t=>t.id)).size!==trainers.length)fail('Mỗi Trainer cần ID duy nhất, tên và khu vực hợp lệ.');
  if(c.users.value.some(u=>u.role==='trainer'&&!trainers.some(t=>t.id===u.trainerId)))fail('Còn tài khoản gắn với Trainer này. Gán lại tài khoản trước khi xóa Trainer.');
  const config={regions,trainers};const saved=await putSetting(c.config,config);return {saved:true,config,configVersion:saved.version};
 }
 const list=c.users.value;
 if(action==='admin_create_user'){
  const data=fields(body,c.config.value);if(list.some(u=>loginName(u.username)===data.username))fail('Username đã tồn tại.',409);
  if(data.role==='trainer'&&list.some(u=>u.role==='trainer'&&u.trainerId===data.trainerId))fail('Trainer này đã có tài khoản.',409);
  const user={id:crypto.randomUUID(),...data,passHash:await passwordHash(body.password),locked:false,createdAt:new Date().toISOString()};list.push(user);await putSetting(c.users,list);return {saved:true,user:safeUser(user)};
 }
 const user=list.find(u=>String(u.id)===String(body.userId));if(!user)fail('Không tìm thấy tài khoản.',404);
 if(action==='admin_update_user'){
  const data=fields(body,c.config.value);if(list.some(u=>u.id!==user.id&&loginName(u.username)===data.username))fail('Username đã tồn tại.',409);
  if(data.role==='trainer'&&list.some(u=>u.id!==user.id&&u.role==='trainer'&&u.trainerId===data.trainerId))fail('Trainer này đã có tài khoản.',409);
  if(user.id===p.userId&&data.role!=='admin')fail('Không tự đổi quyền Admin của tài khoản đang dùng.');Object.assign(user,data);
 }else if(action==='admin_set_password'){user.passHash=await passwordHash(body.password);user.failedLoginAttempts=0;user.blockedUntil=0;}
 else if(action==='admin_set_locked'){if(user.id===p.userId&&body.locked)fail('Không tự khóa tài khoản đang dùng.');user.locked=body.locked===true;user.blockedUntil=0;user.failedLoginAttempts=0;}
 else fail('Thao tác quản lý không hợp lệ.');
 if(!list.some(u=>u.role==='admin'&&!u.locked))fail('Phải giữ ít nhất một Admin đang hoạt động.');
 await putSetting(c.users,list);return {saved:true,user:safeUser(user),relogin:user.id===p.userId&&action==='admin_set_password'};
}

return {AccessError, appUrl, initialized, authorize, bootstrap, manage, authenticate};})();
{
const {AccessError, appUrl, initialized, authorize, bootstrap, manage, authenticate}=HubAccess;

const SANDBOX_IDS=['primary','secondary'];
const sandboxId=value=>value===undefined||value===null?'primary':SANDBOX_IDS.includes(value)?value:null;
function sandboxCredentials(id,get){
 if(!SANDBOX_IDS.includes(id))throw Error('Unknown Sandbox');
 const prefix=id==='secondary'?'TIKTOK_SANDBOX2_':'TIKTOK_';
 return {client:get(prefix+'CLIENT_KEY')?.trim(),clientSecret:get(prefix+'CLIENT_SECRET')?.trim()};
}

// Observations come from TikTok at sync time, never from a requested report date.
const FOLLOWER_SCOPE='user.info.stats';
const FOLLOWER_BASELINE_DATE='2026-10-01';
const followerCalendar=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'});
const followerDay=at=>followerCalendar.format(new Date(at));
function followerPoints(history){
 const byTime=new Map();
 for(const p of Array.isArray(history)?history:[]){
  if(typeof p?.at!=='string'||!Number.isFinite(Date.parse(p.at))||!Number.isSafeInteger(p.count)||p.count<0)continue;
  const at=new Date(p.at).toISOString();byTime.set(at,{at,count:p.count});
 }
 return [...byTime.values()].sort((a,b)=>Date.parse(a.at)-Date.parse(b.at));
}
function recordFollowers(history,point){
 const points=followerPoints([...(Array.isArray(history)?history:[]),point]),days=new Map();
 for(const p of points){const day=followerDay(p.at),entry=days.get(day);if(entry)entry.last=p;else days.set(day,{first:p,last:p});}
 return [...days.values()].flatMap(d=>d.first.at===d.last.at?[d.first]:[d.first,d.last]);
}
function followerView(channel,from,to){
 const history=followerPoints(channel?.followers?.history),last=history[history.length-1],authorized=!!channel?.token?.scopes?.includes(FOLLOWER_SCOPE)&&channel?.followers?.status!=='needs_authorization';
 const saved=channel?.followerBaseline,baseline=saved?.date===FOLLOWER_BASELINE_DATE&&Number.isSafeInteger(saved.count)&&saved.count>=0&&saved.handle===channel?.handle&&(!saved.openId||saved.openId===channel?.token?.openId)?{date:saved.date,count:saved.count,source:'admin_record',recordedAt:saved.recordedAt}:null;
 return {authorized,status:!channel?.token?'not_connected':!authorized?'needs_authorization':channel.followers?.status||'awaiting_sync',
  current:last?.count??null,asOf:last?.at??null,firstRecordedAt:history[0]?.at??null,baselineDate:FOLLOWER_BASELINE_DATE,baseline,
  history:history.filter(p=>{const day=followerDay(p.at);return day>=FOLLOWER_BASELINE_DATE&&day<=to;})};
}



// Official TikTok Display API only. Tokens never leave this function; no scraping.
const te=new TextEncoder(),td=new TextDecoder();
const ROOT='trainer-hub',TABLE='trainer_hub_private';
const SCOPES=['user.info.basic','user.info.profile','video.list'];
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[Đđ]/g,'d').toLowerCase().replace(/[^a-z0-9]/g,'');
const clean=s=>String(s??'').trim();
const b64=a=>{const bytes=new Uint8Array(a);let out='';for(let i=0;i<bytes.length;i+=32768)out+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(out).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');};
const unb64=s=>Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
// Keep the original Sandbox credentials and route the second slot independently.
const env=(id='primary')=>({url:Deno.env.get('SUPABASE_URL'),secret:Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'),...sandboxCredentials(id,k=>Deno.env.get(k))});
const callback=()=>env().url+'/functions/v1/'+ROOT+'/oauth/callback';
const configured=(id='primary')=>!!(env(id).client&&env(id).clientSecret);
const sandboxList=()=>SANDBOX_IDS.map(id=>({id,label:id==='primary'?'Sandbox 1':'Sandbox 2',configured:configured(id)}));
const channelSandbox=c=>{const id=sandboxId(c?.sandboxId);if(!id)failure('Sandbox của kênh không hợp lệ. Nhờ Admin kiểm tra.',409);return id;};
const failure=(message,status=400)=>{throw new AccessError(message,status);};
async function cryptKey(){return crypto.subtle.importKey('raw',await crypto.subtle.digest('SHA-256',te.encode('trainer-hub-private-v1:'+env().secret)),'AES-GCM',false,['encrypt','decrypt']);}
async function seal(key,data){const iv=crypto.getRandomValues(new Uint8Array(12));return {v:1,iv:b64(iv),ciphertext:b64(await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:te.encode(key)},await cryptKey(),te.encode(JSON.stringify(data))))};}
async function unseal(key,data){try{return JSON.parse(td.decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(data.iv),additionalData:te.encode(key)},await cryptKey(),unb64(data.ciphertext))));}catch{failure('Không đọc được dữ liệu kênh đã mã hóa.',503);}}
async function database(path,options={}){
 const e=env();if(!e.url||!e.secret)failure('Chưa sẵn sàng nơi lưu dữ liệu.',503);
 const r=await fetch(e.url+'/rest/v1/'+TABLE+path,{...options,headers:{apikey:e.secret,Authorization:'Bearer '+e.secret,'Content-Type':'application/json',Prefer:'return=representation',...options.headers},signal:AbortSignal.timeout(12000)});
 if(!r.ok)failure('Không lưu/đọc được dữ liệu Xây kênh. Hãy thử lại.',503);
 return r.status===204?[]:await r.json();
}
async function read(key){
 key=ROOT+':'+key;const rows=await database('?key=eq.'+encodeURIComponent(key)+'&select=key,value,version');
 return rows[0]?{key,version:rows[0].version,data:await unseal(key,rows[0].value)}:{key,version:null,data:null};
}
async function resolvedChannel(id){const local=await read('channel:'+id);return {local,data:local.data};}
async function put(record,data){
 if(!record.key.startsWith(ROOT+':'))record.key=ROOT+':'+record.key;
 const value=await seal(record.key,data),next=record.version===null?1:record.version+1;
 const rows=record.version===null?await database('',{method:'POST',headers:{Prefer:'resolution=ignore-duplicates,return=representation'},body:JSON.stringify({key:record.key,value,version:next,updated_at:new Date().toISOString()})}):await database('?key=eq.'+encodeURIComponent(record.key)+'&version=eq.'+record.version,{method:'PATCH',body:JSON.stringify({value,version:next,updated_at:new Date().toISOString()})});
 if(rows.length!==1)failure('Dữ liệu vừa thay đổi ở phiên khác. Hãy tải lại.',409);
 record.data=data;record.version=next;return record;
}
async function consume(key,version){const rows=await database('?key=eq.'+encodeURIComponent(key)+'&version=eq.'+version,{method:'DELETE'});if(rows.length!==1)failure('Liên kết kết nối đã được dùng. Hãy kết nối lại.',409);}
const validDate=s=>typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&!Number.isNaN(Date.parse(s+'T00:00:00Z'))&&new Date(s+'T00:00:00Z').toISOString().slice(0,10)===s;
function dates(body){if(!validDate(body.from)||!validDate(body.to)||body.to<body.from||(Date.parse(body.to)-Date.parse(body.from))/86400000>365)failure('Chọn khoảng ngày hợp lệ, tối đa 366 ngày.');return {from:body.from,to:body.to};}
function handle(value){let s=clean(value).replace(/^@/,'');if(/^https:\/\//i.test(s)){let u;try{u=new URL(s);}catch{failure('Link TikTok không hợp lệ.');}if(!['tiktok.com','www.tiktok.com'].includes(u.hostname)||!/^\/@[a-zA-Z0-9._]+\/?$/.test(u.pathname)||u.username||u.password)failure('Nhập link trang TikTok dạng https://www.tiktok.com/@tenkenh.');s=u.pathname.slice(2).replace(/\/$/,'');}if(!/^[a-zA-Z0-9._]{2,24}$/.test(s))failure('Tên kênh TikTok không hợp lệ.');return s.toLowerCase();}
function trainer(p,id,write=false){const t=p.trainers.find(t=>String(t.id)===String(id));if(!t||!(p.role==='admin'||(p.role==='trainer'&&norm(p.region)&&norm(t.region)===norm(p.region))))failure('Không có quyền truy cập Trainer này.',403);if(write&&p.role!=='admin'&&String(t.id)!==p.trainerId)failure('Chỉ được kết nối kênh của chính bạn.',403);return t;}
function roster(p){return p.trainers;}
async function official(path,options,scopeProbe=false){
 let r;try{r=await fetch('https://open.tiktokapis.com'+path,{...options,signal:AbortSignal.timeout(20000)});}catch{failure('TikTok chưa phản hồi. Số liệu lần đồng bộ trước được giữ lại.',502);}
 let out;try{out=await r.json();}catch{failure('TikTok trả dữ liệu không hợp lệ.',502);}
 if(!r.ok||out.error?.code&&out.error.code!=='ok'||typeof out.error==='string'){
  if(scopeProbe&&(r.status===403||String(out.error?.code||'').includes('scope')))failure('Cần cấp quyền đọc follower.',403);
  failure(r.status===429?'TikTok đang giới hạn lượt truy cập. Hãy thử lại sau.':'Không lấy được dữ liệu TikTok. Hãy kiểm tra hoặc kết nối lại kênh.',r.status===429?429:502);
 }
 return out;
}
async function tokenCall(values,id='primary'){const e=env(id);return official('/v2/oauth/token/',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_key:e.client,client_secret:e.clientSecret,...values}).toString()});}
function tokenPayload(out,previous,id='primary'){
 if(!out.access_token||!out.refresh_token||!out.open_id||!Number.isFinite(Number(out.expires_in)))failure('TikTok chưa cấp quyền đọc video.',502);
 if(!SCOPES.every(s=>String(out.scope||'').split(',').includes(s)))failure('Cần đồng ý đủ quyền hồ sơ và video để kết nối.',403);
 if(previous&&previous.openId!==out.open_id)failure('Tài khoản TikTok trả về không khớp kênh đã gán.',403);
 return {sandboxId:id,clientKey:env(id).client,access:out.access_token,refresh:out.refresh_token,openId:out.open_id,expires:Date.now()+Number(out.expires_in)*1000,scopes:String(out.scope||'').split(',').filter(Boolean)};
}
async function connect(body,p){
 const t=trainer(p,body.trainerId,true);
 if(body.returnUrl!==appUrl())failure('Địa chỉ quay lại không hợp lệ.');
 const resolved=await resolvedChannel(t.id);
 const rec=resolved.local;if(!rec.data?.handle)failure('Admin cần gán trang TikTok trước khi kết nối.');
 const id=channelSandbox(rec.data);if(!configured(id))failure('Sandbox được gán chưa cấu hình xong. Nhờ Admin thiết lập trước khi kết nối.',503);
 const state=crypto.randomUUID()+crypto.randomUUID();await put({key:'oauth:'+state,version:null},{trainerId:String(t.id),dashboardToken:body.dashboardToken,expected:rec.data.handle,returnUrl:body.returnUrl,sandboxId:id,clientKey:env(id).client,expires:Date.now()+10*60000,version:rec.version});
 const requested=body.followerStats===true?[...SCOPES,FOLLOWER_SCOPE]:SCOPES;
 const url=new URL('https://www.tiktok.com/v2/auth/authorize/');url.search=new URLSearchParams({client_key:env(id).client,scope:requested.join(','),response_type:'code',redirect_uri:callback(),state,disable_auto_auth:'1'}).toString();
 return {url:url.href};
}
async function oauth(url){
 const state=url.searchParams.get('state')||'';if(!/^[a-f0-9-]{72}$/.test(state))failure('Phiên kết nối không hợp lệ.');
 const saved=await read('oauth:'+state);if(!saved.data||saved.data.expires<Date.now())failure('Phiên kết nối đã hết hạn. Hãy kết nối lại.');
 await consume(saved.key,saved.version);const back=saved.data.returnUrl;if(back!==appUrl())failure('Địa chỉ quay lại đã thay đổi. Kết nối lại.');
 try{
  if(url.searchParams.has('error')||!url.searchParams.get('code'))throw Error();
  const current=await read('channel:'+saved.data.trainerId);if(!current.data||current.version!==saved.data.version||current.data.handle!==saved.data.expected)throw Error();
  // Recheck the authorizing dashboard account and current ownership at callback time.
  const owner=await authenticate(saved.data.dashboardToken);trainer(owner,saved.data.trainerId,true);
  const id=sandboxId(saved.data.sandboxId);if(!id||channelSandbox(current.data)!==id||!configured(id)||saved.data.clientKey&&saved.data.clientKey!==env(id).client)throw Error();
  const out=await tokenCall({grant_type:'authorization_code',code:url.searchParams.get('code'),redirect_uri:callback()},id);const token=tokenPayload(out,null,id);
  const info=await official('/v2/user/info/?fields=open_id,display_name,username',{headers:{Authorization:'Bearer '+token.access}});const profile=info.data?.user;
  if(!profile||profile.open_id!==token.openId||handle(profile.username)!==saved.data.expected)throw Error();
  const oldId=sandboxId(current.data.token?.sandboxId);
  const sameAccount=current.data.token?.openId===token.openId&&oldId===id;
  const changedSandbox=!!current.data.token&&oldId!==id;
  const keepHistory=sameAccount||changedSandbox;
  let next={...current.data,sandboxId:id,token,profile:{username:handle(profile.username),displayName:clean(profile.display_name).slice(0,150)},
   snapshot:keepHistory?current.data.snapshot:null,pending:sameAccount?current.data.pending:null,
   followers:keepHistory?current.data.followers:null,
   followerBaseline:current.data.followerBaseline?.handle===saved.data.expected&&(!current.data.followerBaseline.openId||current.data.followerBaseline.openId===token.openId||changedSandbox)?{...current.data.followerBaseline,openId:token.openId}:null};
  next=await captureFollowers(next);await put(current,next);
  return Response.redirect(back+'#channel-connect=ok',303);
 }catch{return Response.redirect(back+'#channel-connect=failed',303);}
}
const number=v=>{const n=Number(v);if(v===null||v===undefined||v===''||!Number.isSafeInteger(n)||n<0)failure('TikTok trả chỉ số chưa đầy đủ. Số liệu cũ được giữ lại.',502);return n;};
async function captureFollowers(channel){
 const knownScopes=Array.isArray(channel.token?.scopes);
 if(knownScopes&&!channel.token.scopes.includes(FOLLOWER_SCOPE)||!knownScopes&&channel.followers?.status==='needs_authorization')return {...channel,followers:{...channel.followers,status:'needs_authorization',lastAttemptAt:new Date().toISOString()}};
 try{
  const out=await official('/v2/user/info/?fields=open_id,follower_count',{headers:{Authorization:'Bearer '+channel.token.access}},true),profile=out.data?.user;
  if(!profile||profile.open_id!==channel.token.openId)throw Error('Follower account mismatch');
  const count=number(profile.follower_count),at=new Date().toISOString(),history=recordFollowers(channel.followers?.history,{at,count});
  return {...channel,token:knownScopes?channel.token:{...channel.token,scopes:[FOLLOWER_SCOPE],scopeSource:'stats_probe'},followers:{history,status:'ready',lastAttemptAt:at}};
 }catch(error){return {...channel,followers:{...channel.followers,status:error instanceof AccessError&&error.status===403?'needs_authorization':'unavailable',lastAttemptAt:new Date().toISOString()}};}
}
async function sync(body,p){
 const t=trainer(p,body.trainerId);
 const resolved=await resolvedChannel(t.id);
 const rec=resolved.local;let c=rec.data;if(!c?.token)failure('Trainer chưa kết nối TikTok.',409);
 const id=sandboxId(c.token.sandboxId);if(!id||channelSandbox(c)!==id)failure('Kênh vừa đổi Sandbox. Hãy kết nối lại; dữ liệu cũ được giữ nguyên.',409);
 if(!configured(id))failure('Sandbox của kênh chưa cấu hình xong. Dữ liệu cũ được giữ nguyên.',503);
 if(c.token.clientKey&&c.token.clientKey!==env(id).client)failure('Cấu hình Sandbox đã thay đổi. Hãy kết nối lại; dữ liệu cũ được giữ nguyên.',409);
 if(!body.force&&c.snapshot?.complete&&Date.now()-Date.parse(c.snapshot.syncedAt)<15*60000&&!c.pending&&c.followers?.lastAttemptAt&&Date.now()-Date.parse(c.followers.lastAttemptAt)<15*60000)return {trainerId:String(t.id),cached:true,complete:true};
 if(c.token.expires<Date.now()+120000){const out=await tokenCall({grant_type:'refresh_token',refresh_token:c.token.refresh},id);c={...c,token:tokenPayload(out,c.token,id)};await put(rec,c);}
 // Keep follower observations even when a later video request fails.
 c=await captureFollowers(c);await put(rec,c);
 let pending=c.pending&&Date.now()-c.pending.started<10*60000?c.pending:{started:Date.now(),cursor:null,videos:[]};
 let complete=false;
 for(let page=0;page<5;page++){
  const payload={max_count:20,...(pending.cursor===null?{}:{cursor:pending.cursor})};
  const out=await official('/v2/video/list/?fields=id,create_time,title,like_count,share_count,view_count',{method:'POST',headers:{Authorization:'Bearer '+c.token.access,'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const d=out.data;if(!d||!Array.isArray(d.videos)||typeof d.has_more!=='boolean')failure('TikTok chưa trả danh sách video đầy đủ.',502);
  const map=new Map(pending.videos.map(v=>[v.id,v]));
  for(const v of d.videos){if(!/^\d{5,30}$/.test(String(v.id))||!Number.isFinite(Number(v.create_time)))failure('TikTok trả video không hợp lệ.',502);map.set(String(v.id),{id:String(v.id),createdAt:new Date(Number(v.create_time)*1000).toISOString(),title:clean(v.title).slice(0,500),likes:number(v.like_count),shares:number(v.share_count),views:number(v.view_count)});}
  pending.videos=[...map.values()];if(pending.videos.length>20000)failure('Kênh có quá nhiều video cho một lượt đồng bộ. Dữ liệu trước vẫn được giữ.',422);
  if(!d.has_more){complete=true;break;}
  if(!Number.isFinite(Number(d.cursor))||Number(d.cursor)===pending.cursor)failure('TikTok chưa trả trang video tiếp theo hợp lệ.',502);pending.cursor=Number(d.cursor);
 }
 if(complete){c={...c,snapshot:{complete:true,videos:pending.videos,syncedAt:new Date().toISOString()},pending:null};}
 else c={...c,pending};
 await put(rec,c);return {trainerId:String(t.id),complete,pagesPending:!complete,videoCount:pending.videos.length};
}
async function overview(body,p){
 const range=dates(body);const list=[];
 for(const t of roster(p)){
  const resolved=await resolvedChannel(t.id),c=resolved.data;const videos=(c?.snapshot?.videos||[]).filter(v=>{const day=new Date(v.createdAt).toLocaleDateString('sv-SE',{timeZone:'Asia/Ho_Chi_Minh'});return day>=range.from&&day<=range.to;});
  list.push({id:String(t.id),name:clean(t.name),region:clean(t.region),handle:c?.handle||'',trackingFrom:c?.trackingFrom||null,canSync:p.role==='admin'||norm(p.region)===norm(t.region),connected:!!c?.token,known:!!c?.snapshot?.complete,syncedAt:c?.snapshot?.syncedAt||null,pending:!!c?.pending,videos,followers:followerView(c,range.from,range.to),sandboxId:channelSandbox(c),sandboxReady:configured(channelSandbox(c)),needsSandboxReconnect:!!c?.token&&sandboxId(c.token.sandboxId)!==channelSandbox(c)});
 }
 return {trainers:list,overviewScope:'team',role:p.role,ownTrainerId:p.trainerId,configured:sandboxList().some(s=>s.configured),sandboxes:sandboxList(),...range};
}
async function assign(body,p){
 if(p.role!=='admin')failure('Chỉ Admin được gán trang TikTok.',403);const t=trainer(p,body.trainerId),name=handle(body.handle);
 if(!validDate(body.trackingFrom))failure('Ngày bắt đầu theo dõi không hợp lệ.');
 for(const other of p.trainers){if(String(other.id)!==String(t.id)&&(await resolvedChannel(other.id)).data?.handle===name)failure('Trang TikTok này đã được gán cho Trainer khác.');}
 const resolved=await resolvedChannel(t.id),rec=resolved.local,same=rec.data?.handle===name;
 const id=body.sandboxId===undefined?channelSandbox(rec.data):SANDBOX_IDS.includes(body.sandboxId)?body.sandboxId:null;if(!id)failure('Chọn Sandbox hợp lệ.');
 if(id==='secondary'&&channelSandbox(rec.data)!==id&&!configured(id))failure('Sandbox 2 chưa được cấu hình. Giữ nguyên Sandbox và dữ liệu hiện tại.',409);
 const next={...(same?rec.data:{}),handle:name,sandboxId:id,trackingFrom:body.trackingFrom,updatedAt:new Date().toISOString()};
 if(same&&!next.token&&id!==channelSandbox(rec.data)&&next.followerBaseline)next.followerBaseline={...next.followerBaseline,openId:null};
 await put(rec,next);return {saved:true,trainerId:String(t.id)};
}
async function setFollowerBaseline(body,p){
 if(p.role!=='admin')failure('Chỉ Admin được nhập mốc follower đầu kỳ.',403);
 const t=trainer(p,body.trainerId);
 if(!Number.isSafeInteger(body.count)||body.count<0)failure('Nhập số follower thực tế ngày 01/10/2026, là số nguyên không âm.');
 const resolved=await resolvedChannel(t.id),rec=resolved.local,c=resolved.data;if(!c?.handle)failure('Gán đúng kênh TikTok trước khi nhập mốc follower.');
 const baseline={date:FOLLOWER_BASELINE_DATE,count:body.count,source:'admin_record',recordedAt:new Date().toISOString(),handle:c.handle,openId:c.token?.openId||null};
 await put(rec,{...(rec.data||{handle:c.handle,trackingFrom:c.trackingFrom,sandboxId:'primary'}),followerBaseline:baseline});return {saved:true,trainerId:String(t.id),baseline:{date:baseline.date,count:baseline.count,source:baseline.source,recordedAt:baseline.recordedAt}};
}
Deno.serve(async req=>{
 let originAllowed;try{originAllowed=new URL(appUrl()).origin;}catch(error){return new Response(JSON.stringify({error:error.message}),{status:503,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});}
 const origin=req.headers.get('origin'),headers={'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':originAllowed,'Access-Control-Allow-Headers':'content-type,apikey,authorization','Access-Control-Allow-Methods':'POST,OPTIONS','Vary':'Origin','Referrer-Policy':'no-referrer'};
 const respond=(body,status=200)=>new Response(JSON.stringify(body),{status,headers});
 try{
  const u=new URL(req.url);if(req.method==='GET'&&u.pathname.endsWith('/oauth/callback'))return await oauth(u);
  if(origin&&origin!==originAllowed)return respond({error:'Nguồn truy cập không hợp lệ.'},403);
  if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
  if(req.method!=='POST')return respond({error:'Chỉ hỗ trợ POST.'},405);
  if(Number(req.headers.get('content-length')||0)>64000)return respond({error:'Yêu cầu quá dài.'},413);
  const raw=await req.text();if(raw.length>64000)return respond({error:'Yêu cầu quá dài.'},413);let body;
  try{body=JSON.parse(raw);if(!body||typeof body!=='object'||Array.isArray(body))throw Error();}catch{failure('Yêu cầu không hợp lệ.');}
  if(body.action==='status')return respond({ok:true,initialized:await initialized(),configured:sandboxList().some(s=>s.configured),sandboxes:sandboxList(),redirectUri:callback(),appUrl:appUrl(),followerHistory:true,manualTracking:false});
  if(body.action==='login')return respond({ok:true,...await authorize(body.username,body.password)});
  if(body.action==='bootstrap')return respond({ok:true,...await bootstrap(body)});
  const p=await authenticate(body.dashboardToken);let out;
  if(body.action==='me'||body.action==='change_password'||String(body.action).startsWith('admin_'))out=await manage(body.action,body,p);
  else switch(body.action){case 'overview':out=await overview(body,p);break;case 'assign':out=await assign(body,p);break;case 'connect':out=await connect(body,p);break;case 'sync':out=await sync(body,p);break;case 'set_follower_baseline':out=await setFollowerBaseline(body,p);break;default:failure('Thao tác không hợp lệ.');}
  return respond({ok:true,...out});
 }catch(error){return respond({error:error instanceof AccessError?error.message:'Chưa xử lý được yêu cầu. Dữ liệu cũ được giữ nguyên.'},error instanceof AccessError?error.status:500);}
});

}
