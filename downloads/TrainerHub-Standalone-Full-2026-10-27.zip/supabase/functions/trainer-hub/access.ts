// Account/config module. Private tables are read only by the server's service role.
const enc=new TextEncoder(),dec=new TextDecoder();
const clean=v=>String(v??'').trim();
const loginName=v=>clean(v).normalize('NFKC').toLowerCase();
const b64=v=>btoa(String.fromCharCode(...new Uint8Array(v))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const unb64=v=>Uint8Array.from(atob(v.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
export class AccessError extends Error{constructor(message,status=401){super(message);this.status=status;}}
const fail=(message,status=400)=>{throw new AccessError(message,status);};
export function appUrl(){
 const value=clean(Deno.env.get('APP_URL'));let u;try{u=new URL(value);}catch{fail('Chưa đặt APP_URL hợp lệ trên máy chủ.',503);}
 if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash)fail('APP_URL phải là URL HTTPS đầy đủ, không có query/hash.',503);
 return u.href;
}
async function database(path,options={}){
 const base=Deno.env.get('SUPABASE_URL'),secret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');if(!base||!secret)fail('Máy chủ chưa sẵn sàng.',503);
 const response=await fetch(base+'/rest/v1/trainer_hub_settings'+path,{...options,headers:{apikey:secret,Authorization:'Bearer '+secret,'Content-Type':'application/json',Prefer:'return=representation',...options.headers},signal:AbortSignal.timeout(12000)});
 if(!response.ok)fail('Không truy cập được bảng cấu hình. Kiểm tra đã chạy setup.sql.',503);
 return response.status===204?[]:await response.json();
}
async function readSetting(key){const rows=await database('?key=eq.'+encodeURIComponent(key)+'&select=key,value,version');return rows[0]||{key,value:key==='auth_users'?[]:{regions:[],trainers:[]},version:null};}
async function putSetting(record,value){
 const version=record.version===null?1:record.version+1;
 const body={key:record.key,value,version,updated_at:new Date().toISOString()};
 const rows=record.version===null?await database('',{method:'POST',headers:{Prefer:'resolution=ignore-duplicates,return=representation'},body:JSON.stringify(body)}):await database('?key=eq.'+encodeURIComponent(record.key)+'&version=eq.'+record.version,{method:'PATCH',body:JSON.stringify(body)});
 if(rows.length!==1)fail('Dữ liệu vừa được cập nhật ở phiên khác. Tải lại và thử lại.',409);return rows[0];
}
const digest=async value=>new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(value)));
async function passwordHash(password,saved=null){
 if(typeof password!=='string'||password.length<10||password.length>256)fail('Mật khẩu cần từ 10 đến 256 ký tự.');
 const parts=saved?.split('$'),salt=saved?unb64(parts[2]):crypto.getRandomValues(new Uint8Array(16)),iterations=120000;
 if(saved&&(parts.length!==4||parts[0]!=='pbkdf2_sha256'||parts[1]!==String(iterations)))return '';
 const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);
 const result=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations,hash:'SHA-256'},key,256);
 return 'pbkdf2_sha256$'+iterations+'$'+b64(salt)+'$'+b64(result);
}
async function equal(a,b){const x=await digest(String(a)),y=await digest(String(b));return x.every((v,i)=>v===y[i]);}
async function context(){const [users,config]=await Promise.all([readSetting('auth_users'),readSetting('config')]);if(!Array.isArray(users.value))fail('Dữ liệu tài khoản chưa hợp lệ.',503);return {users,config};}
function principal(user,config){
 if(!user||user.locked||!['admin','trainer'].includes(user.role)||!user.passHash)fail('Tài khoản không có quyền truy cập.',403);
 const trainer=(config.trainers||[]).find(t=>String(t.id)===String(user.trainerId));
 if(user.role==='trainer'&&!trainer?.region)fail('Tài khoản chưa được gán Trainer và khu vực.',403);
 return {userId:String(user.id),username:user.username,displayName:user.displayName,role:user.role,trainerId:user.role==='trainer'?String(trainer.id):'',region:user.role==='trainer'?trainer.region:''};
}
const binding=(p,user)=>JSON.stringify([p.role,p.region,p.trainerId,user.passHash]);
async function signingKey(){return crypto.subtle.importKey('raw',await digest('trainer-hub-session-v1:'+Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);}
async function issue(user,config){const p=principal(user,config),expires=Date.now()+8*3600000,payload=b64(enc.encode(JSON.stringify({sub:p.userId,exp:expires,nonce:crypto.randomUUID()}))),signature=b64(await crypto.subtle.sign('HMAC',await signingKey(),enc.encode(payload+':'+binding(p,user))));return {token:payload+'.'+signature,expires,viewer:p};}
export async function authenticate(token){
 let payload,signature,claims;try{if(typeof token!=='string'||token.length>1500||token.split('.').length!==2)throw Error();[payload,signature]=token.split('.');claims=JSON.parse(dec.decode(unb64(payload)));if(!claims.sub||!Number.isFinite(claims.exp)||claims.exp<Date.now()||claims.exp>Date.now()+8*3600000)throw Error();}catch{fail('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.',401);}
 const c=await context(),users=c.users.value,matches=users.filter(u=>String(u.id)===claims.sub),user=matches.length===1?matches[0]:null,p=principal(user,c.config.value);let valid=false;
 try{valid=await crypto.subtle.verify('HMAC',await signingKey(),unb64(signature),enc.encode(payload+':'+binding(p,user)));}catch{}
 if(!valid)fail('Phiên đăng nhập không còn hợp lệ. Đăng nhập lại.',401);
 return {...p,trainers:c.config.value.trainers||[],config:c.config.value,configVersion:c.config.version};
}
export async function initialized(){return (await readSetting('auth_users')).value.length>0;}
export async function authorize(username,password){
 if(typeof password!=='string'||password.length>256||!clean(username)||clean(username).length>80)fail('Tên đăng nhập hoặc mật khẩu không đúng.',401);
 const c=await context(),list=c.users.value,matches=list.filter(u=>loginName(u.username)===loginName(username)),user=matches.length===1?matches[0]:null;
 if(!user||user.locked)fail('Tên đăng nhập hoặc mật khẩu không đúng, hoặc tài khoản bị khóa.',401);
 if((user.blockedUntil||0)>Date.now())fail('Tạm khóa đăng nhập do nhập sai nhiều lần. Thử lại sau 15 phút hoặc nhờ Admin mở khóa.',429);
 let match=false;try{match=await equal(await passwordHash(password,user.passHash),user.passHash);}catch{}
 if(!match){user.failedLoginAttempts=(user.failedLoginAttempts||0)+1;if(user.failedLoginAttempts>=5)user.blockedUntil=Date.now()+15*60000;await putSetting(c.users,list);fail('Tên đăng nhập hoặc mật khẩu không đúng.',401);}
 if(user.failedLoginAttempts||user.blockedUntil){user.failedLoginAttempts=0;user.blockedUntil=0;await putSetting(c.users,list);}
 return issue(user,c.config.value);
}
function fields(body,config){
 const username=loginName(body.username),displayName=clean(body.displayName),role=body.role;
 if(!/^[a-z0-9_.@-]{3,80}$/.test(username)||!displayName||displayName.length>160||!['admin','trainer'].includes(role))fail('Nhập tên hiển thị, username hợp lệ (3–80 ký tự) và vai trò.');
 const trainer=role==='trainer'?(config.trainers||[]).find(t=>String(t.id)===String(body.trainerId)):null;
 if(role==='trainer'&&!trainer)fail('Chọn Trainer đã được gán khu vực.');
 return {username,displayName,role,trainerId:trainer?String(trainer.id):'',region:trainer?.region||''};
}
export async function bootstrap(body){
 const secret=Deno.env.get('BOOTSTRAP_TOKEN');if(!secret||secret.length<24)fail('Admin cần đặt BOOTSTRAP_TOKEN từ 24 ký tự trong Secrets.',503);
 if(typeof body.bootstrapToken!=='string'||!await equal(secret,body.bootstrapToken))fail('Mã khởi tạo không đúng.',403);
 const c=await context();if(c.users.value.length)fail('Admin đầu tiên đã được tạo. Hãy đăng nhập.',409);
 const user={id:crypto.randomUUID(),...fields({...body,role:'admin'},c.config.value),passHash:await passwordHash(body.password),locked:false,createdAt:new Date().toISOString()};
 await putSetting(c.users,[user]);return issue(user,c.config.value);
}
const safeUser=u=>({id:u.id,username:u.username,displayName:u.displayName,role:u.role,trainerId:u.trainerId||'',region:u.region||'',locked:!!u.locked,blockedUntil:u.blockedUntil||0});
export async function manage(action,body,p){
 if(action==='me')return {viewer:{userId:p.userId,username:p.username,displayName:p.displayName,role:p.role,trainerId:p.trainerId,region:p.region},config:p.config,configVersion:p.configVersion};
 if(action==='change_password'){
  const record=await readSetting('auth_users'),user=record.value.find(u=>String(u.id)===p.userId);let correct=false;
  try{correct=await equal(await passwordHash(body.currentPassword,user.passHash),user.passHash);}catch{}
  if(!correct)fail('Mật khẩu hiện tại không đúng.',403);user.passHash=await passwordHash(body.password);user.failedLoginAttempts=0;user.blockedUntil=0;await putSetting(record,record.value);return {saved:true,relogin:true};
 }
 if(p.role!=='admin')fail('Chỉ Admin được quản lý khu vực, Trainer và tài khoản.',403);
 const c=await context();
 if(action==='admin_users')return {users:c.users.value.map(safeUser)};
 if(action==='admin_save_config'){
  if(body.version!==c.config.version)fail('Cấu hình đã thay đổi. Tải lại để xem bản mới.',409);
  const input=body.config;if(!input||!Array.isArray(input.regions)||!Array.isArray(input.trainers)||input.regions.length>200||input.trainers.length>500)fail('Cấu hình khu vực/Trainer không hợp lệ.');
  const regions=input.regions.map(clean);if(regions.some(x=>!x||x.length>120)||new Set(regions.map(x=>x.toLocaleLowerCase())).size!==regions.length)fail('Tên khu vực trống hoặc trùng nhau.');
  const trainers=input.trainers.map(t=>({id:clean(t.id),name:clean(t.name),region:clean(t.region)}));
  if(trainers.some(t=>!t.id||t.id.length>80||!t.name||t.name.length>160||!regions.includes(t.region))||new Set(trainers.map(t=>t.id)).size!==trainers.length)fail('Mỗi Trainer cần ID duy nhất, tên và khu vực hợp lệ.');
  if(c.users.value.some(u=>u.role==='trainer'&&!trainers.some(t=>t.id===u.trainerId)))fail('Còn tài khoản gắn với Trainer này. Gán lại tài khoản trước khi xóa Trainer.');
  const config={regions,trainers};const saved=await putSetting(c.config,config);return {saved:true,config,configVersion:saved.version};
 }
 const list=c.users.value;
 if(action==='admin_create_user'){
  const data=fields(body,c.config.value);if(list.some(u=>loginName(u.username)===data.username))fail('Username đã tồn tại.',409);
  if(data.role==='trainer'&&list.some(u=>u.role==='trainer'&&u.trainerId===data.trainerId))fail('Trainer này đã có tài khoản.',409);
  const user={id:crypto.randomUUID(),...data,passHash:await passwordHash(body.password),locked:false,createdAt:new Date().toISOString()};list.push(user);await putSetting(c.users,list);return {saved:true,user:safeUser(user)};
 }
 const user=list.find(u=>String(u.id)===String(body.userId));if(!user)fail('Không tìm thấy tài khoản.',404);
 if(action==='admin_update_user'){
  const data=fields(body,c.config.value);if(list.some(u=>u.id!==user.id&&loginName(u.username)===data.username))fail('Username đã tồn tại.',409);
  if(data.role==='trainer'&&list.some(u=>u.id!==user.id&&u.role==='trainer'&&u.trainerId===data.trainerId))fail('Trainer này đã có tài khoản.',409);
  if(user.id===p.userId&&data.role!=='admin')fail('Không tự đổi quyền Admin của tài khoản đang dùng.');Object.assign(user,data);
 }else if(action==='admin_set_password'){user.passHash=await passwordHash(body.password);user.failedLoginAttempts=0;user.blockedUntil=0;}
 else if(action==='admin_set_locked'){if(user.id===p.userId&&body.locked)fail('Không tự khóa tài khoản đang dùng.');user.locked=body.locked===true;user.blockedUntil=0;user.failedLoginAttempts=0;}
 else fail('Thao tác quản lý không hợp lệ.');
 if(!list.some(u=>u.role==='admin'&&!u.locked))fail('Phải giữ ít nhất một Admin đang hoạt động.');
 await putSetting(c.users,list);return {saved:true,user:safeUser(user),relogin:user.id===p.userId&&action==='admin_set_password'};
}
