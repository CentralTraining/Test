export const SANDBOX_IDS=['primary','secondary'];
export const sandboxId=value=>value===undefined||value===null?'primary':SANDBOX_IDS.includes(value)?value:null;
export function sandboxCredentials(id,get){
 if(!SANDBOX_IDS.includes(id))throw Error('Unknown Sandbox');
 const prefix=id==='secondary'?'TIKTOK_SANDBOX2_':'TIKTOK_';
 return {client:get(prefix+'CLIENT_KEY')?.trim(),clientSecret:get(prefix+'CLIENT_SECRET')?.trim()};
}
