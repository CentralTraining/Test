-- Run in SQL Editor of the NEW Supabase project. This never deletes existing data.
create table if not exists public.trainer_hub_settings (
  key text primary key,
  value jsonb not null,
  version bigint not null default 1,
  updated_at timestamptz not null default now()
);
create table if not exists public.trainer_hub_private (
  key text primary key,
  value jsonb not null,
  version bigint not null default 1,
  updated_at timestamptz not null default now()
);
alter table public.trainer_hub_settings enable row level security;
alter table public.trainer_hub_private enable row level security;
revoke all on table public.trainer_hub_settings from public, anon, authenticated;
revoke all on table public.trainer_hub_private from public, anon, authenticated;
grant all on table public.trainer_hub_settings to service_role;
grant all on table public.trainer_hub_private to service_role;
insert into public.trainer_hub_settings (key,value) values
  ('auth_users','[]'::jsonb),
  ('config','{"regions":[],"trainers":[]}'::jsonb)
on conflict (key) do nothing;
