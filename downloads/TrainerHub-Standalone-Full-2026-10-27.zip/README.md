# Trainer Hub độc lập — 27/10/2026

Ứng dụng một file index.html, gồm đăng nhập và ba mục: Xây kênh TikTok, Khu vực & Trainer, Tài khoản. Dành cho dữ liệu riêng trên Supabase mới. Không có dữ liệu hoặc kết nối của Dashboard cũ trong bản xuất.

## Bắt đầu

1. Mở HUONG-DAN.html bằng trình duyệt. Có nút sao chép SQL và source máy chủ.
2. Tạo repository GitHub Pages riêng và project Supabase mới.
3. Chạy supabase/setup.sql trong SQL Editor; đặt APP_URL và BOOTSTRAP_TOKEN trong Secrets.
4. Triển khai trainer-hub-function.ts qua Supabase Editor với tên trainer-hub. Tắt Verify JWT vì function tự xác thực tài khoản nội bộ. Nếu dùng CLI, source module nằm trong supabase/functions/trainer-hub/ và supabase/config.toml có cấu hình tương ứng.
5. Điền supabaseUrl và publishableKey trong HUB_CONFIG ở đầu index.html; không điền service_role hoặc Client Secret. Upload index.html lên root repository và bật Pages từ main/root.
6. Tạo Admin đầu tiên tại link Pages. Sau đó tạo khu vực, Trainer và user trong ứng dụng.
7. Thiết lập ứng dụng/Sandbox TikTok riêng cho bản độc lập; thêm callback mới /functions/v1/trainer-hub/oauth/callback. Nhập Client Key/Secret vào Supabase Secrets; gán và kết nối các kênh mới.

terms.html và privacy.html là trang chính sách bổ sung cho URL TikTok, dùng thông tin Team Training Central đã được cung cấp. Kiểm tra tên đơn vị và email trước khi sử dụng. Các trang này không phải một phần phụ thuộc để chạy giao diện một file.

## Quyền

Admin quản lý khu vực, Trainer, tài khoản, phân kênh, mốc Follow và đồng bộ. Trainer xem chỉ số toàn team, kết nối kênh bản thân, đồng bộ trong khu vực phụ trách và đổi mật khẩu cá nhân. Máy chủ luôn kiểm tra lại tài khoản/quyền. Mật khẩu lưu bằng PBKDF2 có salt; token TikTok mã hóa AES-GCM; các bảng không cho trình duyệt đọc/ghi trực tiếp.

## Phạm vi dữ liệu

Dữ liệu mới bắt đầu trống. Giữ chỉ tiêu 3 video/tuần, bộ lọc và các biểu đồ từ module hiện có; mốc tháng 10/2026 nhập bởi Admin theo số thực tế ngày 01/10. Các tháng sau dùng quan sát thực tế đầu tiên trong ngày 01 theo giờ Việt Nam. Thiếu mốc để trống. API không tái tạo lịch sử follower. Like/View/Share là tổng mới nhất trên video đăng trong kỳ. Tự đồng bộ 15 phút hoạt động khi trang đang mở.

## Kiểm tra đã thực hiện

- Source backend gộp đúng một file và source module không có dependency ngoài.
- Backend với database/TikTok giả lập: khởi tạo Admin một lần, mật khẩu và phiên, khóa/tạm chặn đăng nhập, phân quyền, gán user, đọc toàn team, grant của hai Sandbox, callback một lần, sync/refresh và giữ mốc, không trả thông tin xác thực ra DTO.
- Trình duyệt 390 và 1440 px với backend giả lập: đăng nhập, thêm khu vực/Trainer/user, gán kênh, đổi mật khẩu/đăng nhập lại, Trainer chỉ thấy chức năng được cấp, bộ lọc và bảng, không tràn ngang, không truy cập bảng trực tiếp từ trình duyệt.
- Màn hình khởi tạo Admin qua giao diện, mã khởi tạo/mật khẩu không lưu trong sessionStorage, file chưa cấu hình không gọi project nào, hướng dẫn có SQL/source chính xác và copy được.
- Quét gói runtime: không có project URL cũ, fixture credentials hoặc dữ liệu người dùng thật.

Supabase và TikTok mới chưa được cấu hình trong bản xuất. Các bước kiểm tra trên sử dụng dữ liệu giả lập; thực hiện hướng dẫn để kết nối dịch vụ thật.
