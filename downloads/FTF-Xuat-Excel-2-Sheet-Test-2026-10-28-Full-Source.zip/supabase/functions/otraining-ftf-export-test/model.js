export const FtfExportModel=(()=>{
 const clean=v=>v==null?'':String(v).trim(),norm=v=>clean(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[Đđ]/g,'d').toLowerCase().replace(/[^a-z0-9]/g,''),record=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
 const first=v=>{if(Array.isArray(v))return clean(v[0]);if(typeof v==='string')try{const a=JSON.parse(v);if(Array.isArray(a))return clean(a[0]);}catch{}return clean(v);};
 const id=v=>/^[A-Za-z0-9_-]{1,140}$/.test(clean(v));
 const summaryColumns=['Mã Shop','Tên Shop','Kênh','Vùng','Khu vực','Tỉnh/Thành','Quận/Huyện','Ngày','Giờ','Người Train','SĐT Người Train','Sale QL','SL Dự Kiến','Số Đã Train','Trạng Thái'];
 const detailColumns=['Chiến dịch','Mã Shop','Kênh','Vùng','Khu vực','Tỉnh','Shop','Sale Quản lý','Người Train','Tên học viên','Trạng thái tư vấn mẫu','Test online','Khảo sát','Điểm Hài lòng'];
 function dateParts(value){
  if(!clean(value))return {date:'',time:''};
  const d=new Date(value);if(!Number.isFinite(d.getTime()))return {date:'',time:''};
  return {date:new Intl.DateTimeFormat('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',day:'2-digit',month:'2-digit',year:'numeric'}).format(d),time:new Intl.DateTimeFormat('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',hour:'2-digit',minute:'2-digit',hour12:false}).format(d)};
 }
 function status(value,kind){
  const s=norm(value);if(s==='dat'||kind==='test'&&s==='pass')return kind==='test'?'Pass':'Đạt';
  if(s==='chuadat'||kind==='test'&&s==='fail')return kind==='test'?'Fail':'Chưa đạt';
  if(!s||['chualam','notstarted'].includes(s))return 'Chưa làm';return 'Chưa xác định';
 }
 function survey(value){
  if(value==null||value===false||value===0||['','0','false','chua','chualam','no'].includes(norm(value)))return 'Chưa';
  if(value===true||value===1||['1','true','done','dat','yes','dalam','dakhoasat'].includes(norm(value)))return 'Done';
  if(typeof value==='string'&&Number.isFinite(Date.parse(value)))return 'Done';return 'Chưa xác định';
 }
 function numeric(value){if(value==null||clean(value)==='')return '';const n=Number(clean(value).replace(',','.'));if(!Number.isFinite(n))throw Error('number');return n;}
 function normalize(data,campaignId,selected,campaignName=''){
  if(!record(data)||!Array.isArray(data.mainSheetData)||!record(data.detailSheetData))throw Error('shape');
  const detail=data.detailSheetData;
  for(const name of ['statusMap','nameMap','surveyMap','simulationStatusMap','surveyScoreMap'])if(!record(detail[name]))throw Error('map');
  if(!Array.isArray(detail.allAttendees))throw Error('attendees');
  const byId=new Map(),byCode=new Map();
  for(const row of data.mainSheetData){
   if(!record(row)||!id(row.shop_id)||row.campaign_id!=null&&clean(row.campaign_id)!==clean(campaignId))throw Error('campaign');
   const sid=clean(row.shop_id),code=clean(row.store_id_excel);if(byId.has(sid))throw Error('duplicate_shop');byId.set(sid,row);
   if(code){if(!byCode.has(code))byCode.set(code,[]);byCode.get(code).push(row);}
  }
  const shops=[],included=new Set();
  for(const selectedShop of selected){
   const sid=clean(selectedShop.shopIdOtr),code=clean(selectedShop.shopCode),matches=code?byCode.get(code)||[]:[],row=sid?byId.get(sid):matches.length===1?matches[0]:null;
   if(!row||code&&code!==clean(row.store_id_excel)||norm(first(row.vung))!=='mientrung')throw Error('missing_shop');
   if(included.has(clean(row.shop_id)))throw Error('duplicate_selection');included.add(clean(row.shop_id));shops.push(row);
  }
  const summary=shops.map(s=>{
   const done=norm(s.status_calculated)==='done',when=dateParts(done?s.updated_at:s.training_date),start=clean(s.start_time).slice(0,5),end=clean(s.end_time).slice(0,5),time=done?when.time:start&&end?start+' - '+end:start;
   return [clean(s.store_id_excel),clean(s.store_name),first(s.channel),first(s.vung),clean(s.area),clean(s.province),clean(s.district),when.date,time,clean(s.assigned_person_name)||'Chưa gán',clean(s.assigned_person_phone),clean(s.sale_name)||clean(s.pg_names)||'Chưa gán',numeric(s.expected_quantity),numeric(s.checked_in_count),clean(s.status_calculated)];
  });
  const peopleByShop=new Map(shops.map(s=>[clean(s.shop_id),[]])),pairs=new Set();let duplicateAttendees=0,missingNames=0,unknownStatuses=0;
  for(const attendee of detail.allAttendees){
   if(!record(attendee)||!id(attendee.shop_id)||!id(attendee.user_id))throw Error('attendee');
   const sid=clean(attendee.shop_id),uid=clean(attendee.user_id);if(!byId.has(sid))throw Error('orphan');if(!included.has(sid))continue;
   const key=sid+':'+uid;if(pairs.has(key)){duplicateAttendees++;continue;}pairs.add(key);peopleByShop.get(sid).push(uid);
  }
  const rows=[];
  for(const s of shops)for(const uid of peopleByShop.get(clean(s.shop_id))){
   const name=clean(detail.nameMap[uid]);if(!name)missingNames++;
   const ai=status(detail.simulationStatusMap[uid],'ai'),test=status(detail.statusMap[uid],'test'),ks=survey(detail.surveyMap[uid]);if([ai,test,ks].includes('Chưa xác định'))unknownStatuses++;
   const score=numeric(detail.surveyScoreMap[uid]);if(score!==''&&(score<0||score>5))throw Error('score');
   rows.push([clean(detail.campaignName)||clean(campaignName),clean(s.store_id_excel),first(s.channel),first(s.vung),clean(s.area),clean(s.province),clean(s.store_name),clean(s.sale_name)||clean(s.pg_names)||'Chưa gán',clean(s.assigned_person_name)||'Chưa gán',name||'ID '+uid,ai,test,ks,score]);
  }
  return {sheets:[{name:'Tong Hop F2F',columns:summaryColumns,rows:summary},{name:'Chi Tiet Check-in',columns:detailColumns,rows}],shopCount:shops.length,attendeeCount:rows.length,warnings:{duplicateAttendees,missingNames,unknownStatuses}};
 }
 return {clean,norm,id,first,record,summaryColumns,detailColumns,status,survey,normalize};
})();
