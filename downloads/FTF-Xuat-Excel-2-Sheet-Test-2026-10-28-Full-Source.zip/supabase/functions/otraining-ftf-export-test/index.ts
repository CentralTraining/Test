import {authenticate,AccessError,readDashboardValues} from './access.ts';
import {FtfExportModel as M} from './model.js';
const ORIGIN='https://centraltraining.github.io',CORS={'Access-Control-Allow-Origin':ORIGIN,'Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'POST,OPTIONS','Cache-Control':'no-store','Vary':'Origin'};
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{...CORS,'Content-Type':'application/json'}});
const fail=(message,status=400)=>{throw new AccessError(message,status);};
async function authorizeSelection(body){
 const p=await authenticate(body.dashboardToken);
 if(!M.id(body.campaignKey)||!/^\d{4}-(0[1-9]|1[0-2])$/.test(body.month||'')||!Array.isArray(body.shopIds)||!body.shopIds.length||body.shopIds.length>5000||body.shopIds.some(id=>typeof id!=='string'||!M.id(id))||new Set(body.shopIds).size!==body.shopIds.length)fail('Chiến dịch, tháng hoặc danh sách shop chưa hợp lệ.');
 const data=await readDashboardValues(['campaigns','ftfShopList:'+body.month,'ftfTargetRows:'+body.campaignKey]);
 const camp=(data.campaigns||[]).find(c=>String(c.id)===body.campaignKey&&c.month===body.month&&c.group==='doitac'&&(c.subtype||'ftf')==='ftf');
 if(!camp||!M.id(camp.otrId))fail('Admin chưa cấu hình ID chiến dịch FTF hợp lệ cho tháng đang xem.',409);
 const list=data['ftfShopList:'+body.month],targets=data['ftfTargetRows:'+body.campaignKey];
 if(!Array.isArray(list))fail('Chưa có danh sách shop FTF đã lưu cho tháng này.',409);
 if(p.role!=='admin'&&!Array.isArray(targets))fail('Chưa có Target FTF để kiểm tra quyền theo shop.',409);
 const selected=[];
 for(const id of body.shopIds){
  const matches=list.filter(s=>String(s.id)===id);if(matches.length!==1)fail('Danh sách shop đã thay đổi. Hãy tải lại bảng FTF trước khi xuất.',409);
  const shop=matches[0],t=p.trainers.find(t=>String(t.id)===String(shop.trainerId));
  if(!shop.trainerId||!t)fail('Shop chưa được gán Trainer hợp lệ.',409);
  if(p.role!=='admin'){
   if(p.role!=='trainer'||String(shop.trainerId)!==String(p.trainerId)||M.norm(t.region)!==M.norm(p.region))fail('Shop nằm ngoài phạm vi Trainer được phép xuất.',403);
   const code=M.clean(shop.shopCode),sid=M.clean(shop.shopIdOtr),matched=targets.filter(r=>(code&&M.clean(r.storeId)===code)||(sid&&M.clean(r.storeId)===sid)),owners=new Set(matched.map(r=>String(r.trainerId||'')));
   const allowed=owners.size===1&&owners.has(String(p.trainerId))&&matched.every(r=>!r.region||M.norm(r.region)===M.norm(p.region));
   if(!allowed)fail('Shop không thuộc Target FTF do Trainer được phân công.',403);
  }
  if(shop.aiCampaignId&&String(shop.aiCampaignId)!==M.clean(camp.otrId))fail('Danh sách shop đang thuộc nguồn chiến dịch cũ. Hãy cập nhật FTF trước khi xuất.',409);
  selected.push({id:String(shop.id),shopCode:M.clean(shop.shopCode),shopIdOtr:M.clean(shop.shopIdOtr),trainerId:String(shop.trainerId),region:M.clean(t.region)});
 }
 return {p,camp,selected,signature:JSON.stringify([String(camp.id),M.clean(camp.otrId),selected])};
}
Deno.serve(async req=>{
 const origin=req.headers.get('origin');if(origin&&origin!==ORIGIN)return json({error:'Nguồn truy cập không hợp lệ.'},403);if(req.method==='OPTIONS')return new Response(null,{status:204,headers:CORS});if(req.method!=='POST')return json({error:'Chỉ hỗ trợ POST.'},405);
 try{
  if(Number(req.headers.get('content-length')||0)>200000)fail('Danh sách xuất quá dài.',413);const raw=await req.text();if(raw.length>200000)fail('Danh sách xuất quá dài.',413);let body;try{body=JSON.parse(raw);}catch{fail('Yêu cầu xuất Excel không hợp lệ.');}
  if(!M.record(body)||body.type!=='ftfexport')fail('Yêu cầu xuất Excel không hợp lệ.');
  const ctx=await authorizeSelection(body),userInfo=Deno.env.get('OTRAINING_USER_INFO');if(!userInfo)fail('Chưa sẵn sàng kết nối nguồn FTF.',503);
  // Reuse the existing server credential and user-supplied upstream request contract.
  // This read-only request runs only after fresh Dashboard/selected-shop authorization.
  let data;
  try{
   const response=await fetch('https://otraining.io.vn/api/qrcode/f2f-visits/download-all',{method:'POST',redirect:'error',headers:{'Content-Type':'application/json','Accept':'application/json','Origin':'https://otraining.io.vn','Referer':'https://otraining.io.vn/doitac_f2f.html?id='+M.clean(ctx.camp.otrId),'x-user-info':userInfo},body:JSON.stringify({campaignId:M.clean(ctx.camp.otrId),userId:458,userType:'Leader',userArea:'Mien Trung',status:null,shopName:null,areaFilter:null,vungFilter:'Mien Trung'}),signal:AbortSignal.timeout(40000)});
   if(!response.ok)fail('Nguồn FTF chưa trả dữ liệu xuất (HTTP '+response.status+'). Chưa tạo file.',502);data=await response.json();
  }catch(error){if(error instanceof AccessError)throw error;fail('Chưa đọc được nguồn FTF. Chưa tạo file, hãy thử lại sau.',502);}
  let workbook;try{workbook=M.normalize(data,M.clean(ctx.camp.otrId),ctx.selected,ctx.camp.name);}catch{fail('Nguồn FTF thiếu dữ liệu hoặc chưa khớp đủ shop/chiến dịch. Hãy cập nhật FTF rồi xuất lại; chưa tạo file thiếu hoặc số liệu giả.',502);}
  const latest=await authorizeSelection(body);if(latest.p.userId!==ctx.p.userId||latest.p.role!==ctx.p.role||latest.signature!==ctx.signature)fail('Phân công hoặc chiến dịch vừa thay đổi. Hãy tải lại trước khi xuất.',409);
  return json({ok:true,campaignKey:String(ctx.camp.id),campaignId:M.clean(ctx.camp.otrId),month:body.month,readAt:new Date().toISOString(),source:'otraining-f2f-download-all',...workbook});
 }catch(error){return json({error:error instanceof AccessError?error.message:'Chưa xuất được Excel FTF. Dữ liệu đã lưu được giữ nguyên.'},error instanceof AccessError?error.status:503);}
});
