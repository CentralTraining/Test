import { authenticate, AccessError, readDashboardValues } from './access.ts';
import { PairModel } from './model.js';
const ORIGIN='https://centraltraining.github.io';
const CORS={'Access-Control-Allow-Origin':ORIGIN,'Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'POST,OPTIONS','Cache-Control':'no-store','Vary':'Origin'};
const reply=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{...CORS,'Content-Type':'application/json'}});
const failure=(message,status=400)=>{throw new AccessError(message,status);};
const validId=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,140}$/.test(v);
const validGroupId=v=>typeof v==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(v);
async function groupDb(query,options={}){
 const base=Deno.env.get('SUPABASE_URL'),secret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
 if(!base||!secret)failure('Chưa sẵn sàng lưu nhóm Find Master.',503);
 let response;try{response=await fetch(base+'/rest/v1/pgsm_pair_groups?'+query.toString(),{...options,headers:{apikey:secret,Authorization:'Bearer '+secret,'Content-Type':'application/json',Prefer:'return=representation',...options.headers},signal:AbortSignal.timeout(12000)});}catch{failure('Chưa xác nhận được danh sách nhóm. Hãy tải lại trước khi thử lưu tiếp.',503);}
 if(!response.ok)failure('Không đọc/lưu được nhóm Find Master. Danh sách đã xác nhận được giữ nguyên.',503);
 const rows=await response.json();if(!Array.isArray(rows))failure('Phản hồi danh sách nhóm chưa hợp lệ.',503);return rows;
}
async function context(body){
 const p=await authenticate(body.dashboardToken);
 if(!validId(body.campaignId)||!/^\d{4}-(0[1-9]|1[0-2])$/.test(body.month||''))failure('Chiến dịch hoặc tháng không hợp lệ.');
 const keys=['campaigns','pgsMaster:'+body.campaignId,'monthLock:'+body.month],data=await readDashboardValues(keys);
 const camp=(data.campaigns||[]).find(c=>String(c.id)===body.campaignId&&c.month===body.month&&c.group==='noibo'&&c.subtype==='pgsmaster');
 if(!camp)failure('Chiến dịch Find Master không thuộc tháng đang xem.',403);
 const master=data['pgsMaster:'+body.campaignId];if(!master||!Array.isArray(master.registered))failure('Chưa có danh sách Find Master đã chốt.',409);
 const trainers=(p.trainers||[]).filter(t=>p.role==='admin'||PairModel.norm(t.region)===PairModel.norm(p.region));
 const ids=new Set(trainers.map(t=>String(t.id)));
 const query=new URLSearchParams({campaign_id:'eq.'+body.campaignId,select:'trainer_id,version,groups,updated_at'});
 if(p.role!=='admin')query.set('trainer_id','in.('+trainers.map(t=>String(t.id)).filter(validId).join(',')+')');
 const records=trainers.length?await groupDb(query):[];
 const visible=records.filter(r=>ids.has(String(r.trainer_id)));
 return {p,camp,master,trainers,records:visible,monthLocked:data['monthLock:'+body.month]===true};
}
async function view(ctx){
 const {p,master,trainers,records,monthLocked}=ctx;
 const result=[];
 for(const trainer of trainers){
  const roster=PairModel.roster(master.registered,master.systemMeta,trainer),record=records.find(r=>String(r.trainer_id)===String(trainer.id));
  if(record&&(!Number.isSafeInteger(Number(record.version))||!Array.isArray(record.groups)))failure('Dữ liệu nhóm đã lưu chưa đúng định dạng.',503);
  const bytes=new TextEncoder().encode(JSON.stringify(roster.map(p=>[p.code,p.name,p.channel,p.region,p.trainerId])));
  const rosterRevision=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
  const groups=(record?.groups||[]).map(g=>PairModel.group(g,roster,trainer.id));
  result.push({id:String(trainer.id),name:String(trainer.name||''),region:String(trainer.region||''),version:Number(record?.version||0),rosterRevision,roster,groups,updatedAt:record?.updated_at||null,canManage:!!master.locked&&!monthLocked&&(p.role==='admin'||String(trainer.id)===String(p.trainerId))});
 }
 return {ok:true,campaignId:String(ctx.camp.id),month:ctx.camp.month,monthLocked,rosterLocked:!!master.locked,sourceUpdatedAt:master.systemUpdatedAt||null,role:p.role,ownTrainerId:p.trainerId,trainers:result};
}
async function handle(body){
 if(!['view','save','delete'].includes(body.action))failure('Thao tác không hợp lệ.');
 const ctx=await context(body),current=await view(ctx);
 if(body.action==='view')return current;
 const tid=String(body.trainerId||''),trainer=current.trainers.find(t=>t.id===tid);
 if(!trainer||ctx.p.role!=='admin'&&tid!==String(ctx.p.trainerId))failure('Chỉ được ghép nhóm PG do chính Trainer phụ trách.',403);
 if(!trainer.canManage)failure(ctx.monthLocked?'Tháng đã khóa, không thể sửa nhóm.':'Cần chốt danh sách Find Master trước khi ghép nhóm.',409);
 if(!Number.isSafeInteger(body.expectedVersion)||body.expectedVersion!==trainer.version||body.rosterRevision!==trainer.rosterRevision)failure('Danh sách nhóm hoặc PG đã thay đổi. Hãy tải lại trước khi lưu.',409);
 const stored=ctx.records.find(r=>String(r.trainer_id)===tid),groups=JSON.parse(JSON.stringify(stored?.groups||[]));
 const groupId=body.action==='save'?body.group?.id:body.groupId;
 if(!validGroupId(groupId))failure('Mã nhóm không hợp lệ.');
 const existing=groups.findIndex(g=>g.id===groupId),now=new Date().toISOString();
 if(body.action==='delete'){
  if(existing<0)failure('Nhóm không còn tồn tại. Hãy tải lại danh sách.',409);
  groups.splice(existing,1);
 }else{
  const error=PairModel.validate(body.group?.members,trainer.roster,groups,groupId);if(error)failure(error,409);
  const next={id:groupId,members:body.group.members.map(PairModel.code),createdAt:existing<0?now:groups[existing].createdAt,updatedAt:now};
  if(existing<0)groups.push(next);else groups[existing]=next;
  if(groups.length>500)failure('Số nhóm vượt giới hạn của Trainer.');
 }
 // Confirm roster/permission/lock again before the compare-and-swap write.
 const latest=await context(body),latestView=await view(latest),owner=latestView.trainers.find(t=>t.id===tid);
 if(!owner?.canManage||owner.version!==trainer.version||owner.rosterRevision!==trainer.rosterRevision)failure('Danh sách hoặc quyền vừa thay đổi. Hãy tải lại trước khi lưu.',409);
 const payload={campaign_id:body.campaignId,trainer_id:tid,version:trainer.version+1,groups,updated_by:ctx.p.userId,updated_at:now};
 const query=new URLSearchParams({campaign_id:'eq.'+body.campaignId,trainer_id:'eq.'+tid,select:'trainer_id,version,groups,updated_at'});
 let saved;
 if(trainer.version===0)saved=await groupDb(new URLSearchParams({select:'trainer_id,version,groups,updated_at'}),{method:'POST',headers:{Prefer:'resolution=ignore-duplicates,return=representation'},body:JSON.stringify(payload)});
 else {query.set('version','eq.'+trainer.version);saved=await groupDb(query,{method:'PATCH',body:JSON.stringify(payload)});}
 if(saved.length!==1)failure('Nhóm vừa được cập nhật ở phiên khác. Hãy tải lại; chưa ghi đè thay đổi mới.',409);
 latest.records=latest.records.filter(r=>String(r.trainer_id)!==tid).concat(saved);
 return {...await view(latest),saved:true};
}
Deno.serve(async req=>{
 const origin=req.headers.get('origin');if(origin&&origin!==ORIGIN)return reply({error:'Nguồn truy cập không hợp lệ.'},403);
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:CORS});
 if(req.method!=='POST')return reply({error:'Chỉ hỗ trợ POST.'},405);
 try{
  if(Number(req.headers.get('content-length')||0)>5000)failure('Yêu cầu quá dài.');
  const raw=await req.text();if(raw.length>5000)failure('Yêu cầu quá dài.');let body;try{body=JSON.parse(raw);}catch{failure('Yêu cầu không hợp lệ.');}
  if(!body||typeof body!=='object'||Array.isArray(body))failure('Yêu cầu không hợp lệ.');
  return reply(await handle(body));
 }catch(error){return reply({error:error instanceof AccessError?error.message:'Chưa xử lý được nhóm Find Master. Hãy tải lại để kiểm tra kết quả đã lưu.'},error instanceof AccessError?error.status:503);}
});
