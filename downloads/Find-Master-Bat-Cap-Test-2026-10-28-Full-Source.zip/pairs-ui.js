const pgsmPairViews_=new Map();
const pgsmPairOwner_=()=>JSON.stringify([session?.userId,session?.role,session?.trainerId,session?.region]);
function pgsmPairCurrent_(state){return state.root?.isConnected&&state.owner===pgsmPairOwner_()&&currentMonth===state.camp.month&&String(document.getElementById('pgsmProgressCampaign')?.value||'')===String(state.camp.id);}
async function pgsmPairCall_(state,action,extra={}){
 const tokenPromise=workshopNoiboToken_(),title=document.querySelector('#wsnbAuthOverlay h3');if(title)title.textContent='Xác thực nhóm Find Master';
 const token=await tokenPromise;if(!pgsmPairCurrent_(state))throw Error('Tài khoản hoặc chiến dịch đã thay đổi. Hãy mở lại Find Master.');
 const name=location.pathname.startsWith('/Test/')?'pgsm-pairs-test':'pgsm-pairs';
 const response=await fetch(SUPABASE_URL+'/functions/v1/'+name,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+OTRAINING_ANON_KEY_},body:JSON.stringify({action,campaignId:String(state.camp.id),month:state.camp.month,dashboardToken:token,...extra}),signal:AbortSignal.timeout(30000)});
 let out;try{out=await response.json();}catch{throw Error('Chưa nhận được xác nhận. Hãy tải lại danh sách nhóm trước khi thử lưu tiếp.');}
 if(response.status===401)sessionStorage.removeItem('workshop_private_session');
 if(!response.ok||!out.ok)throw Object.assign(Error(out.error||'Không đọc/lưu được nhóm Find Master.'),{status:response.status});
 if(out.campaignId!==String(state.camp.id)||out.month!==state.camp.month||!Array.isArray(out.trainers))throw Error('Danh sách nhóm chưa đúng chiến dịch đang xem.');
 return out;
}
async function pgsmPairLoad_(state){
 if(state.busy||!pgsmPairCurrent_(state))return;
 const run=++state.run;state.busy=true;state.error='';pgsmPairDraw_(state);
 try{const out=await pgsmPairCall_(state,'view');if(run!==state.run||!pgsmPairCurrent_(state))return;state.data=out;state.editor=null;state.message='';}
 catch(error){if(run===state.run&&pgsmPairCurrent_(state)){state.error=error.message;if([401,403].includes(error.status))state.data=null;}}
 finally{if(run===state.run&&pgsmPairCurrent_(state)){state.busy=false;pgsmPairDraw_(state);}}
}
async function pgsmPairMutate_(state,action,extra){
 if(state.busy||!pgsmPairCurrent_(state))return;
 const run=++state.run;state.busy=true;state.error='';state.message='';pgsmPairDraw_(state);
 try{const out=await pgsmPairCall_(state,action,extra);if(run!==state.run||!pgsmPairCurrent_(state))return;state.data=out;state.editor=null;state.message=action==='delete'?'Đã xóa nhóm. Các PG có thể được ghép lại.':'Đã lưu nhóm Find Master.';}
 catch(error){if(run===state.run&&pgsmPairCurrent_(state)){state.error=error.message;if([401,403].includes(error.status)){state.data=null;state.editor=null;}}}
 finally{if(run===state.run&&pgsmPairCurrent_(state)){state.busy=false;pgsmPairDraw_(state);}}
}
function pgsmPairOpenEditor_(state,trainerId,groupId){
 const trainer=state.data?.trainers.find(t=>t.id===trainerId&&t.canManage);if(!trainer)return;
 const group=trainer.groups.find(g=>g.id===groupId);
 state.editor={trainerId,id:group?.id||crypto.randomUUID(),selected:new Set(group?.members.map(p=>p.code)||[]),editing:!!group};state.error='';pgsmPairDraw_(state);
}
function pgsmPairBadge_(progress){
 const done=progress.done,unknown=progress.known<progress.total;
 return `<span class="pgsm-pair-score ${done?'is-pass':unknown?'is-unknown':'is-pending'}" title="${progress.passed}/${progress.total} thành viên đạt${unknown?' · Chưa đủ kết quả của tất cả thành viên':''}">${done?'✓ ':''}${progress.passed}/${progress.total}${unknown?' ?':''}</span>`;
}
function pgsmPairDetail_(trainer,group){
 const e=escapeHtml;
 return `<article class="pgsm-pair-group" data-pair-group="${e(group.id)}"><div class="pgsm-pair-group-name"><b>${e(group.name)}</b><small>${e(trainer.name)} · ${group.members.length} PG${group.valid?'':' · Cần ghép lại'}</small></div><div class="pgsm-pair-group-channels"><span>Kênh</span><b>${e(group.channels.join(' · ')||'Chưa gán kênh')}</b></div><div class="pgsm-pair-group-members">${group.members.map(p=>`<span title="${e(p.code)}">${e(p.name)} <small>(${e(p.code)})</small></span>`).join('')}</div><div class="pgsm-pair-five">${PGSM_STAGES_.map(m=>`<div><small title="${e(m.label)}">${e(m.id.toUpperCase())}</small>${pgsmPairBadge_(group.progress[m.id])}</div>`).join('')}</div><div class="pgsm-pair-group-result"><b>${group.completed===5?'🏆 Đủ 5 mốc':group.completed+'/5 mốc'}</b>${trainer.canManage?`<div><button type="button" class="secondary" data-pair-edit="${e(group.id)}" data-pair-owner="${e(trainer.id)}">Sửa</button><button type="button" class="secondary" data-pair-delete="${e(group.id)}" data-pair-owner="${e(trainer.id)}">Xóa</button></div>`:''}</div></article>`;
}
function pgsmPairEditor_(state){
 const editor=state.editor;if(!editor)return '';
 const e=escapeHtml,trainer=state.data.trainers.find(t=>t.id===editor.trainerId);if(!trainer?.canManage)return '';
 const raw=trainer.groups.map(g=>({id:g.id,members:g.members.map(p=>p.code)}));
 const used=new Map(raw.filter(g=>g.id!==editor.id).flatMap(g=>g.members.map(code=>[code,g.id])));
 const max=trainer.roster.length%2===1&&!raw.some(g=>g.id!==editor.id&&g.members.length===3)?3:2;
 const selected=[...editor.selected].map(code=>trainer.roster.find(p=>p.code===code)).filter(Boolean),name=selected.map(p=>PairModel.firstName(p.name)).join(' - ');
 const validation=PairModel.validate([...editor.selected],trainer.roster,raw,editor.id);
 return `<section class="pgsm-pair-editor" aria-label="Ghép nhóm PGs"><div class="pgsm-pair-editor-head"><div><h4>${editor.editing?'Chỉnh sửa nhóm':'Tạo nhóm Find Master'}</h4><p>Chọn 2 PG${max===3?' hoặc 3 PG vì danh sách của Trainer có số lẻ':''}. Mỗi PG chỉ thuộc một nhóm.</p></div><button type="button" class="secondary" data-pair-cancel ${state.busy?'disabled':''}>Đóng</button></div>${state.data.role==='admin'?`<label>Trainer phụ trách<select id="pgsmPairManageTrainer" ${editor.editing||state.busy?'disabled':''}>${state.data.trainers.filter(t=>t.canManage).map(t=>`<option value="${e(t.id)}" ${t.id===trainer.id?'selected':''}>${e(t.name)} · ${t.roster.length} PG</option>`).join('')}</select></label>`:`<p class="pgsm-pair-owner">${e(trainer.name)} · ${e(trainer.region)}</p>`}<div class="pgsm-pair-builder"><div class="pgsm-pair-candidates">${trainer.roster.map(p=>`<label class="${used.has(p.code)?'is-used':''}"><input type="checkbox" data-pair-member="${e(p.code)}" ${editor.selected.has(p.code)?'checked':''} ${state.busy||used.has(p.code)||!editor.selected.has(p.code)&&editor.selected.size>=max?'disabled':''}><span><b>${e(p.name)}</b><small>${e(p.code)} · ${e(p.channel||'Chưa gán kênh')}${used.has(p.code)?' · Đã có nhóm':''}</small></span></label>`).join('')||'<p>Chưa có PG Master được chốt cho Trainer này.</p>'}</div><div class="pgsm-pair-preview"><small>Tên nhóm tự tạo</small><strong>${e(name||'Chọn thành viên')}</strong><p>${editor.selected.size} thành viên đã chọn</p>${validation?`<p class="pgsm-pair-form-note">${e(validation)}</p>`:'<p class="pgsm-pair-form-ok">Đủ thành viên để lưu nhóm.</p>'}<button type="button" class="primary" data-pair-save ${state.busy||validation?'disabled':''}>${state.busy?'Đang lưu…':'Lưu nhóm'}</button></div></div></section>`;
}
function pgsmPairDraw_(state){
 if(!pgsmPairCurrent_(state))return;const host=state.root.querySelector('#pgsmPairHost');if(!host)return;
 const e=escapeHtml,data=state.data;
 if(!data){host.innerHTML=`<div class="form-card pgsm-pair-card"><h3>Bắt cặp thi đua Find Master</h3><p>Ghép PG của cùng Trainer thành nhóm 2 hoặc nhóm 3 khi lẻ. Mỗi mốc chỉ đạt khi tất cả thành viên đều đạt.</p>${state.error?`<p class="pgsm-pair-error" role="alert">${e(state.error)}</p>`:''}<button type="button" class="primary" id="pgsmPairsReload" ${state.busy?'disabled':''}>${state.busy?'Đang tải nhóm…':'Mở danh sách nhóm'}</button></div>`;host.querySelector('#pgsmPairsReload').onclick=()=>pgsmPairLoad_(state);return;}
 const trainers=data.trainers.filter(t=>(!state.region||PairModel.norm(t.region)===PairModel.norm(state.region))&&(!state.trainer||t.id===state.trainer));
 const allGroups=trainers.flatMap(t=>t.groups.map(g=>({...g,owner:t}))),search=PairModel.norm(state.search);
 const groups=allGroups.filter(g=>(!state.channel||g.channels.includes(state.channel))&&(!search||PairModel.norm(g.name+' '+g.members.map(p=>p.name+' '+p.code).join(' ')).includes(search)));
 const grouped=new Map();for(const t of trainers){const key=state.groupBy==='region'?t.region:t.id;if(!grouped.has(key))grouped.set(key,{key,label:state.groupBy==='region'?t.region:t.name,groups:[]});grouped.get(key).groups.push(...groups.filter(g=>g.owner.id===t.id));}
 const summaryRows=[{key:'__all__',label:data.role==='admin'?'TỔNG PHẠM VI':'TỔNG KHU VỰC',groups,total:true},...[...grouped.values()].sort((a,b)=>a.label.localeCompare(b.label,'vi'))];
 const regions=[...new Set(data.trainers.map(t=>t.region))].filter(Boolean),channels=[...new Set(allGroups.flatMap(g=>g.channels))].sort((a,b)=>a.localeCompare(b,'vi'));
 const choices=data.trainers.filter(t=>!state.region||PairModel.norm(t.region)===PairModel.norm(state.region));
 const canManage=data.trainers.some(t=>t.canManage),manage= data.role==='trainer'?data.ownTrainerId:state.trainer||data.trainers.find(t=>t.canManage&&t.roster.length>=2)?.id;
 const unpaired=trainers.reduce((sum,t)=>{const assigned=new Set(t.groups.flatMap(g=>g.members.filter(p=>!p.missing).map(p=>p.code)));return sum+t.roster.filter(p=>!assigned.has(p.code)).length;},0);
 const stats=PairModel.summary(groups);
 const detail=entry=>{
  const page=Math.min(state.pages.get(entry.key)||1,Math.max(1,Math.ceil(entry.groups.length/8)));state.pages.set(entry.key,page);
  return `<div class="pgsm-pair-expanded" data-pair-expanded="${e(entry.key)}"><div class="pgsm-pair-list-heading"><b>Tên nhóm · Kênh · Thành viên · Tiến độ 5 mốc</b><span>${entry.groups.length} nhóm</span></div>${entry.groups.slice((page-1)*8,page*8).map(g=>pgsmPairDetail_(g.owner,g)).join('')}${entry.groups.length>8?`<div class="pgsm-pair-pagination"><button type="button" class="secondary" data-pair-page="${e(entry.key)}" data-page="${page-1}" ${page<=1?'disabled':''}>‹</button><span>${page}/${Math.ceil(entry.groups.length/8)}</span><button type="button" class="secondary" data-pair-page="${e(entry.key)}" data-page="${page+1}" ${page*8>=entry.groups.length?'disabled':''}>›</button></div>`:''}</div>`;
 };
 host.innerHTML=`<section class="form-card pgsm-pair-card"><div class="pgsm-pair-heading"><div><h3>Bắt cặp thi đua Find Master</h3><p>Một mốc của nhóm chỉ Đạt khi cả 2 hoặc 3 thành viên cùng đạt mốc đó.</p></div><div><button type="button" class="secondary" id="pgsmPairsReload" ${state.busy?'disabled':''}>↻ Tải lại</button>${canManage?`<button type="button" class="primary" id="pgsmPairsCreate" ${state.busy||!manage?'disabled':''}>＋ Tạo nhóm</button>`:''}</div></div>
 ${state.error?`<p class="pgsm-pair-error" role="alert">${e(state.error)}</p>`:''}${state.message?`<p class="pgsm-pair-success" role="status">${e(state.message)}</p>`:''}
 <div class="pgsm-pair-overview"><div><span>Số cặp trong bộ lọc</span><b>${stats.total}</b></div><div><span>Nhóm đủ 5 mốc</span><b>${stats.completed}</b></div><div><span>PG chưa ghép trong phạm vi</span><b>${unpaired}</b></div></div>
 ${data.monthLocked?'<p class="pgsm-pair-notice">Tháng đã khóa. Có thể xem tiến độ, chưa thể sửa nhóm.</p>':''}${stats.invalid?`<p class="pgsm-pair-notice">${stats.invalid} nhóm cần ghép lại do danh sách thành viên thay đổi. Các nhóm này chưa được tính đạt mốc.</p>`:''}
 ${pgsmPairEditor_(state)}
 <div class="scope-filters pgsm-pair-filters"><label>Xem theo<select id="pgsmPairGroupBy"><option value="trainer" ${state.groupBy==='trainer'?'selected':''}>Trainer</option><option value="region" ${state.groupBy==='region'?'selected':''}>Khu vực</option></select></label><label>Khu vực<select id="pgsmPairRegion"><option value="">Tất cả khu vực</option>${regions.map(v=>`<option value="${e(v)}" ${state.region===v?'selected':''}>${e(v)}</option>`).join('')}</select></label><label>Trainer<select id="pgsmPairTrainer"><option value="">Tất cả Trainer</option>${choices.map(t=>`<option value="${e(t.id)}" ${state.trainer===t.id?'selected':''}>${e(t.name)}</option>`).join('')}</select></label><label>Kênh<select id="pgsmPairChannel"><option value="">Tất cả kênh</option>${channels.map(c=>`<option value="${e(c)}" ${state.channel===c?'selected':''}>${e(c)}</option>`).join('')}</select></label><label>Tìm nhóm / thành viên<input id="pgsmPairSearch" value="${e(state.search)}" placeholder="Tên nhóm, tên hoặc mã PG"></label></div>
 <div class="pgsm-pair-summary" role="table" aria-label="Tiến độ nhóm Find Master"><div class="pgsm-pair-summary-head" role="row"><b>${state.groupBy==='trainer'?'Trainer':'Khu vực'}</b><b>Số cặp</b>${PGSM_STAGES_.map(m=>`<b title="${e(m.label)}">${e(m.id.toUpperCase())}</b>`).join('')}<b>Đủ 5 mốc</b></div>${summaryRows.map(entry=>{const sum=PairModel.summary(entry.groups);return `<div class="pgsm-pair-summary-row ${entry.total?'is-total':''}" role="row"><b class="pgsm-pair-summary-label">${e(entry.label||'Chưa xác định')}</b><div class="pgsm-pair-summary-count" role="cell"><strong>${sum.total}</strong><button type="button" data-pair-expand="${e(entry.key)}" aria-label="${state.expanded.has(entry.key)?'Thu gọn':'Xem nhóm'} ${e(entry.label)}" aria-expanded="${state.expanded.has(entry.key)}" ${!sum.total?'disabled':''}>${state.expanded.has(entry.key)?'−':'+'}</button></div>${sum.stages.map((n,i)=>`<div class="pgsm-pair-summary-stage" role="cell" data-label="M${i+1}"><span>${n}/${sum.total}</span><i><em style="width:${sum.total?n/sum.total*100:0}%"></em></i></div>`).join('')}<div class="pgsm-pair-summary-complete" role="cell" data-label="Đủ 5 mốc">${sum.completed}/${sum.total}</div></div>${state.expanded.has(entry.key)?detail(entry):''}`;}).join('')}</div>
 <p class="pgsm-pair-footnote">${PGSM_STAGES_.map(m=>e(m.label)).join(' &nbsp;|&nbsp; ')}</p><p class="pgsm-pair-footnote">M1–M5 lấy từ kết quả Find Master hiện tại. Dấu ? là chưa đủ kết quả của thành viên. Nhóm 3 được tính là một nhóm trong cột Số cặp.${data.sourceUpdatedAt?' Kết quả cập nhật: '+e(new Date(data.sourceUpdatedAt).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'}))+'.':''}</p></section>`;
 host.querySelector('#pgsmPairsReload').onclick=()=>pgsmPairLoad_(state);
 host.querySelector('#pgsmPairsCreate')?.addEventListener('click',()=>pgsmPairOpenEditor_(state,manage));
 const change=(id,key,reset)=>host.querySelector('#'+id).onchange=event=>{state[key]=event.target.value;if(reset){state.trainer='';state.channel='';}state.pages.clear();pgsmPairDraw_(state);};
 change('pgsmPairGroupBy','groupBy');change('pgsmPairRegion','region',true);change('pgsmPairTrainer','trainer');change('pgsmPairChannel','channel');
 host.querySelector('#pgsmPairSearch').onchange=event=>{state.search=event.target.value;state.pages.clear();pgsmPairDraw_(state);};
 host.querySelectorAll('[data-pair-expand]').forEach(b=>b.onclick=()=>{const key=b.dataset.pairExpand;state.expanded.has(key)?state.expanded.delete(key):state.expanded.add(key);pgsmPairDraw_(state);});
 host.querySelectorAll('[data-pair-page]').forEach(b=>b.onclick=()=>{state.pages.set(b.dataset.pairPage,Number(b.dataset.page));pgsmPairDraw_(state);});
 host.querySelectorAll('[data-pair-edit]').forEach(b=>b.onclick=()=>pgsmPairOpenEditor_(state,b.dataset.pairOwner,b.dataset.pairEdit));
 host.querySelectorAll('[data-pair-delete]').forEach(b=>b.onclick=async()=>{const trainer=data.trainers.find(t=>t.id===b.dataset.pairOwner&&t.canManage),group=trainer?.groups.find(g=>g.id===b.dataset.pairDelete);if(!group||state.busy)return;if(!await showConfirm('Xóa nhóm '+group.name+'? Kết quả thi cá nhân vẫn được giữ nguyên.'))return;await pgsmPairMutate_(state,'delete',{trainerId:trainer.id,groupId:group.id,expectedVersion:trainer.version,rosterRevision:trainer.rosterRevision});});
 host.querySelector('[data-pair-cancel]')?.addEventListener('click',()=>{state.editor=null;pgsmPairDraw_(state);});
 host.querySelector('#pgsmPairManageTrainer')?.addEventListener('change',event=>pgsmPairOpenEditor_(state,event.target.value));
 host.querySelectorAll('[data-pair-member]').forEach(input=>input.onchange=()=>{input.checked?state.editor.selected.add(input.dataset.pairMember):state.editor.selected.delete(input.dataset.pairMember);pgsmPairDraw_(state);});
 host.querySelector('[data-pair-save]')?.addEventListener('click',async()=>{const editor=state.editor,trainer=data.trainers.find(t=>t.id===editor?.trainerId&&t.canManage);if(!editor||!trainer||state.busy)return;await pgsmPairMutate_(state,'save',{trainerId:trainer.id,expectedVersion:trainer.version,rosterRevision:trainer.rosterRevision,group:{id:editor.id,members:[...editor.selected]}});});
}
function pgsmPairsMount_(camp,root){
 const owner=pgsmPairOwner_(),key=owner+'|'+camp.month+'|'+camp.id;
 let state=pgsmPairViews_.get(key);if(!state){state={owner,camp,root,mode:'individual',groupBy:'trainer',region:'',trainer:'',channel:'',search:'',expanded:new Set(),pages:new Map(),data:null,editor:null,error:'',message:'',busy:false,run:0};pgsmPairViews_.set(key,state);}
 state.root=root;state.camp=camp;state.run++;state.busy=false;
 const individual=root.querySelector('#pgsmIndividuals'),host=root.querySelector('#pgsmPairHost'),a=root.querySelector('#pgsmViewIndividual'),b=root.querySelector('#pgsmViewPairs');
 const setMode=mode=>{state.mode=mode;individual.hidden=mode!=='individual';host.hidden=mode!=='pairs';a.setAttribute('aria-pressed',String(mode==='individual'));b.setAttribute('aria-pressed',String(mode==='pairs'));if(mode==='pairs'){pgsmPairDraw_(state);pgsmPairLoad_(state);}};
 a.onclick=()=>setMode('individual');b.onclick=()=>setMode('pairs');setMode(state.mode);
}
document.getElementById('logoutBtn').addEventListener('click',()=>pgsmPairViews_.clear());
