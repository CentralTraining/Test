# Trainer Channel — Test Sandbox credentials

Scope: Supabase function `trainer-channel-test` only, project `qruxqlsbhyhwiqjdkyyc`. The production function and all Secrets were left unchanged.

Deployment: version 4. Source files `index.ts`, `access.ts`, `deno.json` are the complete function and its relative dependencies. No credential values or dashboard records are included.

## Add the Sandbox credentials

In the TikTok Developer app, select the created Sandbox and open App details → Credentials. Enter those values directly in Supabase Edge Function Secrets:

- `TIKTOK_TEST_CLIENT_KEY`
- `TIKTOK_TEST_CLIENT_SECRET`

Set both. The Test function uses this pair when either name exists. Missing/empty parts fail closed rather than mixing credentials. Until neither Test variable exists, the previous key pair remains in use for compatibility; status reports `credentialSource: legacy`.

Expected status after both Test variables are saved: `configured: true`, `credentialSource: test`. This confirms settings were loaded, not that TikTok accepted them or a channel was connected.

Sandbox Login Kit Web Redirect URI:

`https://qruxqlsbhyhwiqjdkyyc.supabase.co/functions/v1/trainer-channel-test/oauth/callback`

Scopes: `user.info.basic`, `user.info.profile`, `video.list`. The current implementation does not use `user.info.stats`.

Actual OAuth authorization and video synchronization must still be tested with a permitted Sandbox target user. First-time app review needs that real end-to-end recording; this bundle does not contain a review video.
