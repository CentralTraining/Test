# Kịch bản quay TikTok App Review — bản Test

Trạng thái: kịch bản chuẩn bị, chưa phải video chứng minh kết nối thành công. File `app-review-description.txt` mô tả chức năng mã nguồn hiện có; cần kiểm thử luồng Sandbox thực tế trước khi gửi hồ sơ.

## Điều kiện trước khi quay

- Website: https://centraltraining.github.io/Test/ . Website URL trong hồ sơ TikTok phải khớp website được quay.
- Với ứng dụng chưa từng được duyệt, TikTok yêu cầu quay tích hợp thực tế trong Sandbox. Tạo Sandbox trong ứng dụng hiện có, bật Login Kit và các quyền thật sự dùng: `user.info.basic`, `user.info.profile`, `video.list`.
- `user.info.stats` đang có trong ảnh hồ sơ nhưng mã tích hợp hiện không dùng. Bỏ quyền này khỏi hồ sơ nếu không có chức năng cần nó; không mô tả hoặc quay giả việc sử dụng quyền đó.
- Cấu hình Redirect URI đúng theo trạng thái của backend Test: `https://qruxqlsbhyhwiqjdkyyc.supabase.co/functions/v1/trainer-channel-test/oauth/callback`.
- Khóa Sandbox phải tương ứng với cấu hình Sandbox đang dùng. Trong Supabase Secrets, lưu Client key của Sandbox bằng tên `TIKTOK_TEST_CLIENT_KEY`, Client secret của Sandbox bằng tên `TIKTOK_TEST_CLIENT_SECRET`. Hai biến này chỉ được bộ kết nối Test sử dụng; giữ nguyên hai biến `TIKTOK_CLIENT_KEY` và `TIKTOK_CLIENT_SECRET` hiện có. Không quay Client Secret, mật khẩu hoặc mã xác thực.
- Thêm tài khoản TikTok được phép thử vào Target users của Sandbox, hoàn tất Apply changes. Đây là tài khoản thật của người tham gia thử nghiệm.
- Không đưa dữ liệu KPI, nhân sự, PGs hoặc dữ liệu khu vực khác vào video gửi xét duyệt. Chỉ ghi vùng tích hợp Xây kênh và thông tin tài khoản thử được phép chia sẻ.

## Luồng quay khoảng 90–150 giây

1. Mở đúng URL Test, để thấy tên miền, tên ứng dụng và các liên kết Điều khoản/Chính sách bảo mật. Không quay màn hình nhập mật khẩu dashboard.
2. Vào Mở rộng → Xây kênh. Dùng tài khoản dashboard được phép và kênh TikTok đã gán đúng. Chỉ hiển thị thông tin kênh thử.
3. Bấm Kết nối. Quay trang cấp quyền TikTok với tên ứng dụng và các quyền được yêu cầu. Nếu cần đăng nhập, tạm dừng quay khi nhập mật khẩu/mã xác thực, rồi tiếp tục tại màn hình consent.
4. Chủ kênh đồng ý quyền. Quay thao tác chuyển trở lại website Test và trạng thái kết nối thực tế. Không ghi query string OAuth có mã code/state.
5. Bấm Đồng bộ TikTok. Quay kết quả video thực tế và các trường mà tích hợp sử dụng: thời gian đăng, lượt thích, chia sẻ, lượt xem.
6. Chuyển Tuần, Tháng và Từ ngày–Đến ngày để thể hiện cách dashboard tính số video/target, likes/shares trên cùng nguồn dữ liệu thật.
7. Kết thúc ở bảng tiến độ. Chỉ ghi nhận đồng bộ thành công khi giao diện hiển thị dữ liệu thật; nếu có lỗi, xử lý lỗi trước khi làm video xét duyệt.

## Yêu cầu file

- MP4 hoặc MOV; tối đa 50 MB/file; tối đa 5 file theo giao diện TikTok hiện tại.
- Đề xuất MP4 H.264, 1280×720 hoặc 1920×1080, 30 fps; chữ và thao tác cần đọc được.
- Không thay màn hình cấp quyền thật bằng hình giả hoặc dùng số liệu mẫu làm bằng chứng đã đồng bộ.
- File quay gốc có thể được nén/chuẩn hóa bằng `prepare_review_video.py` trong thư mục này. Script chỉ xử lý video ghi sẵn; không tạo bằng chứng cấp quyền hay dữ liệu.

## Tiêu chí có thể ảnh hưởng xét duyệt

TikTok nêu ứng dụng chỉ dùng riêng tư/cá nhân hoặc còn trong giai đoạn phát triển/thử nghiệm không đáp ứng tiêu chí duyệt Production. Dashboard hiện phục vụ riêng đội Trainer, nên cần làm rõ mục đích ứng dụng theo thực tế; video đúng định dạng không bảo đảm được duyệt.

Nguồn chính thức:

- https://developers.tiktok.com/docs/en/app-review-guidelines
- https://developers.tiktok.com/docs/en/add-a-sandbox
