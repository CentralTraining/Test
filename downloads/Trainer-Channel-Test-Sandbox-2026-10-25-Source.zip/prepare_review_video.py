#!/usr/bin/env python3
"""Normalize an actual screen recording to an upload-sized MP4; no fabricated UI."""
import argparse
import json
import math
import pathlib
import subprocess


def probe(path):
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)],
        check=True, capture_output=True, text=True,
    )
    return json.loads(result.stdout)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("recording", type=pathlib.Path)
    parser.add_argument("output", type=pathlib.Path)
    args = parser.parse_args()
    if args.output.suffix.lower() != ".mp4":
        parser.error("Output must end in .mp4")
    if args.recording.resolve() == args.output.resolve() or args.output.exists():
        parser.error("Choose a new output filename; existing recordings are preserved")
    source = probe(args.recording)
    videos = [s for s in source["streams"] if s["codec_type"] == "video"]
    if not videos:
        parser.error("The input contains no video")
    duration = float(source["format"].get("duration", 0))
    if not math.isfinite(duration) or duration <= 0:
        parser.error("Cannot determine recording duration")
    # Leave substantial headroom below TikTok's 50 MB upload limit.
    rate_kbps = min(3500, int(42_000_000 * 8 / duration / 1000) - 128)
    if rate_kbps < 500:
        parser.error("Recording is too long for readable text under 50 MB; shorten it first")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([
        "ffmpeg", "-nostdin", "-v", "error", "-n", "-i", str(args.recording),
        "-map", "0:v:0", "-map", "0:a?", "-map_metadata", "-1",
        "-vf", "scale=w='min(1920,iw)':h='min(1080,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2,fps=30,setsar=1",
        "-c:v", "libx264", "-preset", "medium", "-pix_fmt", "yuv420p",
        "-b:v", f"{rate_kbps}k", "-maxrate", f"{rate_kbps}k", "-bufsize", f"{rate_kbps * 2}k",
        "-c:a", "aac", "-b:a", "96k", "-movflags", "+faststart", str(args.output),
    ], check=True)
    result = probe(args.output)
    video = next(s for s in result["streams"] if s["codec_type"] == "video")
    size = args.output.stat().st_size
    if size >= 50_000_000 or video["codec_name"] != "h264" or video.get("pix_fmt") != "yuv420p":
        raise SystemExit("Output validation failed; this file is not marked upload-ready")
    print(json.dumps({
        "output": str(args.output), "bytes": size, "duration_seconds": float(result["format"]["duration"]),
        "codec": video["codec_name"], "width": video["width"], "height": video["height"],
        "file_format_validated": True,
        "content_review": "Actual Sandbox authorization/data must still be checked; format validation is not app approval.",
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
