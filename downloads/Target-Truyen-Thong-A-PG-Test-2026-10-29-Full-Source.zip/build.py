from pathlib import Path
import json,hashlib
p=Path(__file__).parent
s=(p.parent/'pair-final-20261028/main/index.html').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='1561a72e58c9487aea385ba34da5e5eadcdc4cfa0b32fb8d809639ff02d610f2'
(p/'before.html').write_text(s)
start=s.index('async function renderTargetTable(){');end=s.index("document.getElementById('editTargetBtn').addEventListener",start)
part=s[start:end]
marker="\n  const viewModeBox = document.getElementById('targetDoitacViewModeBox');"
assert part.count(marker)==1
addition='''
  if(camp.group==='truyenthong' && ['noibo','doitac'].includes(sub)){
    const helper=document.createElement('div');helper.className='media-a-target-control';helper.dataset.mediaACampaign=String(camp.id);
    helper.innerHTML=`<span><strong>Target theo PG đang làm</strong><small>A = số bài trên 1 PG · Target mỗi Trainer = A × số PG OPPO Đang làm do Trainer phụ trách.</small></span>${isAdmin()?`<button type="button" class="secondary" id="mediaTargetAOpenBtn" ${locked?'disabled':''}>Nhập A — Số bài/PG</button>`:''}${locked&&isAdmin()?'<small>Target đã chốt. Bấm “Sửa Target” để nhập A hoặc chỉnh tay.</small>':''}`;
    ctx.appendChild(helper);helper.querySelector('#mediaTargetAOpenBtn')?.addEventListener('click',()=>mediaTargetAModalOpen_(String(camp.id)));
  }
'''
part=part.replace(marker,'\n'+addition+marker)
old="  await dbSet('records:'+currentMonth, records);";assert part.count(old)==1
part=part.replace(old,"  if(camp.group!=='truyenthong')await dbSet('records:'+currentMonth, records);")
s=s[:start]+part+s[end:]
before=(p/'before.html').read_text()
for begin,finish in [('function renderCampaignList(){','/* Nhân bản 1 chiến dịch'),("document.getElementById('saveTargetBtn').addEventListener",'function startEditRegion(name){')]:
 assert s[s.index(begin):s.index(finish,s.index(begin))]==before[before.index(begin):before.index(finish,before.index(begin))]
marker='\n</body>\n</html>';assert s.count(marker)==1
addition='<style id="media-target-a-style-20261029">'+(p/'style.css').read_text()+'</style><script id="media-target-a-model-20261029">\n'+(p/'model.js').read_text().replace('export const','const',1)+'\n</script><script id="media-target-a-ui-20261029">\n'+(p/'media-target-a.js').read_text()+'\n</script>'
s=s.replace(marker,addition+marker)
b=s.encode();name='Dashboard-Test-2026-10-29-Target-Truyen-Thong-A-PG.html'
for n in ['index.html',name]:(p/n).write_bytes(b)
m={'scope':'Test','date':'2026-10-29','filename':name,'bytes':len(b),'characters':len(s),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'base_commit':'6c1daf6519a1cdefb722763666db361647c6fcde','location':'Cài đặt > Target','wrong_campaign_list_change_removed':True,'manual_target_handler_unchanged':True,'main_changed':False,'backend_changed':False,'schema_changed':False,'secrets_changed':False,'real_data_changed':False}
(p/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));print(json.dumps(m))
