const mediaTargetAOwner_=()=>JSON.stringify([session?.userId,session?.role,session?.region,session?.trainerId]);
async function mediaTargetARead_(id){
 if(!isAdmin())throw Error('Chỉ Admin được tính và lưu Target truyền thông.');
 let values;
 const keys=['campaigns','config'];
 async function read(keys){
  if(!SUPABASE_URL)return dbGetMulti(keys);
  const q=keys.map(k=>'"'+String(k).replace(/"/g,'\\"')+'"').join(',');
  const r=await fetch(SUPABASE_URL+'/rest/v1/'+SUPABASE_TABLE+'?key=in.('+encodeURIComponent(q)+')&select=key,value',{headers:SUPA_HEADERS_,signal:AbortSignal.timeout(20000)});
  if(!r.ok)throw Error('Không đọc được dữ liệu Target (HTTP '+r.status+'). Chưa lưu thay đổi.');
  const rows=await r.json();if(!Array.isArray(rows))throw Error('Dữ liệu Target chưa hợp lệ.');return Object.fromEntries(rows.map(r=>[r.key,r.value]));
 }
 values=await read(keys);const list=values.campaigns,trainers=values.config?.trainers;
 if(!Array.isArray(list)||!Array.isArray(trainers))throw Error('Chưa đọc được chiến dịch hoặc cấu hình Trainer.');
 const camp=list.find(c=>String(c.id)===String(id)&&c.group==='truyenthong'&&['noibo','doitac'].includes(campaignSubtype(c)));
 if(!camp||!/^\d{4}-\d{2}$/.test(camp.month))throw Error('Chiến dịch truyền thông đã thay đổi hoặc không còn tồn tại.');
 const data=await read(['pgs:'+camp.month,'mediaTargets:'+camp.id,'monthLock:'+camp.month]);
 const roster=data['pgs:'+camp.month],targets=data['mediaTargets:'+camp.id]??{};
 if(!Array.isArray(roster))throw Error('Chưa có danh sách PG của '+monthLabel(camp.month)+'. Hãy import Nhân sự của đúng tháng trước.');
 if(!targets||typeof targets!=='object'||Array.isArray(targets))throw Error('Target hiện tại chưa đúng định dạng.');
 const locked=data['monthLock:'+camp.month]===true;
 return {list,camp,trainers,roster,targets,locked,signature:JSON.stringify([camp,trainers,roster,targets,locked])};
}
function mediaTargetAApplied_(fresh,nextCamp,targets){
 campaigns=fresh.list.map(c=>String(c.id)===String(nextCamp.id)?{...nextCamp,mediaTargetsCache:targets}:c);
 if(mediaScopeKey===nextCamp.id)mediaTargets=targets;
 invalidateMediaCampaignsDataCache_();if(typeof invalidateHomeSnapshot_==='function')invalidateHomeSnapshot_();
}
async function mediaTargetAModalOpen_(id){
 if(!isAdmin())return;document.getElementById('mediaTargetAOverlay')?.remove();
 const owner=mediaTargetAOwner_(),viewMonth=currentMonth,ov=document.createElement('div');ov.id='mediaTargetAOverlay';ov.className='media-a-overlay';ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');ov.setAttribute('aria-label','Tính Target truyền thông theo PG đang làm');
 ov.innerHTML='<section class="media-a-dialog"><header><div><h3>Target truyền thông theo PG</h3><p id="mediaATitle">Đang tải chiến dịch…</p></div><button type="button" class="secondary" data-media-a-close aria-label="Đóng">✕</button></header><div class="media-a-body"><p class="section-desc">Target mỗi Trainer = <strong>A × số PG OPPO đang làm</strong> trong Nhân sự của đúng tháng. Mỗi PG chỉ tính một lần theo Code.</p><div class="media-a-input-row"><label for="mediaAInput">Số bài trên 1 PG (A)<input id="mediaAInput" type="number" min="1" step="1" inputmode="numeric" placeholder="Ví dụ: 2" disabled></label><div class="media-a-total"><small>PG đang làm được gán Trainer</small><b id="mediaAActive">—</b></div><div class="media-a-total"><small>Tổng Target (bài)</small><b id="mediaATotal">—</b></div></div><p id="mediaANote" class="section-desc"></p><p id="mediaAError" class="media-a-error" role="alert"></p><div id="mediaAPreview" class="media-a-table" role="status">Đang lấy danh sách PG và Trainer…</div></div><footer><span>Target chốt theo nhân sự tại thời điểm lưu. Khi nhân sự thay đổi, mở nút này để tính lại.</span><button type="button" class="secondary" id="mediaAReload">Tải lại dữ liệu</button><button type="button" class="secondary" id="mediaAEdit" hidden>Sửa Target</button><button type="button" class="primary" id="mediaASave" disabled>Lưu Target</button></footer></section>';
 document.body.appendChild(ov);let source=null,busy=false,editable=false,result=null;
 const input=ov.querySelector('#mediaAInput'),save=ov.querySelector('#mediaASave'),edit=ov.querySelector('#mediaAEdit'),error=ov.querySelector('#mediaAError');
 const current=()=>ov.isConnected&&isAdmin()&&owner===mediaTargetAOwner_()&&viewMonth===currentMonth;
 const close=()=>{if(!busy)ov.remove();};ov.querySelector('[data-media-a-close]').onclick=close;ov.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
 function draw(){
  result=null;error.textContent='';const locked=!source||source.locked||!!source.camp.targetLocked&&!editable;
  input.disabled=busy||locked;edit.hidden=!source||!source.camp.targetLocked||editable||source.locked;edit.disabled=busy;
  ov.querySelector('#mediaAReload').disabled=busy;save.disabled=true;save.textContent=busy?'Đang lưu…':'Lưu Target';
  if(!source)return;
  ov.querySelector('#mediaATitle').textContent=source.camp.name+' · '+campaignSubtypeLabel('truyenthong',campaignSubtype(source.camp))+' · '+monthLabel(source.camp.month);
  ov.querySelector('#mediaANote').textContent=source.locked?'Tháng đã khóa. Chưa thể thay đổi Target.':source.camp.targetLocked&&!editable?'Target đã chốt. Bấm “Sửa Target” để nhập A và tính lại.':'Xem trước toàn bộ Trainer; Trainer không có PG đang làm nhận Target 0.';
  try{result=MediaTargetAModel.calculate(source.roster,source.trainers,input.value);}catch(e){error.textContent=locked?'':e.message;ov.querySelector('#mediaATotal').textContent='—';ov.querySelector('#mediaAPreview').textContent='Nhập số bài/PG (A) để xem trước Target của từng Trainer.';return;}
  const e=escapeHtml;ov.querySelector('#mediaAActive').textContent=result.active;ov.querySelector('#mediaATotal').textContent=result.total;
  ov.querySelector('#mediaAPreview').innerHTML='<table><thead><tr><th>Trainer</th><th>Khu vực</th><th>PG đang làm</th><th>Target (bài)</th></tr></thead><tbody>'+result.rows.map(r=>'<tr><td><strong>'+e(r.name)+'</strong></td><td>'+e(r.region)+'</td><td>'+r.count+'</td><td><strong>'+r.count+' × '+result.a+' = '+r.target+'</strong></td></tr>').join('')+'</tbody></table>';
  if(result.unassigned||result.duplicates)error.textContent=[result.unassigned?result.unassigned+' PG đang làm chưa được gán Trainer hợp lệ, chưa tính vào Target.':'',result.duplicates?'Đã gộp '+result.duplicates+' dòng trùng cùng Code.':''].filter(Boolean).join(' ');
  save.disabled=busy||locked;
 }
 async function load(){if(busy||!current())return;save.disabled=true;input.disabled=true;error.textContent='';try{const next=await mediaTargetARead_(id);if(!current())return ov.remove();source=next;if(!input.value)input.value=String(next.camp.mediaTargetPostsPerPg??'');draw();if(!input.disabled)input.focus();}catch(e){source=null;error.textContent=e.message;ov.querySelector('#mediaAPreview').textContent='Chưa có dữ liệu để tính. Bấm Tải lại dữ liệu sau khi kiểm tra nguồn.';}}
 input.oninput=draw;edit.onclick=()=>{editable=true;draw();input.focus();};ov.querySelector('#mediaAReload').onclick=load;
 save.onclick=async()=>{
  if(busy||!current()||!source||!result||save.disabled)return;const a=input.value;busy=true;draw();
  try{
   const fresh=await mediaTargetARead_(id);if(!current())return ov.remove();
   if(fresh.signature!==source.signature){source=fresh;throw Error('Nhân sự, phân công hoặc Target vừa thay đổi. Đã tải dữ liệu mới; hãy kiểm tra lại trước khi bấm Lưu Target.');}
   if(fresh.locked)throw Error('Tháng đã khóa. Chưa lưu Target.');
   const calculated=MediaTargetAModel.calculate(fresh.roster,fresh.trainers,a),nextCamp={...fresh.camp,mediaTargetPostsPerPg:calculated.a,mediaTargetPgCounts:calculated.counts,mediaTargetCalculatedAt:new Date().toISOString(),targetLocked:true};
   const nextTargets={...fresh.targets,...calculated.targets};if(!current())return ov.remove();
   await saveCampaignData_([['campaigns',fresh.list.map(c=>String(c.id)===String(id)?nextCamp:c)],['mediaTargets:'+id,nextTargets]]);
   if(!current())return ov.remove();mediaTargetAApplied_(fresh,nextCamp,nextTargets);ov.remove();renderCampaignList();const msg=document.getElementById('campaignSaveMsg');if(msg){msg.style.display='block';msg.style.color='var(--green-ok)';msg.textContent='Đã lưu A = '+calculated.a+' bài/PG · '+calculated.active+' PG đang làm · Tổng Target '+calculated.total+' bài cho chiến dịch “'+nextCamp.name+'”.';}
  }catch(e){if(current()){busy=false;draw();error.textContent=e.message;}}
  finally{busy=false;}
 };
 await load();
}
async function mediaTargetAManualSave_(camp){
 const msg=document.getElementById('targetSaveMsg'),owner=mediaTargetAOwner_(),month=currentMonth;
 try{
  if(!isAdmin())return;const fresh=await mediaTargetARead_(camp.id);
  if(owner!==mediaTargetAOwner_()||month!==currentMonth||document.getElementById('targetCampaignSelect')?.value!==camp.id)return;
  if(fresh.locked||fresh.camp.targetLocked)throw Error('Target hoặc tháng đã khóa. Hãy tải lại trước khi chỉnh sửa.');
  const targets={...fresh.targets};for(const inp of document.querySelectorAll('.target-input')){if(!/^\d+$/.test(inp.value)||!Number.isSafeInteger(Number(inp.value)))throw Error('Target phải là số nguyên không âm.');targets[inp.dataset.trainer]=Number(inp.value);}
  const nextCamp={...fresh.camp,targetLocked:true};delete nextCamp.mediaTargetPostsPerPg;delete nextCamp.mediaTargetPgCounts;delete nextCamp.mediaTargetCalculatedAt;
  await saveCampaignData_([['campaigns',fresh.list.map(c=>c.id===camp.id?nextCamp:c)],['mediaTargets:'+camp.id,targets]]);
  if(owner!==mediaTargetAOwner_()||month!==currentMonth)return;mediaTargetAApplied_(fresh,nextCamp,targets);await renderTargetTable();renderKpiAll();
  if(msg){msg.style.display='block';msg.style.color='var(--green-ok)';msg.textContent='Đã lưu Target nhập tay cho chiến dịch này.';}
 }catch(e){if(msg){msg.style.display='block';msg.style.color='var(--red)';msg.textContent=e.message;}}
}
