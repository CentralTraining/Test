export const MediaTargetAModel=(()=>{
 const code=v=>String(v??'').trim().replace(/\.0+$/,'').toUpperCase().replace(/^0+(?=\d+$)/,'');
 const positive=v=>/^\d+$/.test(String(v).trim())&&Number.isSafeInteger(Number(v))&&Number(v)>0;
 function calculate(pgs,trainers,a){
  if(!positive(a))throw Error('A phải là số nguyên lớn hơn 0.');a=Number(a);
  if(!Array.isArray(pgs)||!Array.isArray(trainers))throw Error('Chưa có danh sách PG hoặc Trainer hợp lệ.');
  const ids=new Set();for(const t of trainers){if(!t.id||ids.has(String(t.id)))throw Error('Danh sách Trainer bị trùng hoặc thiếu mã.');ids.add(String(t.id));}
  const people=new Map();let duplicates=0;
  for(const p of pgs){
   if(String(p.brand||'').trim().toUpperCase()!=='OPPO')continue;
   const key=code(p.code)||String(p.id||'').trim();if(!key)throw Error('Có PG OPPO thiếu Code và mã dòng. Cần kiểm tra Nhân sự trước khi tính.');
   const signature=JSON.stringify([String(p.trainerId||''),String(p.status||'').normalize('NFC').trim()]);
   if(people.has(key)){if(people.get(key).signature!==signature)throw Error('Có mã PG trùng nhưng khác Trainer/trạng thái. Cần xử lý trùng tại Nhân sự trước.');duplicates++;continue;}
   people.set(key,{signature,p});
  }
  const counts=Object.fromEntries(trainers.map(t=>[String(t.id),0]));let unassigned=0;
  for(const {p} of people.values())if(String(p.status||'').normalize('NFC').trim()==='Đang làm'){if(ids.has(String(p.trainerId)))counts[String(p.trainerId)]++;else unassigned++;}
  const rows=trainers.map(t=>{const count=counts[String(t.id)],target=count*a;if(!Number.isSafeInteger(target))throw Error('Target vượt giới hạn số nguyên. Hãy giảm A.');return {id:String(t.id),name:String(t.name||''),region:String(t.region||''),count,target};});
  const total=rows.reduce((n,r)=>n+r.target,0);if(!Number.isSafeInteger(total))throw Error('Tổng Target vượt giới hạn số nguyên.');
  return {a,rows,targets:Object.fromEntries(rows.map(r=>[r.id,r.target])),counts,total,active:rows.reduce((n,r)=>n+r.count,0),unassigned,duplicates};
 }
 return {code,positive,calculate};
})();
