# Xây kênh — follower và ba chỉ số đồng thời — bản Test 25/10/2026

Chỉ áp dụng trên `CentralTraining/Test` và Edge Function `trainer-channel-test`. Không thay mã dashboard chính, bộ kết nối chính, dữ liệu KPI, sổ nhắc hoặc Secrets.

## Sử dụng

- Mở rộng → Xây kênh: bảng hiển thị đồng thời Tăng follow, Like, Share cho từng Trainer.
- Bộ lọc tuần, tháng, khoảng ngày và Trainer tiếp tục hoạt động. Follow đối chiếu mốc cố định 01/10/2026 đến mốc cuối ghi nhận không sau ngày kết thúc đang xem. Like/Share là tổng mới nhất của video đăng trong kỳ, không phải lượng tương tác tăng thêm riêng trong kỳ.
- Thêm `user.info.stats` trong Scopes của đúng TikTok app/Sandbox. Chủ kênh bấm Cấp quyền follow để bổ sung quyền nếu token hiện tại chưa có. Luồng video cũ không bị bắt buộc cấp quyền mới.
- Follower được lấy tự động từ TikTok khi đồng bộ. Các kết nối cũ chưa lưu danh sách scope được kiểm tra quyền thống kê một lần; nếu TikTok chưa cho phép thì cần chủ kênh cấp quyền. Không suy ra quyền từ cấu hình app hoặc việc đã lưu Client key.
- Chỉ lưu mốc thực tế tại thời điểm đồng bộ, gồm tự đồng bộ khi mở trang và mỗi 15 phút khi còn đang xem. Mỗi ngày Việt Nam giữ mốc đầu/cuối. Không có đồng bộ nền mới khi đóng trang trong thay đổi này.

## Mốc 01/10/2026

TikTok Display API trả follower hiện tại; không có tham số lấy follower lịch sử ngày 01/10/2026. Tính tự động từ ngày này cần một mốc có thật. Có thể sử dụng một quan sát TikTok thực sự được ghi vào ngày đó hoặc số đầu kỳ từ bản ghi thực tế do Admin nhập. Không lấy follower hôm nay gán ngược thành số ngày 01/10; không coi mốc chưa có là 0.

Admin có thể bổ sung mốc có thật bằng nút Mốc 01/10. Số nhập được ghi nguồn `admin_record`, gắn với kênh/tài khoản và lưu mã hóa. Đây không phải dữ liệu TikTok API được dựng lại; bản phát hành không kèm hoặc tự nhập số đầu kỳ nào. Việc ngày ghi mốc chỉ có ngày, không có giờ, được thể hiện đúng ở biểu đồ.

- Mức tăng = follower mốc cuối − follower mốc 01/10/2026.
- Tỷ lệ = mức tăng / follower mốc 01/10/2026 × 100.
- Thiếu mốc đầu/cuối: hiển thị “—”. Mốc đầu thực tế bằng 0: mức tăng vẫn tính được, % hiển thị “—”.
- Tổng đội chỉ tính mức tăng/% khi tất cả kênh trong phạm vi đã có đủ mốc; không cộng kênh thiếu dữ liệu thành 0.

## Quyền truy cập và lưu dữ liệu

Tiếp tục xác thực tài khoản dashboard phía máy chủ. Admin xem đội và nhập mốc; Trainer chỉ đọc khu vực được phân quyền, chỉ kết nối kênh của chính mình. Token không trả về trình duyệt; mốc follower nằm trong payload kênh mã hóa hiện có. Lỗi follower không làm mất video; lỗi video không xóa mốc follower đã ghi. Dữ liệu cũ có thời điểm ghi nhận rõ khi TikTok gặp lỗi.

## Mã nguồn đầy đủ

- `index.html`: toàn bộ HTML Test.
- `function/`: toàn bộ source và dependency của Edge Function Test; có `followers.ts`, `access.ts`, `index.ts`, `deno.json`.
- `channel-tool.js`, `follower-model.js`, `follower-ui-v2.js`, `follower-ui.css`: source phần giao diện thay đổi.
- `policies/`: Terms/Privacy Test đã cập nhật phạm vi follower.
- `app-review-description.txt`: mô tả dưới 1.000 ký tự; không phải xác nhận TikTok đã xét duyệt.
- `check-*.cjs`, `*-verification.json`: kiểm tra với dữ liệu giả, không chứa dữ liệu Trainer/PGs thực tế hay khóa riêng.

Tài liệu: https://developers.tiktok.com/docs/en/tiktok-api-v2-get-user-info
