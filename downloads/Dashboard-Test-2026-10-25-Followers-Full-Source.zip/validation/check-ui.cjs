process.env.MOBILE_HTML='followers/index.html';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {start,measure}=require('../mobile-audit.cjs');
const root=__dirname,at=['2026-10-19T01:00:00Z','2026-10-25T01:00:00Z'];
const follow=(a,b,status='ready')=>({authorized:true,status,baseline:{date:'2026-10-01',count:a,source:'admin_record'},current:b,asOf:at[1],history:[{at:at[0],count:a},{at:at[1],count:b}]});
(async()=>{
 const results=[];
 for(const width of [320,390,1440]){
  const trainers=Array.from({length:13},(_,i)=>({id:'T'+i,name:'Trainer kiểm thử '+i,region:['HUẾ','ĐÀ NẴNG','NHA TRANG'][i%3]}));
  const rows=trainers.map((t,i)=>({...t,handle:'fixture.channel.'+i,trackingFrom:'2026-10-01',connected:i<7,known:i<7,videos:i<6?[{id:'1000000'+i,createdAt:at[0],title:'Video synthetic',likes:10,shares:2,views:100}]:[],syncedAt:at[1],followers:i===0?follow(100,150):i===1?follow(500,450):i===2?{...follow(0,0),baseline:null,history:[{at:at[1],count:0}]}:i===3?follow(0,5):i===4?{authorized:false,status:'needs_authorization',current:null,asOf:null,history:[]}:i===5?follow(100,110,'unavailable'):i===6?follow(12000000,13400000):undefined}));
  let trainerMode=false;const calls=[];
  const {browser,context,page,audit}=await start(width,data=>data.config.trainers=trainers);
  try{
   await context.route('https://centraltraining.github.io/Test/',route=>route.fulfill({status:200,contentType:'text/html',body:fs.readFileSync(path.join(root,'index.html'),'utf8')}));
   await context.route('**/functions/v1/trainer-channel*',route=>{
    const b=JSON.parse(route.request().postData());calls.push(b);const out={ok:true};
    if(b.action==='status')Object.assign(out,{configured:true,optionalScopes:['user.info.stats'],followerHistory:true});
    else if(b.action==='overview')Object.assign(out,{trainers:trainerMode?rows.filter(t=>t.region==='HUẾ'):rows,from:b.from,to:b.to});
    else if(b.action==='sync')out.complete=true;
    else if(b.action==='connect')out.url='https://invalid.fixture/';
    else if(b.action==='set_follower_baseline'){rows.find(t=>t.id===b.trainerId).followers.baseline={date:'2026-10-01',count:b.count,source:'admin_record'};out.saved=true;}
    return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(out)});
   });
   await page.goto('https://centraltraining.github.io/Test/');await page.waitForSelector('#mainApp:not(.hidden)');
   await page.evaluate(()=>{sessionStorage.setItem('workshop_private_session',JSON.stringify({token:'SYNTHETIC',expires:Date.now()+3600000,userId:session.userId}));channelView_.filters.anchor='2026-10-25';});
   await page.locator('nav.tabs [data-tab="extensions"]').click();await page.waitForFunction(()=>channelView_.data?.trainers?.length===13&&!channelView_.busy);
   assert.equal(await page.locator('.channel-detail-table thead th').count(),8);assert.equal(await page.locator('.channel-detail-table tbody tr').count(),13);assert.equal(await page.locator('.channel-metrics-table [role=row]').count(),14);assert.equal(await page.locator('.channel-metrics-head [role=columnheader]').count(),4);assert.equal(await page.locator('[data-channel-metric]').count(),0,'all three metrics visible without tabs');
   assert((await page.locator('.channel-follow-summary').innerText()).includes('6/13 kênh'));assert((await page.locator('.channel-follow-summary').innerText()).includes('—'));assert(await page.locator('.channel-follow-warning').isVisible());
   assert.equal(await page.locator('.channel-metric-cell.down').count(),1);assert(await page.locator('[data-channel-follow-connect="T4"]').isVisible());
   let layout=await measure(page,'followers-all');assert(layout.documentWidth<=layout.width+2,JSON.stringify(layout));assert.equal(layout.overflow.length,0,JSON.stringify(layout));
   const table=await page.locator('.channel-detail-table').evaluate(t=>({width:t.clientWidth,scroll:t.scrollWidth}));assert(table.scroll<=table.width+2,JSON.stringify(table));
   await page.locator('#channelTrainer').selectOption('T0');assert.equal(await page.locator('.channel-follow-trend svg circle').count(),3);assert((await page.locator('.channel-follow-summary').innerText()).includes('+50%'));
   assert(await page.locator('.channel-follow-summary strong').first().evaluate(el=>[...el.querySelectorAll('span')].some(s=>s.getBoundingClientRect().width>0&&parseFloat(getComputedStyle(s).fontSize)>=18)),'follower numbers use the summary font size');
   await page.locator('[data-channel-followers="T0"]').first().click();assert.equal(await page.locator('.channel-follow-history tbody tr').count(),3);assert((await page.locator('.channel-dialog').innerText()).includes('Mốc 01/10: 100 → mốc cuối 150'));assert((await page.locator('.channel-follow-history').innerText()).includes('Admin nhập'));layout=await measure(page,'follower-modal');assert.equal(layout.overflow.length,0,JSON.stringify(layout));await page.locator('.channel-close').click();
   await page.screenshot({path:path.join(root,'follower-'+width+'.png'),fullPage:true});
   await page.locator('#channelTrainer').selectOption('T1');assert((await page.locator('.channel-follow-summary').innerText()).includes('-50'));assert((await page.locator('.channel-follow-summary').innerText()).includes('-10%'));
   await page.locator('#channelTrainer').selectOption('T2');assert.equal(await page.locator('.channel-follow-trend svg circle').count(),1);assert.equal(await page.locator('.channel-follow-trend svg polyline').count(),0);assert((await page.locator('.channel-follow-summary').innerText()).includes('—'));assert((await page.locator('.channel-follow-observed').innerText()).includes('thiếu số follower thực tế ngày 01/10/2026'));
   await page.locator('[data-channel-follow-baseline]').click();await page.locator('#channelFollowerBaselineTrainer').selectOption('T2');assert.equal(await page.locator('#channelFollowerBaselineCount').inputValue(),'','never prefill missing historical counts with zero or current count');await page.locator('#channelFollowerBaselineCount').fill('0');await page.locator('#channelFollowerBaselineForm [type=submit]').click();await page.waitForSelector('.channel-overlay',{state:'detached'});assert(calls.some(b=>b.action==='set_follower_baseline'&&b.count===0));
   await page.locator('#channelTrainer').selectOption('T3');assert((await page.locator('.channel-follow-summary').innerText()).includes('+5'));assert((await page.locator('.channel-follow-summary').innerText()).includes('Mốc đầu bằng 0'));
   await page.locator('#channelTrainer').selectOption('T6');layout=await measure(page,'large-follower-count');assert.equal(layout.overflow.length,0,JSON.stringify(layout));
   await page.locator('[data-channel-mode="month"]').click();await page.locator('#channelMonth').fill('2026-09');await page.locator('#channelMonth').dispatchEvent('change');await page.waitForFunction(()=>channelView_.data?.to==='2026-09-30');assert.equal(await page.locator('.channel-follow-trend svg').count(),0);assert((await page.locator('.channel-follow-summary').innerText()).includes('—'));
   await page.locator('#channelTrainer').selectOption('T4');await page.locator('[data-channel-follow-connect="T4"]').click();assert(calls.some(b=>b.action==='connect'&&b.trainerId==='T4'&&b.followerStats===true));
   await page.locator('[data-channel-follow-help]').click();assert((await page.locator('.channel-dialog').innerText()).includes('user.info.stats'));await page.locator('.channel-close').click();
   trainerMode=true;await page.evaluate(()=>{session={userId:'UT0',username:'fixture-trainer',role:'trainer',region:'HUẾ',trainerId:'T0'};sessionStorage.setItem('workshop_private_session',JSON.stringify({token:'TRAINER_SYNTHETIC',expires:Date.now()+3600000,userId:session.userId}));renderChannelTool_();});await page.waitForFunction(()=>channelView_.data?.trainers?.length===5&&!channelView_.busy);
   assert.equal(await page.locator('.channel-detail-table tbody tr').count(),5);assert(!(await page.locator('.channel-detail-table').innerText()).includes('ĐÀ NẴNG'));assert.equal(await page.locator('[data-channel-follow-connect="T4"]').count(),0);assert.equal(await page.locator('[data-channel-follow-baseline]').count(),0);
   assert.equal(audit.errors.length,0,audit.errors.join('\n'));results.push({width,table,followMetricsAndChart:true,onePointNotZero:true,negativeAndZeroBaseline:true,rangeFilters:true,scopeUpgradeRequested:true,regionScope:true,layout});console.log(width+': follower metrics, charts, history, optional permission, range filtering, region scope and layout passed.');
  }finally{await browser.close();}
 }
 fs.writeFileSync(path.join(root,'ui-verification.json'),JSON.stringify(results,null,2)+'\n');
})().catch(e=>{console.error(e);process.exitCode=1;});
