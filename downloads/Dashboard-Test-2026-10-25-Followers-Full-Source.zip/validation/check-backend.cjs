const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto').webcrypto,path=require('node:path');
const root=__dirname,read=f=>fs.readFileSync(path.join(root,f),'utf8');
const hash=require('node:crypto').createHash('sha256').update('fixture-password').digest('hex');
const trainers=[{id:'T0',name:'Fixture Trainer A',region:'HUẾ'},{id:'T1',name:'Fixture Trainer B',region:'ĐÀ NẴNG'},{id:'T2',name:'Fixture Trainer C',region:'HUẾ'}];
const users=[{id:'UA',username:'admin',role:'admin',passHash:hash},{id:'U0',username:'trainer',role:'trainer',region:'HUẾ',trainerId:'T0',passHash:hash}];
const records=new Map();let serve,clock=Date.parse('2026-10-25T01:00:00Z'),grantStats=false,count=100,statsFail=false,wrongStatsAccount=false,videoFail=false,statsRequests=0;
class ClockDate extends Date{constructor(...args){super(...(args.length?args:[clock]));}static now(){return clock;}}
const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json'}});
const sandbox={crypto,Response,Request,URL,URLSearchParams,TextEncoder,TextDecoder,Uint8Array,AbortSignal,btoa,atob,Intl,Date:ClockDate,console,Deno:{env:{get:k=>({SUPABASE_URL:'https://db.fixture',SUPABASE_SERVICE_ROLE_KEY:'FIXTURE_SERVICE',TIKTOK_TEST_CLIENT_KEY:'FIXTURE_CLIENT',TIKTOK_TEST_CLIENT_SECRET:'FIXTURE_SECRET'})[k]},serve:fn=>serve=fn},fetch:async(url,options={})=>{
 const u=new URL(url);
 if(u.origin==='https://db.fixture'){
  assert.equal(options.headers.apikey,'FIXTURE_SERVICE');
  if(u.pathname.includes('kv_store'))return json([{key:'auth_users',value:users},{key:'config',value:{trainers}}]);
  assert(u.pathname.endsWith('/trainer_channel_private'));const key=u.searchParams.get('key')?.slice(3);
  if(options.method==='POST'){const value=JSON.parse(options.body);if(records.has(value.key))return json([]);records.set(value.key,value);return json([value]);}
  if(options.method==='PATCH'||options.method==='DELETE'){const old=records.get(key),version=Number(u.searchParams.get('version')?.slice(3));if(!old||old.version!==version)return json([]);if(options.method==='DELETE'){records.delete(key);return json([old]);}const next={...old,...JSON.parse(options.body)};records.set(key,next);return json([next]);}
  return json(records.has(key)?[records.get(key)]:[]);
 }
 assert.equal(u.origin,'https://open.tiktokapis.com');
 if(u.pathname==='/v2/oauth/token/')return json({access_token:'ACCESS_TOKEN_TEST',refresh_token:'REFRESH_TOKEN_TEST',open_id:'OPEN0',expires_in:86400,scope:'user.info.basic,user.info.profile,video.list'+(grantStats?',user.info.stats':'')});
 if(u.pathname==='/v2/user/info/'){
  if(u.searchParams.get('fields').includes('follower_count')){statsRequests++;if(statsFail)return json({error:{code:statsFail==='scope'?'scope_not_authorized':'temporary_error'}},statsFail==='scope'?403:503);return json({error:{code:'ok'},data:{user:{open_id:wrongStatsAccount?'WRONG_ACCOUNT':'OPEN0',follower_count:count}}});}
  return json({error:{code:'ok'},data:{user:{open_id:'OPEN0',username:'fixture.a',display_name:'Fixture TikTok A'}}});
 }
 if(u.pathname==='/v2/video/list/'){if(videoFail)return json({error:{code:'temporary_error'}},503);return json({error:{code:'ok'},data:{has_more:false,cursor:12345,videos:[{id:'10000001',create_time:1792880000,title:'Synthetic video',like_count:10,share_count:2,view_count:100}]}});}
 throw Error('Unexpected endpoint');
}};
const access=read('function/access.ts').replace(/export /g,''),helper=read('function/followers.ts').replace(/export /g,''),source=read('function/index.ts').replace(/^import .*;\n/gm,'');
vm.runInNewContext(access+'\n{\n'+helper+'\n'+source+"\nglobalThis.forceLegacyFixture=async()=>{const r=await read('channel:T0');const token={...r.data.token};delete token.scopes;await put(r,{...r.data,token,followers:null});};\n}",sandbox);
const model=vm.runInNewContext(read('follower-model.js')+'\nFollowerModel',{Date:ClockDate,Map,Number});
(async()=>{
 const admin=(await vm.runInNewContext("authorize('admin','fixture-password')",sandbox)).token;
 let trainer=(await vm.runInNewContext("authorize('trainer','fixture-password')",sandbox)).token;
 const call=async body=>{const response=await serve(new Request('https://function.fixture',{method:'POST',body:JSON.stringify(body)}));return {statusCode:response.status,...await response.json()};};
 const period={from:'2026-10-25',to:'2026-10-25'},query={action:'overview',dashboardToken:trainer,...period};
 const own=async()=>{const result=await call(query);assert.equal(result.statusCode,200);return result.trainers.find(t=>t.id==='T0');};
 const oauth=async follow=>{const result=await call({action:'connect',dashboardToken:trainer,trainerId:'T0',returnUrl:'https://centraltraining.github.io/Test/',followerStats:follow});assert.equal(result.statusCode,200);const u=new URL(result.url);assert.equal(u.searchParams.get('scope').includes('user.info.stats'),follow);const state=u.searchParams.get('state');const response=await serve(new Request('https://function.fixture/oauth/callback?state='+state+'&code=FIXTURE'));assert(response.headers.get('location').endsWith('#channel-connect=ok'));assert.equal((await serve(new Request('https://function.fixture/oauth/callback?state='+state+'&code=REPLAY'))).status,400);};
 const sync=()=>call({action:'sync',dashboardToken:trainer,trainerId:'T0',force:true});
 assert.deepEqual(Array.from((await call({action:'status'})).optionalScopes),['user.info.stats']);
 assert.equal((await call({action:'overview',...period})).statusCode,401);
 assert.equal((await call({action:'assign',dashboardToken:admin,trainerId:'T0',handle:'fixture.a',trackingFrom:'2026-10-01'})).saved,true);
 await oauth(false);assert.equal(statsRequests,0);assert.equal((await sync()).complete,true);let row=await own();assert.equal(row.followers.current,null);assert.equal(row.followers.status,'needs_authorization');assert.equal(row.videos.length,1);
 grantStats=true;await oauth(true);row=await own();assert.equal(row.videos.length,1,'granting new scope preserves existing video snapshot');assert.equal(row.followers.current,100);assert.equal(row.followers.authorized,true);assert.equal(row.followers.history.length,1);assert.equal(model.row(row,period).delta,null,'first observation is not 0 growth');
 assert.equal((await call({action:'set_follower_baseline',dashboardToken:trainer,trainerId:'T0',count:100})).statusCode,403);
 for(const bad of [-1,1.5,null,'100'])assert.equal((await call({action:'set_follower_baseline',dashboardToken:admin,trainerId:'T0',count:bad})).statusCode,400);
 const baseline=await call({action:'set_follower_baseline',dashboardToken:admin,trainerId:'T0',count:100,date:'2026-08-01',source:'tiktok_api'});assert.equal(baseline.baseline.date,'2026-10-01');assert.equal(baseline.baseline.source,'admin_record');row=await own();assert.equal(model.row(row,period).delta,0);assert(!JSON.stringify(row.followers).includes('OPEN0'),'account identifier is not exposed with baseline');
 clock+=30*60000;count=125;assert.equal((await sync()).complete,true);row=await own();assert.equal(row.followers.history.length,2);assert.equal(model.row(row,period).delta,25);assert.equal(model.row(row,period).growthPct,25);
 clock+=30*60000;count=120;await sync();row=await own();assert.equal(row.followers.history.length,2,'only first/latest observation per Vietnam day');assert.equal(model.row(row,period).delta,20);
 clock+=30*60000;statsFail=true;assert.equal((await sync()).complete,true,'stats failure must not block video sync');row=await own();assert.equal(row.followers.current,120);assert.equal(row.followers.status,'unavailable');statsFail=false;
 clock+=30*60000;count=145;videoFail=true;assert.equal((await sync()).statusCode,502);row=await own();assert.equal(row.followers.current,145,'follower observation survives a later video failure');assert.equal(row.videos.length,1);videoFail=false;
 clock+=30*60000;wrongStatsAccount=true;count=999;await sync();row=await own();assert.equal(row.followers.current,145,'must not accept another account stats');assert.equal(row.followers.status,'unavailable');wrongStatsAccount=false;
 clock+=30*60000;count=-1;await sync();row=await own();assert.equal(row.followers.current,145,'invalid count preserves prior observations');count=145;
 const past=await call({...query,from:'2026-10-01',to:'2026-10-24'});assert.equal(past.trainers.find(t=>t.id==='T0').followers.history.length,0,'no invented history before tracking');assert.equal(model.row(past.trainers[0],{from:'2026-10-01',to:'2026-10-24'}).delta,null);
 const beforeStatsRequests=statsRequests;grantStats=false;await oauth(true);row=await own();assert.equal(row.followers.authorized,false);assert.equal(row.followers.current,145);assert.equal(row.videos.length,1);assert.equal(statsRequests,beforeStatsRequests,'declining optional stats leaves video integration usable');
 assert.equal((await call({action:'connect',dashboardToken:trainer,trainerId:'T2',returnUrl:'https://centraltraining.github.io/Test/',followerStats:true})).statusCode,403);
 assert.equal((await call({action:'sync',dashboardToken:trainer,trainerId:'T1',force:true})).statusCode,403);
 const scoped=await call(query);assert.equal(scoped.trainers.length,2);assert(scoped.trainers.every(t=>t.region==='HUẾ'));assert(!JSON.stringify(scoped).includes('ACCESS_TOKEN_TEST'));assert(!JSON.stringify(scoped).includes('REFRESH_TOKEN_TEST'));assert(!JSON.stringify([...records.values()]).includes('"history"'),'history is encrypted in storage');
 grantStats=true;await oauth(true);clock=Date.parse('2026-10-25T17:00:00Z');trainer=(await vm.runInNewContext("authorize('trainer','fixture-password')",sandbox)).token;query.dashboardToken=trainer;count=160;await sync();row=await own();assert(row.followers.history.every(p=>Date.parse(p.at)<clock),'Vietnam midnight belongs to the next date');const tomorrow=await call({...query,from:'2026-10-26',to:'2026-10-26'});assert.equal(tomorrow.trainers.find(t=>t.id==='T0').followers.history.filter(p=>p.at===new Date(clock).toISOString()).length,1);
 clock+=25*3600000;trainer=(await vm.runInNewContext("authorize('trainer','fixture-password')",sandbox)).token;query.dashboardToken=trainer;count=170;assert.equal((await sync()).complete,true,'refresh keeps the follower permission');row=await own();assert.equal(row.followers.current,170);assert.equal(row.followers.authorized,true);
 await sandbox.forceLegacyFixture();const probes=statsRequests;await sync();assert.equal(statsRequests,probes+1,'legacy grants are checked automatically once');row=await own();assert.equal(row.followers.current,170);assert.equal(row.followers.authorized,true);
 clock+=60000;statsFail='scope';await sync();row=await own();assert.equal(row.followers.status,'needs_authorization');assert.equal(row.followers.authorized,false);assert.equal(row.followers.current,170);
 const check={optionalScope:true,legacyVideoConnectionPreserved:true,declinedStatsSupported:true,firstPointUnknownGrowth:true,growthBetweenObservedPoints:true,dailyCompaction:true,statsFailureDoesNotBlockVideos:true,videoFailureKeepsFollowerObservation:true,accountAndIntegerValidation:true,noBackdatedHistory:true,vietnamMidnight:true,regionAuthorization:true,encryptedHistory:true,noTokensInOverview:true};
 fs.writeFileSync(path.join(root,'backend-verification.json'),JSON.stringify(check,null,2)+'\n');console.log(JSON.stringify(check));
})().catch(e=>{console.error(e);process.exitCode=1;});
