/* Date ranges use Vietnam calendar days. TikTok engagement is the latest total
   on videos PUBLISHED in that range, not engagement gained during that range. */
const ChannelModel=(()=>{
 const DAY=86400000,iso=d=>d.toISOString().slice(0,10),date=s=>new Date(s+'T00:00:00Z');
 const valid=s=>/^\d{4}-\d{2}-\d{2}$/.test(String(s))&&!Number.isNaN(+date(s))&&iso(date(s))===s;
 const today=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 const add=(s,n)=>iso(new Date(+date(s)+n*DAY));
 function period(f){
  let from,to;
  if(f.mode==='week'){if(!valid(f.anchor))throw Error('Chọn ngày thuộc tuần cần xem.');const d=date(f.anchor);from=add(f.anchor,-((d.getUTCDay()+6)%7));to=add(from,6);}
  else if(f.mode==='month'){if(!/^\d{4}-\d{2}$/.test(f.month))throw Error('Chọn tháng cần xem.');from=f.month+'-01';if(!valid(from))throw Error('Tháng không hợp lệ.');const d=date(from);to=iso(new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)));}
  else{from=f.from;to=f.to;}
  if(!valid(from)||!valid(to)||from>to||(+date(to)-+date(from))/DAY>365)throw Error('Khoảng ngày hợp lệ tối đa 366 ngày.');
  return {from,to,days:Math.round((+date(to)-+date(from))/DAY)+1};
 }
 const goal=(t,p)=>{const from=t.trackingFrom&&t.trackingFrom>p.from?t.trackingFrom:p.from;return from>p.to?0:Math.ceil((Math.round((+date(p.to)-+date(from))/DAY)+1)*3/7);};
 const day=v=>iso(new Date(Date.parse(v.createdAt)+7*3600000));
 function report(trainers,p){
  const rows=trainers.map(t=>{const videos=(t.videos||[]).filter(v=>day(v)>=p.from&&day(v)<=p.to);const target=goal(t,p),known=!!t.known;return {...t,videos,target,actual:known?videos.length:null,likes:known?videos.reduce((n,v)=>n+v.likes,0):null,shares:known?videos.reduce((n,v)=>n+v.shares,0):null,pct:known&&target?Math.round(videos.length/target*1000)/10:null};});
  const totals=rows.reduce((a,t)=>({target:a.target+t.target,actual:a.actual+(t.actual||0),likes:a.likes+(t.likes||0),shares:a.shares+(t.shares||0),known:a.known+Number(t.known)}),{target:0,actual:0,likes:0,shares:0,known:0});
  const binSize=p.days>35?7:1,bins=[];for(let start=p.from;start<=p.to;start=add(start,binSize))bins.push({from:start,to:add(start,binSize-1)>p.to?p.to:add(start,binSize-1),count:0});
  for(const t of rows.filter(t=>t.known))for(const v of t.videos){const i=Math.floor((+date(day(v))-+date(p.from))/DAY/binSize);if(bins[i])bins[i].count++;}
  return {rows,totals,bins,complete:rows.length>0&&totals.known===rows.length};
 }
 return {today,period,goal,report,day,add};
})();
