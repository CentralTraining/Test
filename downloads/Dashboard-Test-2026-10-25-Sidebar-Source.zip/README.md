# Dashboard Test — Thiết kế menu — 25/10/2026

Phạm vi: thiết kế menu trên https://centraltraining.github.io/Test/.

- Nền sáng, đường viền mảnh và bóng nhẹ; bỏ ảnh nền và khung xám lớn của menu cũ.
- Gom nút thành hai nhóm Hoạt động và Công cụ với khoảng cách ổn định, không kéo giãn từng nút theo chiều cao màn hình.
- Tám biểu tượng SVG dạng nét cùng kích thước, kế thừa màu của mục đang chọn.
- Mục đang chọn màu xanh đậm, có dấu chỉ hướng; chữ và biểu tượng căn cùng trục.
- Thẻ tài khoản chuyển sang dạng hàng nhỏ, avatar bên trái, tên và vai trò bên phải, giữ đầy đủ tên người dùng.
- Chiều cao nút tự chuyển giữa ba mức theo không gian thực tế; không có thanh cuộn riêng trong menu.
- Menu điện thoại giữ chiều cao và bố cục gọn hiện có, dùng cùng bộ biểu tượng.
- Giữ nguyên nút điều hướng, data-tab, ID, quyền truy cập, bảng Follow/View/Like/Share, công thức, dữ liệu và các chức năng khác.
- Không đưa hai liên kết pháp lý trở lại sidebar; các trang và liên kết trên màn hình đăng nhập còn nguyên.
- Không thay Edge Function, Secrets, bot KPI hoặc dashboard chính.

Kiểm tra bằng dữ liệu giả lập ở 320×844, 390×844, 1024×600, 1280×500, 1366×768, 1440×900, 1920×1080. Kiểm tra đủ nút và thẻ tài khoản trong viewport, không cuộn menu, không tràn ngang, khoảng cách các nút, điều hướng, bộ lọc và quyền khu vực.

`index.html` là file HTML đầy đủ để lưu phiên bản. `source/` chứa CSS, script tự điều chỉnh chiều cao và script build. `verification/` chứa kết quả kiểm tra; toàn bộ dữ liệu kiểm thử là giả lập.
