from pathlib import Path
import re,json,hashlib

r=Path(__file__).parent
before=(r/'index.before.html').read_text()
start=before.index('<div class="sidebar-col"')
end=before.index('<div class="main-content">',start)
menu=before[start:end]
icons={
 'home':'<path d="m3 10 9-7 9 7"/><path d="M5 9v12h14V9M9 21v-7h6v7"/>',
 'overview':'<circle cx="9" cy="8" r="3"/><path d="M3 21v-2a6 6 0 0 1 12 0v2M16 5a3 3 0 0 1 0 6M21 21v-2a6 6 0 0 0-4-5.65"/>',
 'kpi':'<path d="M4 3v18h17M8 16v-4M13 16V8M18 16V5"/>',
 'so':'<path d="M4 3v18h17M7 14l4-4 4 3 6-7M17 6h4v4"/>',
 'settings':'<path d="m9 3-.7 2.4-2.4 1.4-2.4-.6-1.5 2.6 1.7 1.8v2.8L2 15.2l1.5 2.6 2.4-.6 2.4 1.4L9 21h3l.7-2.4 2.4-1.4 2.4.6 1.5-2.6-1.7-1.8v-2.8L19 8.8l-1.5-2.6-2.4.6-2.4-1.4L12 3Z"/><circle cx="10.5" cy="12" r="3"/>',
 'data':'<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 4 16 4 16 0V5M4 12c0 4 16 4 16 0"/>',
 'extensions':'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
 'account':'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="9" r="3"/><path d="M5.5 18a7 7 0 0 1 13 0"/>',
}
def replace_icon(m):
 tab=m.group(2)
 assert tab in icons
 svg='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'+icons[tab]+'</svg>'
 return m.group(1)+svg+m.group(3)
pattern=r'(<button\b[^>]*data-tab="([^"]+)"[^>]*>\s*<span class="nav-ic">).*?(</span>)'
menu,count=re.subn(pattern,replace_icon,menu,flags=re.S)
assert count==8
labels=iter(['HOẠT ĐỘNG','CÔNG CỤ'])
menu,count=re.subn(r'<div class="nav-group">',lambda m:m.group(0)+'\n      <div class="nav-group-label" aria-hidden="true">'+next(labels)+'</div>',menu)
assert count==2
out=before[:start]+menu+before[end:]
out=out.replace('</head>','<style id="sidebar-design-20261025">\n'+(r/'sidebar-design.css').read_text()+'\n</style>\n</head>',1)
script_pattern=r'(<script id="sidebar-fit-20261025">)\s*.*?\s*(</script>)'
out,count=re.subn(script_pattern,lambda m:m.group(1)+'\n'+(r/'sidebar-fit.js').read_text()+'\n'+m.group(2),out,count=1,flags=re.S)
assert count==1
def unchanged(s):
 s=re.sub(r'<style id="sidebar-design-20261025">.*?</style>\s*','',s,flags=re.S)
 s=re.sub(script_pattern,'SIDEBAR_FIT_SCRIPT',s,count=1,flags=re.S)
 a=s.index('<div class="sidebar-col"');b=s.index('<div class="main-content">',a)
 return s[:a]+'SIDEBAR_MARKUP'+s[b:]
assert unchanged(out)==unchanged(before)
for tab in icons:
 assert out.count('data-tab="'+tab+'"')==before.count('data-tab="'+tab+'"')
assert '<script id="trainer-channel-20261024-script">' in out
(r/'index.html').write_text(out)
result={'only_sidebar_changed':True,'navigation_buttons_preserved':8,'unified_inline_icons':8,'channel_code_unchanged':True,'sidebar_policy_links_absent':True,'bytes':len(out.encode()),'sha256':hashlib.sha256(out.encode()).hexdigest()}
(r/'build-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
