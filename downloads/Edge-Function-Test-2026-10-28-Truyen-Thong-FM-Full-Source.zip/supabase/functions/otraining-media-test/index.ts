// Read-only media adapter for Dashboard Test. Existing production functions stay unchanged.
// JWT verification is enabled at the gateway, as on otraining-testonline.
const CORS={
  'Access-Control-Allow-Origin':'https://centraltraining.github.io',
  'Access-Control-Allow-Headers':'authorization,apikey,content-type',
  'Access-Control-Allow-Methods':'POST,OPTIONS',
  'Vary':'Origin',
};
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{...CORS,'Content-Type':'application/json'}});
const clean=value=>String(value??'').trim();
const identifier=value=>/^[1-9]\d{0,8}$/.test(clean(value));
const count=value=>Number.isSafeInteger(Number(value))&&Number(value)>=0?Number(value):0;
Deno.serve(async req=>{
  const origin=req.headers.get('origin');
  if(origin&&origin!=='https://centraltraining.github.io')return json({error:'Nguồn truy cập không hợp lệ.'},403);
  if(req.method==='OPTIONS')return new Response(null,{status:204,headers:CORS});
  if(req.method!=='POST')return json({error:'Chỉ hỗ trợ POST.'},405);
  if(Number(req.headers.get('content-length')||0)>2000)return json({error:'Yêu cầu quá dài.'},413);
  let body;
  try{const raw=await req.text();if(raw.length>2000)return json({error:'Yêu cầu quá dài.'},413);body=JSON.parse(raw);}
  catch{return json({error:'Yêu cầu không hợp lệ.'},400);}
  if(!body||typeof body!=='object'||Array.isArray(body)||body.type!=='media')return json({error:'Chỉ hỗ trợ dữ liệu Truyền thông Nội bộ.'},400);
  const campaignType=body.campaignType??'noibo';
  if(!['noibo','fm'].includes(campaignType)||!identifier(body.campaignId))return json({error:'Nguồn hoặc ID chiến dịch không hợp lệ.'},400);
  if(campaignType==='fm'&&!identifier(body.programId))return json({error:'Nguồn FM cần Program ID hợp lệ.'},400);
  if(body.programId!==undefined&&body.programId!==null&&body.programId!==''&&!identifier(body.programId))return json({error:'Program ID không hợp lệ.'},400);
  const campaignId=clean(body.campaignId),programId=clean(body.programId)||'1';
  const userInfo=Deno.env.get('OTRAINING_USER_INFO');
  if(!userInfo)return json({error:'Chưa sẵn sàng kết nối otraining.'},503);
  const url=new URL('https://otraining.io.vn/api/media-dashboard/employees');
  url.search=new URLSearchParams({campaignType,campaignId,programId,vung:'Mien Trung',area:'all',search:'',page:'1',limit:'999999'}).toString();
  let response,data;
  try{
    response=await fetch(url,{method:'GET',redirect:'error',headers:{'x-user-info':userInfo,'Accept':'application/json','Referer':'https://otraining.io.vn/quanly_kqtt.html'},signal:AbortSignal.timeout(30000)});
    if(!response.ok)return json({error:'otraining chưa trả được dữ liệu (HTTP '+response.status+'). Dữ liệu đã lưu được giữ nguyên.'},502);
    data=await response.json();
  }catch{return json({error:'Chưa đọc được dữ liệu otraining. Hãy thử lại; dữ liệu đã lưu được giữ nguyên.'},502);}
  if(data?.success===false||data?.ok===false)return json({error:'otraining chưa xác nhận dữ liệu chiến dịch. Dữ liệu đã lưu được giữ nguyên.'},502);
  const employees=Array.isArray(data)?data:(data?.employees??data?.data??data?.rows);
  if(!Array.isArray(employees)||employees.some(e=>!e||typeof e!=='object'||!Array.isArray(e.programs)))return json({error:'Dữ liệu Truyền thông chưa đúng định dạng. Dữ liệu đã lưu được giữ nguyên.'},502);
  const out=employees.map(e=>({
    code:clean(e.employee_code??e.code),name:clean(e.full_name??e.name),area:clean(e.area),
    programs:e.programs.filter(p=>p&&typeof p==='object').map(p=>({
      programId:p.program_id??p.programId??null,name:clean(p.program_name??p.name),
      approved:count(p.approved),target:count(p.target),submitted:count(p.submitted),
    })),
  }));
  return json({ok:true,campaignId,programId,campaignType,count:out.length,employees:out});
});
