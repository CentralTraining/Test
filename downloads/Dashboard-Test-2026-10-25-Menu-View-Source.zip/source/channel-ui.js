function channelFollowerDate_(at){return at?new Date(at).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'}):'—';}
function channelFollowerPointDate_(point){return point?.dateOnly?point.date.split('-').reverse().join('/')+' · mốc Admin ghi nhận':channelFollowerDate_(point?.at);}
function channelFollowerSigned_(n,suffix=''){return n===null||n===undefined?'—':(n>0?'+':'')+channelNumber_(n)+suffix;}
function channelFollowerTone_(n){return n===null?'unknown':n>0?'up':n<0?'down':'flat';}
function channelFollowerCount_(value,signed=false){
 const full=signed?channelFollowerSigned_(value):channelNumber_(value),compact=value===null||value===undefined?'—':(signed&&value>0?'+':'')+new Intl.NumberFormat('vi-VN',{notation:'compact',maximumFractionDigits:1}).format(value);
 return `<span class="channel-count-full">${full}</span><span class="channel-count-compact">${compact}</span>`;
}
function channelFollowerState_(r){
 if(r.status==='unavailable')return 'Chưa cập nhật được; giữ mốc trước';
 if(!r.connected)return 'Chưa kết nối';
 if(!r.baseline)return 'Thiếu số follower thực tế ngày 01/10/2026';
 if(!r.authorized)return 'Cần cấp quyền follower';
 if(!r.last)return 'Chưa có mốc cuối để đối chiếu';
 return r.partial?'Theo mốc cuối đã ghi nhận':'Đối chiếu với mốc 01/10/2026';
}
function channelFollowerCells_(trainer,period){
 const r=FollowerModel.row(trainer,period),e=channelEscape_,tip=r.comparable?'Mốc gốc: '+channelFollowerPointDate_(r.first)+' · '+r.first.count+'; mốc cuối: '+channelFollowerPointDate_(r.last)+' · '+r.last.count:channelFollowerState_(r);
 return `<td class="channel-follower-current" title="${e(r.asOf?'Mốc gần nhất: '+channelFollowerDate_(r.asOf)+' · '+r.current:'Chưa ghi nhận follower')}">${channelFollowerCount_(r.current)}<small>${r.asOf?e(new Date(r.asOf).toLocaleDateString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',day:'2-digit',month:'2-digit'})):'Chưa có mốc'}</small></td><td class="channel-follower-change ${channelFollowerTone_(r.delta)}" title="${e(tip)}"><button type="button" class="channel-follow-detail" data-channel-followers="${e(r.id)}">${channelFollowerCount_(r.delta,true)}</button><small>${r.comparable?channelFollowerSigned_(r.growthPct,'%'):!r.baseline?'Thiếu mốc 01/10':r.authorized?'Chưa có mốc cuối':'Cần cấp quyền'}</small></td>`;
}
function channelFollowerTrend_(row){
 const e=channelEscape_,points=row.points;
 if(!points.length)return `<div class="channel-follow-empty">${e(channelFollowerState_(row))}. ${row.authorized?'Bấm Đồng bộ TikTok để ghi số follower hiện tại.':'Chủ kênh cấp quyền follower để bắt đầu tự ghi nhận.'}</div>`;
 const position=p=>p.dateOnly?Date.parse(p.date+'T00:00:00+07:00'):Date.parse(p.at);
 const width=760,height=190,left=95,right=25,top=20,bottom=35,first=position(points[0]),last=position(points[points.length-1]),minimum=Math.min(...points.map(p=>p.count)),maximum=Math.max(...points.map(p=>p.count)),padding=Math.max(1,(maximum-minimum)*.15),low=Math.max(0,minimum-padding),high=maximum+padding;
 const axis=n=>new Intl.NumberFormat('vi-VN',{notation:'compact',maximumFractionDigits:1}).format(n),x=p=>points.length===1?width/2:left+(position(p)-first)/Math.max(1,last-first)*(width-left-right),y=p=>height-bottom-(p.count-low)/Math.max(1,high-low)*(height-top-bottom);
 const polyline=points.map(p=>x(p).toFixed(2)+','+y(p).toFixed(2)).join(' '),labels=[points[0],...(points.length>1?[points[points.length-1]]:[])];
 const note=row.comparable?'Mốc 01/10: '+channelNumber_(row.first.count)+' → mốc cuối '+channelNumber_(row.last.count)+' follower · '+channelFollowerState_(row):!row.baseline?'Đã ghi '+points.length+' mốc hiện tại; còn thiếu số follower thực tế ngày 01/10/2026.':row.last?'Mốc gốc và mốc cuối chưa đủ điều kiện đối chiếu.':'Đã có mốc gốc; đang chờ mốc đồng bộ từ TikTok.';
 return `<div class="channel-follow-trend"><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Follower ${e(row.name)} theo các mốc ghi nhận"><line x1="${left}" y1="${height-bottom}" x2="${width-right}" y2="${height-bottom}" class="channel-follow-axis"/><text x="${left-8}" y="${top+8}" text-anchor="end">${axis(Math.ceil(high))}</text><text x="${left-8}" y="${height-bottom}" text-anchor="end">${axis(Math.floor(low))}</text>${points.length>1?`<polyline points="${polyline}" class="channel-follow-line"/>`:''}${points.map(p=>`<circle cx="${x(p).toFixed(2)}" cy="${y(p).toFixed(2)}" r="4" tabindex="0" class="${p.dateOnly?'manual-baseline':''}"><title>${e(channelFollowerPointDate_(p))}: ${channelNumber_(p.count)} follower</title></circle>`).join('')}${labels.map((p,i)=>`<text x="${points.length===1?width/2:i?width-right:left}" y="${height-10}" text-anchor="${points.length===1?'middle':i?'end':'start'}">${e(channelFollowerPointDate_(p).replace(' · mốc Admin ghi nhận',''))}</text>`).join('')}</svg><div class="channel-follow-observed">${e(note)}</div></div>`;
}
function channelFollowerHistory_(trainer,period){
 if(!trainer)return;const r=FollowerModel.row(trainer,period),e=channelEscape_,n=channelNumber_;
 channelDialog_(r.name+' · Lịch sử follower',`<p class="channel-note">${e(channelFollowerState_(r))}. Mốc gốc: 01/10/2026; nguồn của mỗi mốc được ghi rõ.</p>${channelFollowerTrend_(r)}<div class="channel-follow-history"><table><thead><tr><th>Mốc ghi nhận · giờ Việt Nam</th><th>Follower</th><th>Nguồn</th></tr></thead><tbody>${r.points.map(p=>`<tr><td>${e(channelFollowerPointDate_(p))}</td><td>${n(p.count)}</td><td>${p.dateOnly?'Admin nhập':'TikTok API'}</td></tr>`).join('')||'<tr><td colspan="3">Chưa có mốc đã ghi nhận.</td></tr>'}</tbody></table></div>`);
}
function channelFollowerHelp_(){
 channelDialog_('Theo dõi follower từ 01/10/2026',`<ol><li>Trong TikTok for Developers, chọn đúng ứng dụng hoặc Sandbox → <b>Scopes → Add scopes → user.info.stats</b>, rồi lưu.</li><li>Chủ kênh bấm <b>Cấp quyền follow</b>, đăng nhập đúng kênh đã gán và đồng ý quyền bổ sung. Các lần đồng bộ sau sẽ tự lấy follower hiện tại.</li><li>Mức tăng = follower mốc cuối − follower thực tế ngày <b>01/10/2026</b>. TikTok API không trả số lịch sử ngày 01/10 nếu trước đó ứng dụng chưa ghi nhận.</li><li>Nếu có bản ghi hoặc báo cáo thực tế ngày 01/10, Admin có thể nhập tại <b>Mốc 01/10</b>. Mốc này được đánh dấu nguồn Admin; để trống khi chưa có số liệu.</li><li>Chọn Trainer để xem các mốc và biểu đồ. Số liệu chưa đủ sẽ hiển thị “—”; không lấy follower hiện tại làm số ngày 01/10.</li></ol>`);
}
function channelFollowerBaseline_(){
 if(!isAdmin())return;const list=(channelView_.data?.trainers||[]).filter(t=>t.handle),e=channelEscape_;
 if(!list.length){channelMessage_('Gán kênh TikTok trước khi nhập mốc đầu kỳ.',true);return;}
 const ov=channelDialog_('Mốc follower ngày 01/10/2026',`<form id="channelFollowerBaselineForm"><label>Trainer<select id="channelFollowerBaselineTrainer">${list.map(t=>`<option value="${e(t.id)}">${e(t.name)} · @${e(t.handle)}</option>`).join('')}</select></label><label>Follower thực tế ngày 01/10/2026<input id="channelFollowerBaselineCount" type="number" min="0" step="1" required placeholder="Nhập số liệu đã ghi nhận ngày 01/10"></label><p class="channel-note">Chỉ nhập số từ bản ghi hoặc báo cáo thực tế. Mốc được đánh dấu nguồn Admin nhập; không tự sao chép số hiện tại hoặc điền 0 khi chưa có số đầu kỳ.</p><p id="channelFollowerBaselineError" role="alert" style="color:var(--red)"></p><button type="submit" class="primary">Lưu mốc 01/10</button></form>`);
 const select=ov.querySelector('#channelFollowerBaselineTrainer'),input=ov.querySelector('#channelFollowerBaselineCount'),fill=()=>{const baseline=list.find(t=>String(t.id)===select.value)?.followers?.baseline;input.value=Number.isSafeInteger(baseline?.count)?String(baseline.count):'';};select.onchange=fill;fill();
 ov.querySelector('form').onsubmit=async event=>{event.preventDefault();const button=ov.querySelector('[type=submit]');try{if(input.value.trim()==='')throw Error('Chưa có số follower đầu kỳ.');const count=Number(input.value);if(!Number.isSafeInteger(count)||count<0)throw Error('Nhập số nguyên không âm.');button.disabled=true;await channelApi_('set_follower_baseline',{trainerId:select.value,count});ov.remove();await channelLoad_();channelMessage_('Đã lưu mốc 01/10/2026 theo số liệu Admin nhập.');}catch(error){ov.querySelector('#channelFollowerBaselineError').textContent=error.message;button.disabled=false;}};
}
function channelBindFollowers_(root,trainers,period){
 root.querySelectorAll('[data-channel-followers]').forEach(b=>b.onclick=()=>channelFollowerHistory_(trainers.find(t=>String(t.id)===b.dataset.channelFollowers),period));
 root.querySelectorAll('[data-channel-follow-connect]').forEach(b=>b.onclick=()=>channelConnect_(b.dataset.channelFollowConnect,true));
 root.querySelectorAll('[data-channel-follow-help]').forEach(b=>b.addEventListener('click',channelFollowerHelp_));root.querySelector('[data-channel-follow-baseline]')?.addEventListener('click',channelFollowerBaseline_);
}
