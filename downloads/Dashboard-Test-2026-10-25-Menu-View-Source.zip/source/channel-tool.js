/* Extensions / Channel building. All TikTok calls go through the authenticated
   Edge Function. No account tokens, API secrets, or scraped content in HTML. */
let channelView_={filters:{mode:'week',anchor:ChannelModel.today(),month:ChannelModel.today().slice(0,7),from:ChannelModel.today(),to:ChannelModel.today(),region:'',trainer:''},data:null,owner:'',configured:false,managementOpen:false,busy:false,load:0,request:0,timer:null};
const channelEscape_=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const channelNumber_=n=>n===null||n===undefined?'—':Number(n).toLocaleString('vi-VN');
const channelShort_=s=>String(s||'').trim().split(/\s+/).slice(-2).join(' ');
function channelOwner_(){return session?JSON.stringify([session.userId,session.role,session.region,session.trainerId]):'';}
function channelUrl_(){return SUPABASE_URL+'/functions/v1/'+(location.pathname.startsWith('/Test/')?'trainer-channel-test':'trainer-channel');}
function channelMessage_(text,error=false){const box=document.getElementById('channelStatus');if(box){box.textContent=text;box.dataset.error=String(error);}}
async function channelApi_(action,extra={}){
 const owner=channelOwner_();const token=action==='status'?null:await workshopNoiboToken_();
 const res=await fetch(channelUrl_(),{method:'POST',headers:{'Content-Type':'application/json',apikey:SUPABASE_ANON_KEY},body:JSON.stringify({action,...extra,...(token?{dashboardToken:token}:{})}),signal:AbortSignal.timeout(115000)});
 let out;try{out=await res.json();}catch{throw Error('Chưa nhận được phản hồi Xây kênh. Hãy thử lại.');}
 if(owner!==channelOwner_())throw Error('Tài khoản đã thay đổi. Hãy mở lại Xây kênh.');
 if(res.status===401)sessionStorage.removeItem('workshop_private_session');
 if(!res.ok||!out.ok)throw Error(out.error||'Không đọc được dữ liệu Xây kênh.');return out;
}
function channelInitial_(){
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[Đđ]/g,'d').toLowerCase().replace(/[^a-z0-9]/g,'');
 return (config.trainers||[]).filter(t=>isAdmin()||isTrainer()&&norm(session.region)&&norm(t.region)===norm(session.region)).map(t=>({...t,id:String(t.id),known:false,connected:false,handle:'',videos:[]}));
}
async function renderChannelTool_(){
 const root=document.getElementById('channelTool');if(!root)return;
 const owner=channelOwner_();if(owner!==channelView_.owner){clearTimeout(channelView_.timer);channelView_.data=null;channelView_.owner=owner;channelView_.filters.region='';channelView_.filters.trainer='';channelView_.managementOpen=false;channelView_.busy=false;}
 channelDraw_();if(!isAdmin()&&!isTrainer())return;
 const load=++channelView_.load;
 try{
  const status=await channelApi_('status');if(load!==channelView_.load||owner!==channelOwner_())return;channelView_.configured=status.configured;
  await channelLoad_(false);if(load!==channelView_.load||owner!==channelOwner_())return;channelDraw_();
  if(channelView_.configured){channelSync_(false);}
 }catch(error){channelDraw_();channelMessage_(error.message,true);}
 if(location.hash.startsWith('#channel-connect=')){
  const ok=location.hash==='#channel-connect=ok';history.replaceState(null,'',location.pathname+location.search);channelMessage_(ok?'Đã kết nối TikTok. Đang đọc video…':'Chưa kết nối được. Hãy dùng đúng tài khoản TikTok được gán và đồng ý đủ quyền.',!ok);
 }
}
async function channelLoad_(draw=true){
 const owner=channelOwner_(),period=ChannelModel.period(channelView_.filters),version=++channelView_.request;
 const data=await channelApi_('overview',{from:period.from,to:period.to});
 if(owner!==channelOwner_()||version!==channelView_.request)return;
 channelView_.data=data;if(draw)channelDraw_();
}
// Date filters are independent from monthly KPI data and never write to KPI records.
function channelDraw_(){
 const root=document.getElementById('channelTool');if(!root)return;
 if(!isAdmin()&&!isTrainer()){root.innerHTML='<div class="channel-empty">Mục Xây kênh dành cho Admin và Trainer.</div>';return;}
 const f=channelView_.filters,list=channelView_.data?.trainers||channelInitial_();let period;
 try{period=ChannelModel.period(f);}catch(e){channelMessage_(e.message,true);return;}
 const regions=[...new Set(list.map(t=>t.region).filter(Boolean))],trainers=list.filter(t=>!f.region||t.region===f.region);
 const selected=trainers.filter(t=>!f.trainer||String(t.id)===f.trainer),report=ChannelModel.report(selected,period),e=channelEscape_,num=channelNumber_;
 const choices=(rows,value)=>rows.map(([v,label])=>`<option value="${e(v)}" ${v===value?'selected':''}>${e(label)}</option>`).join('');
 const videoText=report.totals.known?num(report.totals.actual):'—',pct=report.complete&&report.totals.target?Math.round(report.totals.actual/report.totals.target*1000)/10:null;
 root.innerHTML=`<div class="channel-heading channel-compact-heading"><div><h2>Xây kênh TikTok</h2><p>3 bài/tuần · Theo dõi tiến độ và tương tác</p></div><div class="channel-heading-actions"><button type="button" class="secondary" data-channel-manage>Quản lý kênh</button><button type="button" class="secondary" id="channelSync" ${channelView_.busy||!channelView_.configured?'disabled':''}>↻ Đồng bộ</button></div></div>
 ${!channelView_.configured?`<div class="channel-banner"><strong>Chưa cấu hình ứng dụng TikTok.</strong> Admin gán trang cho Trainer, sau đó hoàn tất Login Kit và Display API để tự lấy video, like/share. <button type="button" class="secondary" id="channelSetup">Hướng dẫn kết nối</button></div>`:''}
 <div class="channel-toolbar" aria-label="Bộ lọc tiến độ xây kênh">
  <div class="channel-modes" role="group" aria-label="Kỳ báo cáo">${[['week','Tuần'],['month','Tháng'],['range','Khoảng ngày']].map(([v,label])=>`<button type="button" data-channel-mode="${v}" aria-pressed="${f.mode===v}">${label}</button>`).join('')}</div>
  ${f.mode==='week'?`<label>Chọn tuần<input type="date" id="channelAnchor" value="${f.anchor}"></label>`:f.mode==='month'?`<label>Chọn tháng<input type="month" id="channelMonth" value="${f.month}"></label>`:`<label>Từ ngày<input type="date" id="channelFrom" value="${f.from}"></label><label>Đến ngày<input type="date" id="channelTo" value="${f.to}"></label>`}
  <label>Khu vực<select id="channelRegion"><option value="">Tất cả khu vực</option>${choices(regions.map(r=>[r,r]),f.region)}</select></label>
  <label>Trainer<select id="channelTrainer"><option value="">Tất cả Trainer</option>${choices(trainers.map(t=>[String(t.id),t.name]),f.trainer)}</select></label>
 </div>
 <div class="channel-status" id="channelStatus" role="status" aria-live="polite">${channelView_.busy?'Đang đồng bộ video và chỉ số kênh…':`${period.from.split('-').reverse().join('/')} – ${period.to.split('-').reverse().join('/')} · Đã có dữ liệu ${report.totals.known}/${selected.length} Trainer`}</div>
 ${channelCompactSummary_(report,selected,period)}
 <div class="channel-grid channel-grid-compact"><section class="channel-card channel-posts-panel"><div class="channel-panel-title"><h3>Tiến độ bài đăng</h3></div><p class="channel-panel-caption">3 bài/tuần · Giữ số thực khi vượt target</p><div class="channel-posts-head"><span>Trainer</span><span>Tiến độ</span><span>Bài / Target</span></div>
 ${report.rows.map(t=>`<div class="channel-chart-row" title="${e(t.name)} · ${t.actual===null?'Chưa đồng bộ':t.actual+'/'+t.target+' video'}"><div class="channel-chart-name" title="${e(t.name)}">${e(channelShort_(t.name))}<small>${e(t.region)}</small></div><div class="channel-track ${t.known?'':'unknown'}" role="img" aria-label="${e(t.name)}: ${t.actual===null?'chưa đồng bộ':t.actual+'/'+t.target+' video'}">${t.known?`<i style="width:${Math.min(100,t.pct||0)}%"></i>`:''}</div><div class="channel-chart-value">${t.known?num(t.actual)+'/'+num(t.target):'— / '+num(t.target)}<small>${t.pct===null?'Chưa đồng bộ':num(t.pct)+'%'}</small></div></div>`).join('')||'<div class="channel-empty">Chưa có Trainer trong phạm vi.</div>'}
 </section>${channelMetricsCard_(report,period)}</div>
 <section class="channel-card channel-rhythm-panel"><h3>Nhịp đăng video</h3><p>${period.days>35?'Theo từng nhóm 7 ngày':'Theo ngày'} · Giờ Việt Nam</p>${channelTimeline_(report)}
 </section>
 <details class="channel-management" id="channelManagement" ${channelView_.managementOpen?'open':''}><summary><span>Quản lý kênh · ${selected.length} Trainer</span></summary><div class="channel-management-body"><div class="channel-management-tools">${isAdmin()?'<button type="button" class="secondary" data-channel-follow-baseline>Mốc follower 01/10</button>':''}<button type="button" class="secondary" data-channel-follow-help>Hướng dẫn follower</button></div> <section class="channel-card"><div class="channel-heading"><div><h3>Kênh của từng Trainer</h3><p>Số liệu chỉ tính video công khai; bấm Trainer để xem video</p></div>${isAdmin()?'<button type="button" class="secondary" id="channelAssign">＋ Gán trang TikTok</button>':''}</div>
 <table class="channel-detail-table" aria-label="Tiến độ xây kênh TikTok"><thead><tr><th>Trainer</th><th>Trang TikTok</th><th>Video / Target</th><th>♥ Like</th><th>↗ Share</th><th>Follower gần nhất</th><th>Tăng từ 01/10</th><th>Kết nối</th></tr></thead><tbody>${report.rows.map(t=>`<tr><td><button type="button" class="secondary" data-channel-videos="${e(t.id)}" title="${e(t.name)}">${e(channelShort_(t.name))}</button><small>${e(t.region)}</small></td><td>${t.handle?`<a href="https://www.tiktok.com/@${e(t.handle)}" target="_blank" rel="noopener noreferrer">@${e(t.handle)}</a>`:'Chưa gán'}</td><td>${t.known?num(t.actual):'—'} / ${num(t.target)}<small>${t.pct===null?'Chưa đồng bộ':num(t.pct)+'%'}</small></td><td>${num(t.likes)}</td><td>${num(t.shares)}</td>${channelFollowerCells_(t,period)}<td><span class="channel-tag ${t.known?'good':'wait'}">${t.known?'Đã đồng bộ':t.connected?'Đã kết nối':t.handle?'Chờ kết nối':'Chưa gán'}</span>${isAdmin()||String(t.id)===String(session.trainerId)?`<button type="button" class="secondary" data-channel-connect="${e(t.id)}" ${!t.handle||!channelView_.configured?'disabled':''} title="Đăng nhập đúng tài khoản TikTok đã gán">${t.connected?'Kết nối lại':'Kết nối'}</button>`:''}${t.connected&&!t.followers?.authorized&&(isAdmin()||String(t.id)===String(session.trainerId))?`<button type="button" class="secondary" data-channel-follow-connect="${e(t.id)}">Cấp quyền follow</button>`:''}<small>${t.syncedAt?e(new Date(t.syncedAt).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})):''}</small></td></tr>`).join('')||'<tr><td colspan="8">Chưa có Trainer trong phạm vi.</td></tr>'}</tbody></table></section>
 <p class="channel-note">Tuần: thứ Hai – Chủ nhật. Target tháng/khoảng ngày = 3 × số ngày theo dõi / 7, làm tròn lên. Like/share là tổng hiện tại của các video đăng trong kỳ, không phải lượt tương tác tăng riêng trong kỳ. Tự đồng bộ khi mở trang và mỗi 15 phút khi đang xem; TikTok có thể cập nhật số liệu chậm.</p>
 </div></details>`;
 root.querySelectorAll('[data-channel-mode]').forEach(b=>b.onclick=()=>{f.mode=b.dataset.channelMode;channelDraw_();channelChangePeriod_();});
 const bind=(id,field,reset=false)=>{const el=root.querySelector('#'+id);if(el)el.onchange=()=>{const prev=f[field];f[field]=el.value;if(reset)f.trainer='';try{ChannelModel.period(f);if(['region','trainer'].includes(field))channelDraw_();else channelChangePeriod_();}catch(error){f[field]=prev;el.value=prev;channelMessage_(error.message,true);}};};
 [['channelAnchor','anchor'],['channelMonth','month'],['channelFrom','from'],['channelTo','to'],['channelRegion','region',true],['channelTrainer','trainer']].forEach(args=>bind(...args));
 root.querySelector('#channelSync').onclick=()=>channelSync_(true);root.querySelector('#channelSetup')?.addEventListener('click',channelSetup_);root.querySelector('#channelAssign')?.addEventListener('click',channelAssign_);
 root.querySelectorAll('[data-channel-connect]').forEach(b=>b.onclick=()=>channelConnect_(b.dataset.channelConnect));
 root.querySelectorAll('[data-channel-videos]').forEach(b=>b.onclick=()=>channelVideos_(report.rows.find(t=>t.id===b.dataset.channelVideos)));
 channelBindFollowers_(root,selected,period);
 channelBindCompact_(root);
}
async function channelChangePeriod_(){channelView_.data=null;channelDraw_();channelMessage_('Đang tải số liệu theo kỳ đã chọn…');try{await channelLoad_();}catch(error){channelMessage_(error.message,true);}}
function channelTimeline_(report){
 if(!report.totals.known)return '<div class="channel-timeline no-values">Kết nối TikTok để xem nhịp đăng video</div>';
 const max=Math.max(1,...report.bins.map(b=>b.count));return `<div class="channel-timeline" role="img" aria-label="Số video đăng theo thời gian">${report.bins.map((b,i)=>`<div class="channel-day" title="${b.from} – ${b.to}: ${b.count} video"><div class="channel-day-bar" style="height:${Math.max(1,b.count/max*110)}px">${b.count?`<span>${b.count}</span>`:''}</div><small>${report.bins.length>16&&i%3?'':b.from.slice(5).split('-').reverse().join('/')}</small></div>`).join('')}</div>`;
}
function channelDialog_(title,html){
 document.querySelector('.channel-overlay')?.remove();const ov=document.createElement('div');ov.className='channel-overlay';ov.innerHTML=`<div class="channel-dialog" role="dialog" aria-modal="true" aria-label="${channelEscape_(title)}"><button type="button" class="channel-close" aria-label="Đóng">×</button><h3>${channelEscape_(title)}</h3>${html}</div>`;
 const close=()=>ov.remove();ov.querySelector('.channel-close').onclick=close;ov.onclick=e=>{if(e.target===ov)close();};ov.onkeydown=e=>{if(e.key==='Escape')close();};document.body.append(ov);ov.querySelector('button')?.focus();return ov;
}
function channelSetup_(){
 const test=location.pathname.startsWith('/Test/'),slug=test?'trainer-channel-test':'trainer-channel',redirect=SUPABASE_URL+'/functions/v1/'+slug+'/oauth/callback',site='https://centraltraining.github.io/'+(test?'Test/':'Dashboard/');
 channelDialog_('Bật tự đồng bộ TikTok',`<ol><li>Mở <a href="https://developers.tiktok.com/" target="_blank" rel="noopener noreferrer">TikTok for Developers</a> → chọn ứng dụng. Với bản thử nghiệm, tạo Sandbox và thêm đúng tài khoản TikTok vào Target users.</li><li>Thêm <b>Login Kit</b>. Trong <b>Scopes</b>, thêm <code>user.info.basic</code>, <code>user.info.profile</code>, <code>video.list</code>. Thêm <code>user.info.stats</code> để đọc follower.</li><li>Login Kit Web Redirect URI: <code>${channelEscape_(redirect)}</code>. Website: <code>${channelEscape_(site)}</code>.</li><li>Lưu cấu hình TikTok. Production cần được xét duyệt; Sandbox chỉ dùng với tài khoản thử nghiệm đã thêm.</li><li>Trong Supabase → Edge Functions → Secrets, cấu hình <code>${test?'TIKTOK_TEST_CLIENT_KEY':'TIKTOK_CLIENT_KEY'}</code> và <code>${test?'TIKTOK_TEST_CLIENT_SECRET':'TIKTOK_CLIENT_SECRET'}</code> của đúng ứng dụng hoặc Sandbox. Nhập khóa trực tiếp tại Supabase.</li><li>Admin gán đúng @TikTok cho Trainer. Chủ kênh bấm <b>Kết nối</b> để đọc video; bấm <b>Cấp quyền follow</b> để cho phép ghi mốc follower.</li></ol><p class="channel-note">Like/share là số mới nhất của video. Tăng trưởng follower được tính từ những mốc ứng dụng ghi nhận sau khi được cấp quyền, không tự dựng dữ liệu quá khứ.</p>`);
}
function channelAssign_(){
 if(!isAdmin())return;const list=channelView_.data?.trainers||channelInitial_(),e=channelEscape_;
 const ov=channelDialog_('Gán trang TikTok cho Trainer',`<form id="channelAssignForm"><label>Trainer<select id="channelAssignTrainer">${list.map(t=>`<option value="${e(t.id)}">${e(t.name)} · ${e(t.region)}</option>`).join('')}</select></label><label>Trang TikTok<input id="channelHandle" placeholder="https://www.tiktok.com/@tenkenh hoặc @tenkenh" required autocomplete="off"></label><label>Bắt đầu tính target<input id="channelTracking" type="date" required></label><p class="channel-note">Mỗi Trainer có một kênh. Đổi trang TikTok sẽ yêu cầu chủ kênh kết nối lại; số liệu kênh cũ được thay sau khi xác thực đúng kênh mới.</p><p id="channelAssignError" role="alert" style="color:var(--red)"></p><button type="submit" class="primary">Lưu trang TikTok</button></form>`);
 const select=ov.querySelector('#channelAssignTrainer'),fill=()=>{const t=list.find(t=>t.id===select.value);ov.querySelector('#channelHandle').value=t?.handle?'@'+t.handle:'';ov.querySelector('#channelTracking').value=t?.trackingFrom||ChannelModel.period(channelView_.filters).from;};select.onchange=fill;fill();
 ov.querySelector('form').onsubmit=async event=>{event.preventDefault();const b=ov.querySelector('[type=submit]');b.disabled=true;try{await channelApi_('assign',{trainerId:select.value,handle:ov.querySelector('#channelHandle').value,trackingFrom:ov.querySelector('#channelTracking').value});ov.remove();await channelLoad_();channelMessage_('Đã gán trang TikTok. Chủ kênh cần bấm Kết nối để cho phép đọc video.');}catch(error){ov.querySelector('#channelAssignError').textContent=error.message;b.disabled=false;}};
}
async function channelConnect_(id,followerStats=false){
 try{const returnUrl=location.origin+location.pathname;if(!['https://centraltraining.github.io/Test/','https://centraltraining.github.io/Dashboard/'].includes(returnUrl))throw Error('Hãy mở dashboard trên website chính thức để kết nối.');const out=await channelApi_('connect',{trainerId:id,returnUrl,followerStats:followerStats===true});const u=new URL(out.url);if(u.origin!=='https://www.tiktok.com'||u.pathname!=='/v2/auth/authorize/')throw Error('Địa chỉ kết nối TikTok không hợp lệ.');location.assign(u.href);}catch(error){channelMessage_(error.message,true);}
}
function channelVideos_(t){
 if(!t)return;const e=channelEscape_,n=channelNumber_;
 channelDialog_(t.name+' · Video trong kỳ',t.known?t.videos.map(v=>`<div class="channel-video"><a href="https://www.tiktok.com/@${e(t.handle)}/video/${e(v.id)}" target="_blank" rel="noopener noreferrer">${e(v.title||'Video TikTok')}</a><small>${e(new Date(v.createdAt).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'}))} · ♥ ${n(v.likes)} · ↗ ${n(v.shares)} · ${n(v.views)} lượt xem</small></div>`).join('')||'<p class="channel-empty">TikTok xác nhận chưa có video công khai trong kỳ này.</p>':'<p class="channel-empty">Chưa đồng bộ được dữ liệu kênh này.</p>');
}
async function channelSync_(force){
 if(channelView_.busy||!channelView_.configured)return;channelView_.busy=true;const owner=channelOwner_();channelDraw_();
 const list=(channelView_.data?.trainers||[]).filter(t=>t.connected&&(!channelView_.filters.region||t.region===channelView_.filters.region)&&(!channelView_.filters.trainer||t.id===channelView_.filters.trainer));
 let done=0,failed=0,pending=0;
 try{
  for(const t of list){
   if(owner!==channelOwner_()||currentTabId_()!=='extensions')break;
   channelMessage_('Đang đồng bộ kênh: '+t.name+' ('+(done+1)+'/'+list.length+')');
   try{let out;for(let pass=0;pass<50;pass++){out=await channelApi_('sync',{trainerId:t.id,force:!!force&&pass===0});if(out.complete)break;if(currentTabId_()!=='extensions'||owner!==channelOwner_())break;}if(out?.complete)done++;else pending++;}catch{failed++;}
  }
  if(owner===channelOwner_()){await channelLoad_(false);channelView_.busy=false;channelDraw_();channelMessage_(list.length?`Đã đồng bộ ${done}/${list.length} kênh.${failed?' '+failed+' kênh chưa lấy được; giữ dữ liệu trước.':''}${pending?' '+pending+' kênh còn đang lấy trang video.':''}`:'Chưa có kênh TikTok đã kết nối trong phạm vi.',failed>0);}
 }catch(error){channelMessage_(error.message,true);}
 finally{channelView_.busy=false;clearTimeout(channelView_.timer);if(owner===channelOwner_())channelView_.timer=setTimeout(()=>{if(currentTabId_()==='extensions')channelSync_(false);},15*60000);const btn=document.getElementById('channelSync');if(btn)btn.disabled=!channelView_.configured;}
}
document.getElementById('logoutBtn').addEventListener('click',()=>{channelView_.data=null;channelView_.owner='';channelView_.load++;channelView_.request++;clearTimeout(channelView_.timer);document.querySelector('.channel-overlay')?.remove();const root=document.getElementById('channelTool');if(root)root.replaceChildren();});
// OAuth return links reopen this extension after the existing dashboard boot completes.
if(location.hash.startsWith('#channel-connect=')){
 const watcher=setInterval(()=>{if(session&&config.trainers?.length&&document.querySelector('#mainApp:not(.hidden)')){clearInterval(watcher);document.querySelector('nav.tabs [data-tab="extensions"]')?.click();}},250);setTimeout(()=>clearInterval(watcher),30000);
}
