from pathlib import Path
import re, json, hashlib

root = Path(__file__).parent
before = (root / 'index.before.html').read_text()
script_pattern = r'(<script id="trainer-channel-20261024-script">)\s*(.*?)\s*(</script>)'
style_pattern = r'(<style id="trainer-channel-20261024">)\s*(.*?)\s*(</style>)'
script = '\n'.join((p.read_text() for p in [root/'channel-model.js', root.parent/'followers/follower-model.js', root/'channel-tool.js', root/'channel-ui.js', root/'compact-ui.js']))
assert '</script' not in script.lower()
out = re.sub(script_pattern, lambda m: m.group(1)+'\n'+script+'\n'+m.group(3), before, count=1, flags=re.S)
out = re.sub(style_pattern, lambda m: m.group(1)+'\n'+m.group(2)+'\n'+(root/'sidebar-fit.css').read_text()+'\n'+m.group(3), out, count=1, flags=re.S)
policy = '<nav class="public-policy-links" aria-label="Điều khoản và bảo mật"><a href="./terms.html" target="_blank" rel="noopener noreferrer">Điều khoản sử dụng</a><a href="./privacy.html" target="_blank" rel="noopener noreferrer">Chính sách bảo mật</a></nav>'
assert out.count(policy) == 2
sidebar_start = out.index('<div class="sidebar-col"')
sidebar_end = out.index('<div class="main-content">', sidebar_start)
menu = out[sidebar_start:sidebar_end]
assert menu.count(policy) == 1
menu = menu.replace(policy, '').replace('<div style="text-align:center;font-size:8pt;', '<div class="sidebar-tagline" style="text-align:center;font-size:8pt;')
out = out[:sidebar_start] + menu + out[sidebar_end:]
assert out.count(policy) == 1  # Existing links on the public login screen remain accessible.
body_before, closing_body, body_after = out.rpartition('</body>')
assert closing_body and '</script>' not in body_after
out = body_before + '<script id="sidebar-fit-20261025">\n'+(root/'sidebar-fit.js').read_text()+'\n</script>\n' + closing_body + body_after
def normalized(s):
    s = re.sub(script_pattern, 'CHANNEL_SCRIPT', s, count=1, flags=re.S)
    s = re.sub(style_pattern, 'CHANNEL_STYLE', s, count=1, flags=re.S)
    s = re.sub(r'<script id="sidebar-fit-20261025">.*?</script>\s*', '', s, count=1, flags=re.S)
    return s.replace(policy, '').replace(' class="sidebar-tagline"', '')
assert normalized(out) == normalized(before)
assert 'Follow · View · Like · Share' in out
(root/'index.html').write_text(out)
result = {'only_channel_and_sidebar_changes': True, 'sidebar_policy_links_removed': True, 'public_login_policy_links_preserved': True, 'backend_changed': False, 'bytes':len(out.encode()), 'sha256':hashlib.sha256(out.encode()).hexdigest()}
(root/'build-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
