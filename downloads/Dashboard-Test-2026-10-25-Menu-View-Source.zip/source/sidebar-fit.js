/* Navigation only: no account data, external requests, or changes to permissions. */
(()=>{
  const root=document.documentElement,sidebar=document.querySelector('.sidebar-col .sidebar-inner');
  if(!sidebar)return;
  let queued=false;
  function fit(){
    queued=false;
    if(root.matches('.mobile-layout,.ui-force-mobile')){
      sidebar.style.removeProperty('--sidebar-fit-height');return;
    }
    const box=sidebar.getBoundingClientRect();
    if(box.width<=0||sidebar.offsetWidth<=0)return;
    const scale=box.width/sidebar.offsetWidth;
    const available=window.innerHeight-Math.max(8,box.top)-12;
    const value=Math.max(240,Math.floor(available/scale))+'px';
    if(sidebar.style.getPropertyValue('--sidebar-fit-height')!==value)
      sidebar.style.setProperty('--sidebar-fit-height',value);
  }
  function schedule(){if(!queued){queued=true;requestAnimationFrame(fit);}}
  addEventListener('resize',schedule,{passive:true});
  addEventListener('scroll',schedule,{passive:true});
  document.addEventListener('click',event=>{if(event.target.closest('nav.tabs button'))schedule();});
  new MutationObserver(schedule).observe(root,{attributes:true,attributeFilter:['class']});
  new MutationObserver(schedule).observe(document.getElementById('mainApp'),{attributes:true,attributeFilter:['class','style']});
  const observer=new ResizeObserver(schedule);
  document.querySelectorAll('header.top,#monthStatusBar,.sidebar-brand,.sidebar-scope').forEach(el=>observer.observe(el));
  if(document.fonts?.ready)document.fonts.ready.then(schedule);
  schedule();
})();
