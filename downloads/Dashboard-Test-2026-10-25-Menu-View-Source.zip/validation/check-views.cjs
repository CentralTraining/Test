const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const context={};vm.createContext(context);
vm.runInContext(fs.readFileSync(__dirname+'/channel-model.js','utf8')+';this.model=ChannelModel;',context);
const p=context.model.period({mode:'range',from:'2026-10-01',to:'2026-10-31'});
const video=(id,createdAt,views)=>({id,createdAt,views,likes:2,shares:1});
const trainers=[
 {id:'A',known:true,videos:[video('1','2026-09-30T17:00:00Z',100),video('2','2026-10-31T16:59:59Z',250),video('3','2026-10-31T17:00:00Z',9999)]},
 {id:'B',known:false,videos:[video('4','2026-10-10T01:00:00Z',100)]},
 {id:'C',known:true,videos:[video('5','2026-10-10T01:00:00Z',undefined)]},
 {id:'D',known:true,videos:[]},
 {id:'E',known:true,videos:[video('6','2026-10-10T01:00:00Z',0)]}
];
const report=context.model.report(trainers,p);
assert.equal(report.rows[0].views,350,'only videos published in the Vietnam date range contribute views');
assert.equal(report.rows[0].actual,2);
assert.equal(report.rows[1].views,null,'unsynced channels remain unknown');
assert.equal(report.rows[2].views,null,'missing historical view data is never replaced with zero');
assert.equal(report.rows[3].views,0,'confirmed empty channel is a real zero');
assert.equal(report.rows[4].views,0,'TikTok zero view count is retained');
assert.equal(report.rows[0].likes,4);assert.equal(report.rows[0].shares,2);
console.log('View totals, Vietnam boundaries, unknown and zero values: passed');
