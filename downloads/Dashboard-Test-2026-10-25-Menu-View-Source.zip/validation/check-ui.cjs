process.env.MOBILE_HTML='menu-views/index.html';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {start,measure}=require('../mobile-audit.cjs');
const root=__dirname,at=['2026-10-19T01:00:00Z','2026-10-25T01:00:00Z'];
(async()=>{
 const results=[];
 for(const [width,height] of [[320,844],[390,844],[1024,600],[1280,500],[1366,768],[1440,900],[1920,1080]]){
  const trainers=Array.from({length:13},(_,i)=>({id:'T'+i,name:'Trainer kiểm thử '+i,region:['HUẾ','ĐÀ NẴNG','NHA TRANG'][i%3]}));
  const rows=trainers.map((t,i)=>({...t,handle:'fixture.channel.'+i,trackingFrom:'2026-10-01',connected:i<7,known:i<7,videos:i<7?[{id:'1000000'+i,createdAt:at[0],title:'Synthetic video',likes:i===6?13400000:141+i,shares:i+2,views:i===3?undefined:i===6?123456789:100}]:[],syncedAt:at[1],followers:{authorized:i!==4,status:i===4?'needs_authorization':'ready',baseline:i===2?null:{date:'2026-10-01',count:i===6?12000000:100,source:'admin_record'},current:i===6?13400000:150,asOf:at[1],history:[{at:at[0],count:i===6?12000000:100},{at:at[1],count:i===6?13400000:150}]}}));
  let trainerMode=false;const calls=[];const {browser,context,page,audit}=await start(width,data=>data.config.trainers=trainers);
  try{
   await page.setViewportSize({width,height});
   await context.route('https://centraltraining.github.io/Test/',route=>route.fulfill({status:200,contentType:'text/html',body:fs.readFileSync(path.join(root,'index.html'),'utf8')}));
   await context.route('**/functions/v1/trainer-channel*',route=>{const b=JSON.parse(route.request().postData());calls.push(b);const out={ok:true};if(b.action==='status')out.configured=true;else if(b.action==='overview')Object.assign(out,{trainers:trainerMode?rows.filter(t=>t.region==='HUẾ'):rows,from:b.from,to:b.to});else if(b.action==='sync')out.complete=true;else if(b.action==='connect')out.url='https://invalid.fixture/';return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(out)});});
   await page.goto('https://centraltraining.github.io/Test/');await page.waitForSelector('#mainApp:not(.hidden)');await page.evaluate(()=>{sessionStorage.setItem('workshop_private_session',JSON.stringify({token:'SYNTHETIC',expires:Date.now()+3600000,userId:session.userId}));channelView_.filters.anchor='2026-10-25';});
   assert(await page.locator('#monthStatusBar').isVisible());await page.locator('nav.tabs [data-tab="extensions"]').click();await page.waitForFunction(()=>channelView_.data?.trainers?.length===13&&!channelView_.busy);await page.evaluate(()=>window.scrollTo(0,0));assert(await page.locator('#monthStatusBar').isHidden());
   assert.equal(await page.locator('.channel-followers-card').count(),0,'no large follower panel above charts');assert.equal(await page.locator('.channel-summary .channel-stat').count(),4);assert.equal(await page.locator('[data-channel-metric]').count(),0);assert.equal(await page.locator('.channel-interaction-panel').count(),1);assert.equal(await page.locator('.channel-interaction-panel [role=row]').count(),14);assert.equal(await page.locator('.channel-rhythm-panel').count(),1);
   assert.equal(await page.locator('#channelManagement').getAttribute('open'),null);assert(await page.locator('.channel-detail-table').isHidden());
   const visibleHeaders=await page.locator('.channel-interaction-panel [role=columnheader]:visible').count();assert.equal(visibleHeaders,width<700?6:5);
   const geometry=await page.evaluate(()=>{const b=s=>{const r=document.querySelector(s).getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom};};return {plots:b('.channel-grid-compact'),posts:b('.channel-posts-panel'),interaction:b('.channel-interaction-panel'),rhythm:b('.channel-rhythm-panel'),summary:b('.channel-summary'),viewport:innerHeight};});
   if(width>=700){assert(Math.abs(geometry.posts.width/geometry.interaction.width-1.45)<.03);assert(geometry.posts.x<geometry.interaction.x);assert(geometry.rhythm.y>=geometry.plots.bottom-2);if(height>=850)assert(geometry.rhythm.bottom<=height,'desktop overview and posting rhythm fit in one screen');}else{assert(await page.locator('.channel-posts-panel').isHidden());assert(geometry.plots.bottom<=height,'mobile overview shows all five metrics for 13 Trainers in one screen');}
   assert.deepEqual(await page.locator('.channel-metrics-head [role=columnheader]:visible').allTextContents(),width<700?['Trainer','Bài đăng','↑ Follow','◉ View','♥ Like','↗ Share']:['Trainer','↑ Follow','◉ View','♥ Like','↗ Share']);
   const dataRows=page.locator('.channel-interaction-panel [role=row]').filter({has:page.locator('[role=rowheader]')});
   assert.equal(await dataRows.nth(0).locator('.channel-metric-cell.view .channel-metric-number').innerText(),'100');
   assert.equal(await dataRows.nth(3).locator('.channel-metric-cell.view .channel-metric-number').innerText(),'—');
   assert((await dataRows.nth(6).locator('.channel-metric-cell.view').getAttribute('title')).includes('123.456.789'));
   assert.equal(await page.locator('.sidebar-inner .public-policy-links').count(),0);
   assert.equal(await page.locator('#loginScreen .public-policy-links').count(),1);
   if(width>=700){
    await page.waitForTimeout(150);
    const navigation=await page.evaluate(()=>{
     const sidebar=document.querySelector('.sidebar-inner'),nav=sidebar.querySelector('nav.tabs'),visible=[...nav.querySelectorAll('button')].filter(el=>getComputedStyle(el).display!=='none');
     return {sidebarBottom:sidebar.getBoundingClientRect().bottom,navHeight:nav.clientHeight,navScrollHeight:nav.scrollHeight,sidebarHeight:sidebar.clientHeight,sidebarScrollHeight:sidebar.scrollHeight,items:visible.map(el=>{const r=el.getBoundingClientRect();return {tab:el.dataset.tab,top:r.top,bottom:r.bottom,height:r.height,labelFits:el.scrollHeight<=el.clientHeight+1};}),accountBottom:sidebar.querySelector('.sidebar-scope').getBoundingClientRect().bottom,viewport:innerHeight};
    });
    assert.equal(navigation.items.length,8,JSON.stringify(navigation));
    assert(navigation.sidebarBottom<=height-8,JSON.stringify(navigation));
    assert(navigation.navScrollHeight<=navigation.navHeight+2,JSON.stringify(navigation));
    assert(navigation.sidebarScrollHeight<=navigation.sidebarHeight+2,JSON.stringify(navigation));
    assert(navigation.items.every(el=>el.top>=0&&el.bottom<=height&&el.height>=16&&el.labelFits),JSON.stringify(navigation));
    assert(navigation.accountBottom<=height,JSON.stringify(navigation));
   }
   let layout=await measure(page,'compact-all');assert(layout.documentWidth<=layout.width+2,JSON.stringify(layout));assert.equal(layout.overflow.length,0,JSON.stringify(layout));
   await page.screenshot({path:path.join(root,'menu-views-'+width+'.png'),fullPage:true});
   await page.locator('[data-channel-manage]').click();await page.waitForFunction(()=>document.getElementById('channelManagement').open);assert(await page.locator('.channel-detail-table').isVisible());assert.equal(await page.locator('.channel-detail-table tbody tr').count(),13);assert(await page.locator('[data-channel-follow-connect="T4"]').isVisible());
   await page.locator('#channelTrainer').selectOption('T0');assert.equal(await page.locator('#channelManagement').getAttribute('open'),'');assert.equal(await page.locator('.channel-detail-table tbody tr').count(),1);
   await page.locator('.channel-interaction-panel [data-channel-followers="T0"]').click();assert.equal(await page.locator('.channel-follow-history tbody tr').count(),3);assert(await page.locator('.channel-dialog svg').isVisible());await page.locator('.channel-close').click();
   await page.locator('[data-channel-manage]').click();assert(await page.locator('.channel-detail-table').isHidden());await page.locator('.channel-interaction-panel [data-channel-follow-help]').click();assert((await page.locator('.channel-dialog').innerText()).includes('user.info.stats'));await page.locator('.channel-close').click();
   await page.locator('[data-channel-mode="month"]').click();await page.locator('#channelMonth').fill('2026-09');await page.locator('#channelMonth').dispatchEvent('change');await page.waitForFunction(()=>channelView_.data?.to==='2026-09-30');layout=await measure(page,'compact-month');assert.equal(layout.overflow.length,0,JSON.stringify(layout));
   await page.locator('[data-channel-mode="range"]').click();layout=await measure(page,'compact-range');assert.equal(layout.overflow.length,0,JSON.stringify(layout));
   trainerMode=true;await page.evaluate(()=>{session={userId:'UT0',username:'fixture-trainer',role:'trainer',region:'HUẾ',trainerId:'T0'};sessionStorage.setItem('workshop_private_session',JSON.stringify({token:'TRAINER_SYNTHETIC',expires:Date.now()+3600000,userId:session.userId}));renderChannelTool_();});await page.waitForFunction(()=>channelView_.data?.trainers?.length===5&&!channelView_.busy);assert.equal(await page.locator('.channel-interaction-panel [role=row]').count(),6);assert.equal(await page.locator('[data-channel-follow-baseline]').count(),0);assert.equal(audit.errors.length,0,audit.errors.join('\n'));assert.equal(audit.writes,0,'UI does not write KPI or Trainer data');
   await page.locator('nav.tabs [data-tab="kpi"]').click();assert(await page.locator('#monthStatusBar').isVisible(),'KPI month status remains on KPI pages');
   if(width>=700){await page.evaluate(()=>window.scrollTo(0,0));await page.waitForTimeout(150);const fit=await page.evaluate(()=>{const el=document.querySelector('.sidebar-inner'),nav=el.querySelector('nav.tabs');return {bottom:el.getBoundingClientRect().bottom,scroll:nav.scrollHeight,height:nav.clientHeight};});assert(fit.bottom<=height-8&&fit.scroll<=fit.height+2,JSON.stringify(fit));}
   results.push({width,height,visibleHeaders,geometry,layout,noLargeFollowerPanel:true,simultaneousMetrics:true,managementCollapsed:true,regionScopePreserved:true});console.log(JSON.stringify({width,plotsBottom:geometry.plots.bottom,rhythmBottom:geometry.rhythm.bottom,viewport:height,noOverflow:true}));
  }finally{await browser.close();}
 }
 fs.writeFileSync(path.join(root,'ui-verification.json'),JSON.stringify(results,null,2)+'\n');
})().catch(e=>{console.error(e);process.exitCode=1;});
