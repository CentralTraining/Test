# Dashboard Test — Menu và View — 25/10/2026

Phạm vi: giao diện Test tại https://centraltraining.github.io/Test/.

- Menu máy tính chia đều các nút trong chiều cao màn hình, giữ đủ Home đến Tài khoản và thông tin người dùng; không có thanh cuộn riêng trong menu.
- Chiều cao menu được đo theo viewport, có tính đến mức thu gọn desktop hiện có; tự cập nhật khi đổi trang hoặc kích thước cửa sổ.
- Bỏ hai liên kết Điều khoản/Bảo mật khỏi sidebar theo yêu cầu. Các trang pháp lý và liên kết trên màn hình đăng nhập vẫn giữ nguyên.
- Bảng tương tác thêm View ngay sau Follow, trước Like và Share. Màu thanh View riêng; số rút gọn hiển thị đầy đủ khi rê chuột.
- View là tổng view mới nhất của các video được đăng trong kỳ ngày Việt Nam đang chọn. Đây không phải view tăng riêng trong kỳ.
- Kênh chưa đồng bộ hoặc bản ghi cũ thiếu view hiển thị “—”; số 0 xác nhận từ API giữ nguyên.
- Mobile vẫn hiển thị một dòng/Trainer với Bài đăng, Follow, View, Like, Share; giữ nguyên hai khung trên desktop và nhịp đăng video bên dưới.
- Không sửa Edge Function, Secrets, quyền truy cập, dữ liệu, bot KPI hoặc dashboard chính.

Kiểm tra: viewport 320×844, 390×844, 1024×600, 1280×500, 1366×768, 1440×900, 1920×1080; menu không cuộn và không cắt mục; không tràn ngang; bộ lọc, trạng thái thiếu dữ liệu, lịch sử follower, quyền khu vực và KPI tháng tiếp tục hoạt động. Kiểm thử chỉ dùng dữ liệu giả lập.

`index.html` là toàn bộ dashboard, dùng để lưu phiên bản. Thư mục `source/` chứa các phần nguồn thay đổi và phụ thuộc follower không đổi. Thư mục `verification/` chứa kết quả kiểm tra. Không có khóa bí mật hay dữ liệu riêng trong gói.
