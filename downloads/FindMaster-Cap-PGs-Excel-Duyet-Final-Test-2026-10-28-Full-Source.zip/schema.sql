-- Additive, private workflow store. Test writes environment=test only.
-- Existing pgsm_pair_groups and Master/KV data remain unchanged.
begin;
create table public.pgsm_pair_workflows (
 environment text not null check(environment in ('test','main')),
 campaign_id text not null,
 trainer_id text not null,
 version bigint not null default 1 check(version>=1),
 groups jsonb not null default '[]'::jsonb check(jsonb_typeof(groups)='array' and jsonb_array_length(groups)<=500),
 state text not null default 'draft' check(state in ('draft','pending','approved','returned')),
 roster_revision text not null,
 legacy_version bigint not null default 0,
 submitted_at timestamptz,
 submitted_by text,
 reviewed_at timestamptz,
 reviewed_by text,
 return_note text not null default '' check(length(return_note)<=500),
 updated_by text not null,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 primary key(environment,campaign_id,trainer_id),
 check(state not in ('pending','approved') or (submitted_at is not null and submitted_by is not null)),
 check(state not in ('approved','returned') or (reviewed_at is not null and reviewed_by is not null)),
 check(state<>'returned' or length(btrim(return_note))>0)
);
alter table public.pgsm_pair_workflows enable row level security;
revoke all on table public.pgsm_pair_workflows from public,anon,authenticated;
grant select,insert,update,delete on table public.pgsm_pair_workflows to service_role;
comment on table public.pgsm_pair_workflows is 'Find Master pairing draft/submission/final workflow; server-only custom Dashboard authorization; Test and Main namespaces are independent.';
commit;
