export const PairModel=(()=>{
 const stages=['m1','m2','m3','m4','m5'];
 const code=v=>String(v??'').trim().replace(/\.0+$/,'').toUpperCase();
 const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[Đđ]/g,'d').toLowerCase().replace(/[^a-z0-9]/g,'');
 const flag=v=>v===true||v===1||v==='1'||v==='true'||v==='TRUE'?true:v===false||v===0||v==='0'||v==='false'||v==='FALSE'?false:null;
 const firstName=v=>String(v||'').trim().split(/\s+/).at(-1)||'Chưa có tên';
 const states={draft:'Nháp',pending:'Chờ Admin duyệt',approved:'Đã duyệt final',returned:'Trả lại chỉnh sửa',stale:'Danh sách PG đã thay đổi'};
 function roster(registered,meta,trainer){
  const map=new Map(),ambiguous=new Set(),counts=new Map();
  for(const p of registered||[]){const id=code(p.code);if(id)counts.set(id,(counts.get(id)||0)+1);}
  for(const p of registered||[]){
   if(String(p.trainerId)!==String(trainer.id)||p.region&&norm(p.region)!==norm(trainer.region))continue;
   const id=code(p.code);if(!id||counts.get(id)!==1)continue;if(map.has(id)){ambiguous.add(id);continue;}
   const source=meta?.[id],fromSystem=source?.source==='OTRAINING FM';
   const progress=Object.fromEntries(stages.map(s=>{const value=fromSystem?flag(source.done?.[s]):null;return [s,{done:value===true,known:value!==null}];}));
   // The existing Dashboard HR import explicitly matches Ma NV to Code.
   map.set(id,{code:id,employeeCode:code(p.employeeCode||p.employee_code||id),name:String(p.name||'').trim(),shopId:String(p.shopId??p.storeId??'').trim(),shop:String(p.shop||p.shopName||'').trim(),province:String(p.province||'').trim(),channel:String(p.channel||'').trim(),trainerId:String(trainer.id),region:String(trainer.region||p.region||''),progress});
  }
  ambiguous.forEach(id=>map.delete(id));return [...map.values()].sort((a,b)=>a.code.localeCompare(b.code));
 }
 function group(raw,roster,ownerId){
  const byCode=new Map(roster.map(p=>[p.code,p])),members=(Array.isArray(raw.members)?raw.members:[]).map(id=>byCode.get(code(id))||{code:code(id),employeeCode:code(id),name:'PG không còn trong danh sách',channel:'',shopId:'',shop:'',province:'',missing:true,progress:{}});
  const valid=[2,3].includes(members.length)&&(members.length!==3||roster.length%2===1)&&new Set(members.map(p=>p.code)).size===members.length&&members.every(p=>!p.missing&&p.trainerId===String(ownerId));
  const progress=Object.fromEntries(stages.map(s=>{const passed=members.filter(p=>p.progress?.[s]?.done===true).length,known=members.filter(p=>p.progress?.[s]?.known===true).length;return [s,{done:valid&&passed===members.length,passed,known,total:members.length}];}));
  return {...raw,members,valid,name:members.map(p=>firstName(p.name)).join(' - '),channels:[...new Set(members.map(p=>p.channel).filter(Boolean))],progress,completed:stages.filter(s=>progress[s].done).length};
 }
 function validate(members,roster,groups,editingId){
  if(!Array.isArray(members)||![2,3].includes(members.length))return 'Mỗi nhóm cần đúng 2 PG, hoặc 3 PG khi danh sách của Trainer có số lẻ.';
  const codes=members.map(code);if(codes.some(x=>!x)||new Set(codes).size!==codes.length)return 'Không được chọn trùng PG trong nhóm.';
  const available=new Set(roster.map(p=>p.code));if(codes.some(c=>!available.has(c)))return 'Chỉ được ghép PG trong danh sách Master do Trainer này phụ trách.';
  if(groups.some(g=>g.id!==editingId&&(g.members||[]).some(c=>codes.includes(code(c)))))return 'Một PG chỉ được thuộc một nhóm trong chiến dịch. Hãy tải lại danh sách.';
  if(codes.length===3&&(roster.length%2===0||groups.some(g=>g.id!==editingId&&g.members?.length===3)))return 'Chỉ tạo một nhóm 3 khi tổng PG của Trainer là số lẻ.';
  return '';
 }
 function complete(roster,groups){
  if(roster.length<2)return 'Trainer cần ít nhất 2 PG trong danh sách Master đã chốt.';
  if(!groups.length)return 'Chưa có nhóm để gửi Admin duyệt.';
  const codes=groups.flatMap(g=>g.members.map(p=>p.code));
  if(groups.some(g=>!g.valid)||new Set(groups.map(g=>g.id)).size!==groups.length||new Set(codes).size!==codes.length||groups.filter(g=>g.members.length===3).length>1)return 'Danh sách nhóm có PG trùng, thiếu hoặc không còn hợp lệ. Hãy ghép lại trước khi gửi.';
  if(codes.length!==roster.length||roster.some(p=>!codes.includes(p.code)))return 'Cần ghép đủ tất cả PG của Trainer trước khi gửi Admin duyệt.';
  return '';
 }
 function summary(groups){return {total:groups.length,stages:stages.map(s=>groups.filter(g=>g.progress[s].done).length),completed:groups.filter(g=>g.completed===5).length,invalid:groups.filter(g=>!g.valid).length};}
 function select(trainers,filter={}){
  const search=norm(filter.search);return trainers.filter(t=>(!filter.region||norm(t.region)===norm(filter.region))&&(!filter.trainerId||t.id===filter.trainerId)&&(!filter.state||t.effectiveState===filter.state)).flatMap(t=>t.groups.filter(g=>(!filter.channel||g.channels.includes(filter.channel))&&(!search||norm(g.name+' '+g.members.map(p=>p.name+' '+p.code+' '+p.shopId+' '+p.shop).join(' ')).includes(search))).map(g=>({...g,owner:t})));
 }
 const exportColumns=['STT','Code PG','Mã NV','Họ tên PG','Mã shop','Tên shop','Khu vực','Tỉnh/TP','Kênh','Trainer','Trạng thái duyệt','Tên cặp'];
 function exportRows(groups){let n=0;return groups.flatMap(g=>g.members.map(p=>[String(++n),p.code,p.employeeCode||'',p.name,p.shopId||'',p.shop||'',p.region||g.owner.region,p.province||'',p.channel||'',g.owner.name,states[g.owner.effectiveState]||'Nháp',g.name]));}
 return {stages,code,norm,flag,firstName,states,roster,group,validate,complete,summary,select,exportColumns,exportRows};
})();
