import { authenticate, AccessError, readDashboardValues } from './access.ts';
import { PairModel } from './model.js';
// Test-only writes. A future Main promotion must use the literal 'main'.
const ENVIRONMENT='test';
const TABLE='pgsm_pair_workflows',LEGACY='pgsm_pair_groups';
const ORIGIN='https://centraltraining.github.io';
const CORS={'Access-Control-Allow-Origin':ORIGIN,'Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'POST,OPTIONS','Cache-Control':'no-store','Vary':'Origin'};
const reply=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{...CORS,'Content-Type':'application/json'}});
const failure=(message,status=400)=>{throw new AccessError(message,status);};
const validId=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,140}$/.test(v);
const validGroupId=v=>typeof v==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(v);
const digest=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(value)))),b=>b.toString(16).padStart(2,'0')).join('');
async function groupDb(table,query,options={}){
 if(![TABLE,LEGACY].includes(table)||table===LEGACY&&options.method&&options.method!=='GET')failure('Không được thay đổi nguồn nhóm cũ.',403);
 const base=Deno.env.get('SUPABASE_URL'),secret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');if(!base||!secret)failure('Chưa sẵn sàng lưu nhóm Find Master.',503);
 let response;try{response=await fetch(base+'/rest/v1/'+table+'?'+query.toString(),{...options,headers:{apikey:secret,Authorization:'Bearer '+secret,'Content-Type':'application/json',Prefer:'return=representation',...options.headers},signal:AbortSignal.timeout(12000)});}catch{failure('Chưa xác nhận được kết quả. Hãy tải lại danh sách trước khi thao tác tiếp.',503);}
 if(!response.ok)failure('Chưa đọc/lưu được danh sách cặp PGs. Hãy tải lại để kiểm tra trạng thái đã xác nhận.',503);
 const rows=await response.json();if(!Array.isArray(rows))failure('Phản hồi danh sách nhóm chưa hợp lệ.',503);return rows;
}
async function context(body){
 const p=await authenticate(body.dashboardToken);
 if(!validId(body.campaignId)||!/^\d{4}-(0[1-9]|1[0-2])$/.test(body.month||''))failure('Chiến dịch hoặc tháng không hợp lệ.');
 const data=await readDashboardValues(['campaigns','pgsMaster:'+body.campaignId,'monthLock:'+body.month,'pgs:'+body.month]);
 const camp=(data.campaigns||[]).find(c=>String(c.id)===body.campaignId&&c.month===body.month&&c.group==='noibo'&&c.subtype==='pgsmaster');if(!camp)failure('Chiến dịch Find Master không thuộc tháng đang xem.',403);
 const master=data['pgsMaster:'+body.campaignId];if(!master||!Array.isArray(master.registered))failure('Chưa có danh sách Find Master đã chốt.',409);
 const trainers=(p.trainers||[]).filter(t=>validId(String(t.id))&&(p.role==='admin'||PairModel.norm(t.region)===PairModel.norm(p.region))),ids=new Set(trainers.map(t=>String(t.id)));
 const filter={campaign_id:'eq.'+body.campaignId};if(p.role!=='admin')filter.trainer_id='in.('+[...ids].join(',')+')';
 const [records,legacy]=trainers.length?await Promise.all([groupDb(TABLE,new URLSearchParams({...filter,environment:'eq.'+ENVIRONMENT,select:'*'})),groupDb(LEGACY,new URLSearchParams({...filter,select:'trainer_id,version,groups,updated_at'}))]):[[],[]];
 return {p,camp,master,hr:data['pgs:'+body.month],trainers,records:records.filter(r=>r.environment===ENVIRONMENT&&ids.has(String(r.trainer_id))),legacy:legacy.filter(r=>ids.has(String(r.trainer_id))),monthLocked:data['monthLock:'+body.month]===true};
}
async function view(ctx){
 const {p,master,hr,trainers,records,legacy,monthLocked}=ctx,result=[];
 for(const t of trainers){
  const id=String(t.id),record=records.find(r=>String(r.trainer_id)===id),old=legacy.find(r=>String(r.trainer_id)===id),raw=record?.groups||old?.groups||[];
  if(!Array.isArray(raw)||record&&(!Number.isSafeInteger(Number(record.version))||!Object.keys(PairModel.states).includes(record.state)))failure('Dữ liệu nhóm đã lưu chưa đúng định dạng.',503);
  const roster=PairModel.roster(master.registered,master.systemMeta,t,hr,master.manualRemove),baseRoster=roster.map(p=>[p.code,p.employeeCode,p.name,p.shopId,p.shop,p.region,p.province,p.channel,p.trainerId]),blocked=roster.filter(p=>p.eligible===false).map(p=>[p.code,p.eligibilityReason,PairModel.norm(p.hrStatus)]),rosterRevision=await digest(blocked.length?{roster:baseRoster,blocked}:baseRoster);
  const groups=raw.map(g=>PairModel.group(g,roster,id)),state=record?.state||'draft',version=Number(record?.version||0),sourceRevision=record?'workflow:'+version:'legacy:'+Number(old?.version||0)+':'+await digest(raw);
  const completionError=PairModel.complete(roster,groups),stale=!!record&&['pending','approved'].includes(state)&&(record.roster_revision!==rosterRevision||!!completionError);
  const unlocked=!!master.locked&&!monthLocked,owns=p.role==='admin'||String(p.trainerId)===id,editable=unlocked&&owns&&['draft','returned'].includes(state);
  result.push({id,name:String(t.name||''),region:String(t.region||''),version,sourceRevision,rosterRevision,roster,eligibleCount:PairModel.eligibleRoster(roster).length,blockedCount:blocked.length,groups,state,effectiveState:stale?'stale':state,legacy:!record&&!!old,completionError,stale,submittedAt:record?.submitted_at||null,reviewedAt:record?.reviewed_at||null,returnNote:record?.return_note||'',updatedAt:record?.updated_at||old?.updated_at||null,canManage:editable,canSubmit:editable&&!completionError,canApprove:p.role==='admin'&&unlocked&&state==='pending'&&!stale,canReturn:p.role==='admin'&&unlocked&&['pending','approved'].includes(state)});
 }
 return {ok:true,campaignId:String(ctx.camp.id),month:ctx.camp.month,environment:ENVIRONMENT,monthLocked,rosterLocked:!!master.locked,sourceUpdatedAt:master.systemUpdatedAt||null,role:p.role,ownTrainerId:p.trainerId,trainers:result};
}
function filteredExport(current,body){
 const f=body.filter||{};if(!f||typeof f!=='object'||Array.isArray(f))failure('Bộ lọc xuất Excel chưa hợp lệ.');
 if(f.trainerId&&!current.trainers.some(t=>t.id===f.trainerId)||f.region&&!current.trainers.some(t=>PairModel.norm(t.region)===PairModel.norm(f.region)))failure('Bộ lọc xuất nằm ngoài phạm vi được cấp quyền.',403);
 if(f.state&&!Object.keys(PairModel.states).includes(f.state)||String(f.search||'').length>200||String(f.channel||'').length>200)failure('Bộ lọc xuất Excel chưa hợp lệ.');
 const groups=PairModel.select(current.trainers,f);return {ok:true,campaignId:current.campaignId,month:current.month,export:{columns:PairModel.exportColumns,rows:PairModel.exportRows(groups),groupCount:groups.length,memberCount:groups.reduce((n,g)=>n+g.members.length,0)}};
}
async function handle(body){
 if(!['view','export','save','delete','submit','approve','return'].includes(body.action))failure('Thao tác không hợp lệ.');
 const ctx=await context(body),current=await view(ctx);if(body.action==='view')return current;if(body.action==='export')return filteredExport(current,body);
 const tid=String(body.trainerId||''),owner=current.trainers.find(t=>t.id===tid);if(!owner||ctx.p.role!=='admin'&&tid!==String(ctx.p.trainerId))failure('Chỉ được thao tác danh sách PG do chính Trainer phụ trách.',403);
 if(!current.rosterLocked||current.monthLocked)failure(current.monthLocked?'Tháng đã khóa, không thể thay đổi nhóm hoặc duyệt final.':'Cần chốt danh sách Master trước khi thao tác.',409);
 if(!Number.isSafeInteger(body.expectedVersion)||body.expectedVersion!==owner.version||body.rosterRevision!==owner.rosterRevision||body.sourceRevision!==owner.sourceRevision)failure('Danh sách hoặc trạng thái đã thay đổi. Hãy tải lại trước khi lưu/duyệt.',409);
 const stored=ctx.records.find(r=>String(r.trainer_id)===tid),old=ctx.legacy.find(r=>String(r.trainer_id)===tid),groups=JSON.parse(JSON.stringify(stored?.groups||old?.groups||[])),now=new Date().toISOString();
 let nextState=owner.state,extra={};
 if(['save','delete'].includes(body.action)){
  if(!owner.canManage)failure('Danh sách đang chờ hoặc đã duyệt final. Admin cần trả lại trước khi sửa.',409);
  const gid=body.action==='save'?body.group?.id:body.groupId;if(!validGroupId(gid))failure('Mã nhóm không hợp lệ.');const index=groups.findIndex(g=>g.id===gid);
  if(body.action==='delete'){if(index<0)failure('Nhóm không còn tồn tại. Hãy tải lại.',409);groups.splice(index,1);}else{
   const error=PairModel.validate(body.group?.members,owner.roster,groups,gid);if(error)failure(error,409);
   const next={id:gid,members:body.group.members.map(PairModel.code),createdAt:index<0?now:groups[index].createdAt,updatedAt:now};if(index<0)groups.push(next);else groups[index]=next;if(groups.length>500)failure('Số nhóm vượt giới hạn.');
  }
  nextState='draft';
 }else if(body.action==='submit'){
  if(!owner.canManage)failure('Danh sách đã gửi hoặc đã duyệt. Hãy tải lại để kiểm tra trạng thái.',409);if(owner.completionError)failure(owner.completionError,409);
  nextState='pending';extra={submitted_at:now,submitted_by:ctx.p.userId,reviewed_at:null,reviewed_by:null,return_note:''};
 }else{
  if(ctx.p.role!=='admin')failure('Chỉ Admin được duyệt final hoặc trả lại danh sách.',403);
  if(body.action==='approve'){if(!owner.canApprove)failure(owner.stale?'Danh sách PG đã thay đổi sau khi gửi. Hãy trả lại để Trainer ghép và gửi lại.':'Chỉ duyệt final danh sách đang chờ.',409);nextState='approved';extra={reviewed_at:now,reviewed_by:ctx.p.userId,return_note:''};}
  else {if(!owner.canReturn)failure('Chỉ trả lại danh sách đang chờ hoặc đã duyệt.',409);const note=typeof body.note==='string'?body.note.trim():'';if(!note||note.length>500)failure('Cần nhập lý do trả lại, tối đa 500 ký tự.');nextState='returned';extra={reviewed_at:now,reviewed_by:ctx.p.userId,return_note:note};}
 }
 const latest=await context(body),fresh=await view(latest),live=fresh.trainers.find(t=>t.id===tid);
 if(!live||fresh.monthLocked||!fresh.rosterLocked||live.version!==owner.version||live.sourceRevision!==owner.sourceRevision||live.rosterRevision!==owner.rosterRevision||live.state!==owner.state||ctx.p.role!==latest.p.role||ctx.p.userId!==latest.p.userId)failure('Danh sách hoặc quyền vừa thay đổi. Hãy tải lại trước khi xác nhận.',409);
 const payload={environment:ENVIRONMENT,campaign_id:body.campaignId,trainer_id:tid,version:owner.version+1,groups,state:nextState,roster_revision:owner.rosterRevision,legacy_version:Number(stored?.legacy_version||old?.version||0),updated_by:ctx.p.userId,updated_at:now,...extra};
 let saved;if(!stored)saved=await groupDb(TABLE,new URLSearchParams({select:'*'}),{method:'POST',headers:{Prefer:'resolution=ignore-duplicates,return=representation'},body:JSON.stringify(payload)});
 else saved=await groupDb(TABLE,new URLSearchParams({environment:'eq.'+ENVIRONMENT,campaign_id:'eq.'+body.campaignId,trainer_id:'eq.'+tid,version:'eq.'+owner.version,state:'eq.'+owner.state,select:'*'}),{method:'PATCH',body:JSON.stringify(payload)});
 if(saved.length!==1)failure('Danh sách vừa được cập nhật ở phiên khác. Hãy tải lại; chưa ghi đè dữ liệu mới.',409);
 latest.records=latest.records.filter(r=>String(r.trainer_id)!==tid).concat(saved);return {...await view(latest),saved:true,action:body.action};
}
Deno.serve(async req=>{
 const origin=req.headers.get('origin');if(origin&&origin!==ORIGIN)return reply({error:'Nguồn truy cập không hợp lệ.'},403);if(req.method==='OPTIONS')return new Response(null,{status:204,headers:CORS});if(req.method!=='POST')return reply({error:'Chỉ hỗ trợ POST.'},405);
 try{if(Number(req.headers.get('content-length')||0)>6000)failure('Yêu cầu quá dài.');const raw=await req.text();if(raw.length>6000)failure('Yêu cầu quá dài.');let body;try{body=JSON.parse(raw);}catch{failure('Yêu cầu không hợp lệ.');}if(!body||typeof body!=='object'||Array.isArray(body))failure('Yêu cầu không hợp lệ.');return reply(await handle(body));}
 catch(error){return reply({error:error instanceof AccessError?error.message:'Chưa xử lý được danh sách cặp PGs. Hãy tải lại để kiểm tra kết quả đã lưu.'},error instanceof AccessError?error.status:503);}
});
