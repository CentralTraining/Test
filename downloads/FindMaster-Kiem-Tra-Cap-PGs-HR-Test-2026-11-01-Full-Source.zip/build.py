from pathlib import Path
import hashlib,json,re
r=Path(__file__).parent;s=(r/'before.html').read_text();assert hashlib.sha256(s.encode()).hexdigest()=='2c64cd2fcdbc9eb716f66d901454c39defc0286cbd3b21c29d4116263cb3924f'
def block(id,tag,body):
 global s
 pattern=r'(<'+tag+r' id="'+re.escape(id)+r'">).*?(</'+tag+r'>)';s,n=re.subn(pattern,lambda m:m.group(1)+'\n'+body+'\n'+m.group(2),s,flags=re.S);assert n==1,(id,n)
block('pgsm-pairs-model-20261028','script',(r/'function/model.js').read_text().replace('export const PairModel','const PairModel',1))
block('pgsm-pairs-ui-20261028','script',(r/'pairs-ui.js').read_text())
block('pgsm-pairs-style-20261028','style',(r/'pairs.css').read_text()+'\n'+(r/'workflow.css').read_text()+'\n'+(r/'eligibility.css').read_text())
b=s.encode();name='Dashboard-Test-2026-11-01-FindMaster-Kiem-Tra-Cap-PGs-HR.html'
for n in ['index.html',name]:(r/n).write_bytes(b)
m={'scope':'Test','date':'2026-11-01','filename':name,'base_commit':'c7e1d76fa21c4ed91d2f596422e35bc5ccaa29a7','bytes':len(b),'characters':len(s),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+bytes([0])+b).hexdigest(),'function':'pgsm-pairs-test','environment':'test','main_changed':False,'schema_changed':False,'secrets_changed':False,'business_data_changed':False}
(r/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));print(json.dumps(m))
